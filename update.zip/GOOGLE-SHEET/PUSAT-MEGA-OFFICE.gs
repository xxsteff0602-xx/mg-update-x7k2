// MEGA OFFICE - PUSAT (akun staff, izin aplikasi, pengumuman, riwayat masuk)
// Pasang di Google Sheet KHUSUS milikmu (jangan dibagikan ke staff). Cara lengkap: PASANG-PUSAT.txt
//
// Tab yang dibuat otomatis:
//   Akun        : satu baris per orang. Sandi TIDAK disimpan apa adanya (hanya sidik acak / hash).
//   Riwayat     : siapa masuk / gagal / terkunci, jam berapa, dari PC mana.
//   Pengumuman  : baris paling bawah = pengumuman yang tampil di Home staff.
// Jangan mengubah isi kolom salt / hash dengan tangan. Kolom lain boleh dibaca, ubah lewat menu Admin di aplikasi.

var AKUN_HEAD = ['username', 'nama', 'role', 'website', 'shift', 'apps', 'status', 'gagal', 'kunci_sampai', 'wajib_ganti', 'terakhir_masuk', 'dibuat', 'salt', 'hash'];
var RIW_HEAD = ['waktu', 'username', 'kejadian', 'pc', 'website', 'info'];
var PENG_HEAD = ['waktu', 'oleh', 'teks'];
var MAX_GAGAL = 5;               // salah sandi berturut-turut sebelum akun terkunci
var KUNCI_MENIT = 30;            // lama terkunci (atau sampai admin membuka kunci)
var TOKEN_JAM = 14;              // sesi login berlaku (jam), cukup untuk satu shift + lembur
var ITER = 300;                  // putaran hash sandi

// ------------------------------------------------------------------ util
function props_() { return PropertiesService.getScriptProperties(); }
function now_() { return new Date(); }
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function hex_(bytes) { var s = ''; for (var i = 0; i < bytes.length; i++) { var b = (bytes[i] + 256) % 256; s += (b < 16 ? '0' : '') + b.toString(16); } return s; }
function sha_(s) { return hex_(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, s, Utilities.Charset.UTF_8)); }
function hashPw_(pw, salt) { var h = sha_(salt + ':' + pw); for (var i = 0; i < ITER; i++) h = sha_(h + salt); return h; }
function rand_() { return Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, ''); }
function same_(a, b) { a = String(a); b = String(b); if (a.length !== b.length) return false; var d = 0; for (var i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i); return d === 0; }
function clean_(s, n) { return String(s == null ? '' : s).replace(/[\r\n\t]+/g, ' ').trim().substring(0, n || 200); }
function uname_(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9._-]/g, '').substring(0, 30); }

function tab_(name, head) {
  var ss = SpreadsheetApp.getActive();
  var s = ss.getSheetByName(name);
  if (!s) s = ss.insertSheet(name);
  if (s.getLastRow() === 0) {
    s.appendRow(head);
    s.setFrozenRows(1);
    s.getRange(1, 1, 1, head.length).setFontWeight('bold');
  }
  return s;
}

// ------------------------------------------------------------------ akun
function readUsers_() {
  var s = tab_('Akun', AKUN_HEAD);
  var v = s.getDataRange().getValues();
  var list = [];
  for (var r = 1; r < v.length; r++) {
    if (!v[r][0]) continue;
    var o = { _row: r + 1 };
    for (var c = 0; c < AKUN_HEAD.length; c++) o[AKUN_HEAD[c]] = v[r][c];
    o.username = uname_(o.username);
    o.gagal = Number(o.gagal) || 0;
    list.push(o);
  }
  return list;
}
function findUser_(u) { u = uname_(u); var l = readUsers_(); for (var i = 0; i < l.length; i++) if (l[i].username === u) return l[i]; return null; }
function writeUser_(o) {
  var s = tab_('Akun', AKUN_HEAD);
  var row = AKUN_HEAD.map(function (k) { return o[k] == null ? '' : o[k]; });
  if (o._row) s.getRange(o._row, 1, 1, AKUN_HEAD.length).setValues([row]);
  else s.appendRow(row);
}
function publicUser_(o) {
  return { username: o.username, nama: String(o.nama || o.username), role: String(o.role || 'staff'), website: String(o.website || ''),
           shift: String(o.shift || 'pagi'), apps: String(o.apps || '').split(',').map(function (x) { return x.trim(); }).filter(String),
           status: String(o.status || 'aktif'), wajib_ganti: String(o.wajib_ganti) === '1' || o.wajib_ganti === true || o.wajib_ganti === 1,
           terkunci: lockedUntil_(o) > now_().getTime(), gagal: o.gagal, terakhir_masuk: fmt_(o.terakhir_masuk) };
}
function lockedUntil_(o) { var t = o.kunci_sampai ? new Date(o.kunci_sampai).getTime() : 0; return isNaN(t) ? 0 : t; }
function fmt_(d) {
  if (!d) return '';
  var x = d instanceof Date ? d : new Date(d);
  if (isNaN(x.getTime())) return String(d);
  return Utilities.formatDate(x, Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm');
}
function log_(u, ev, pc, web, info) {
  tab_('Riwayat', RIW_HEAD).appendRow([now_(), uname_(u), clean_(ev, 40), clean_(pc, 60), clean_(web, 40), clean_(info, 200)]);
}
function webUrl_() { return props_().getProperty('MO_WEB') || ''; }
function announcement_() {
  var s = tab_('Pengumuman', PENG_HEAD);
  var n = s.getLastRow();
  if (n < 2) return null;
  var v = s.getRange(n, 1, 1, 3).getValues()[0];
  if (!String(v[2]).trim()) return null;
  return { waktu: fmt_(v[0]), oleh: String(v[1]), teks: String(v[2]) };
}

// ------------------------------------------------------------------ token (tanda tangan HMAC, tidak disimpan di sheet)
function b64_(s) { return Utilities.base64EncodeWebSafe(s).replace(/=+$/, ''); }
function unb64_(s) { while (s.length % 4) s += '='; return Utilities.newBlob(Utilities.base64DecodeWebSafe(s)).getDataAsString(); }
function sign_(payload) { return b64_(Utilities.computeHmacSha256Signature(payload, props_().getProperty('TOKEN_SECRET'))); }
function makeToken_(o) {
  var p = b64_(JSON.stringify({ u: o.username, r: String(o.role || 'staff'), x: now_().getTime() + TOKEN_JAM * 3600000 }));
  return p + '.' + sign_(p);
}
function readToken_(t) {
  var parts = String(t || '').split('.');
  if (parts.length !== 2 || !same_(sign_(parts[0]), parts[1])) return null;
  var p; try { p = JSON.parse(unb64_(parts[0])); } catch (e) { return null; }
  if (!p || p.x < now_().getTime()) return null;
  var o = findUser_(p.u);
  if (!o || String(o.status || 'aktif') !== 'aktif') return null;
  return o;
}

// ------------------------------------------------------------------ cek sandi (dipakai login & buka kunci layar)
function checkPw_(o, pw, pc, ev) {
  var t = now_().getTime();
  if (lockedUntil_(o) > t) {
    var m = Math.ceil((lockedUntil_(o) - t) / 60000);
    return { ok: false, locked: true, msg: 'Akun terkunci karena terlalu banyak salah sandi. Coba lagi ' + m + ' menit lagi atau minta admin membuka kunci.' };
  }
  if (same_(hashPw_(String(pw || ''), String(o.salt)), String(o.hash))) {
    o.gagal = 0; o.kunci_sampai = '';
    return { ok: true };
  }
  o.gagal = (Number(o.gagal) || 0) + 1;
  var left = MAX_GAGAL - o.gagal;
  if (left <= 0) {
    o.kunci_sampai = new Date(t + KUNCI_MENIT * 60000); o.gagal = 0;
    writeUser_(o); log_(o.username, 'terkunci', pc, o.website, ev);
    return { ok: false, locked: true, msg: 'Salah sandi ' + MAX_GAGAL + ' kali. Akun terkunci ' + KUNCI_MENIT + ' menit atau sampai admin membuka kunci.' };
  }
  writeUser_(o); log_(o.username, ev + ' gagal', pc, o.website, 'sisa ' + left);
  return { ok: false, left: left, msg: 'Sandi salah. Sisa ' + left + ' percobaan.' };
}

// ------------------------------------------------------------------ API
function doGet() { return out_({ ok: true, app: 'mega-office-pusat' }); }

function doPost(e) {
  var d;
  try { d = JSON.parse(e.postData.contents); } catch (x) { return out_({ ok: false, msg: 'permintaan tidak valid' }); }
  var key = props_().getProperty('PUSAT_KEY');
  if (!key || !same_(d.k, key)) return out_({ ok: false, msg: 'kode pusat salah' });
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try { return out_(handle_(d)); }
  catch (x) { return out_({ ok: false, msg: 'Pusat error: ' + String(x && x.message || x).substring(0, 120) }); }
  finally { lock.releaseLock(); }
}

function handle_(d) {
  var a = String(d.a || ''), pc = clean_(d.pc, 60);
  if (a === 'ping') return { ok: true, name: SpreadsheetApp.getActive().getName() };

  if (a === 'login') {
    var o = findUser_(d.u);
    if (!o) { log_(d.u, 'login gagal', pc, '', 'username tidak ada'); return { ok: false, msg: 'Username atau sandi salah.' }; }
    if (String(o.status || 'aktif') !== 'aktif') { log_(o.username, 'login ditolak', pc, o.website, 'akun nonaktif'); return { ok: false, msg: 'Akun ini dinonaktifkan. Hubungi admin.' }; }
    var c = checkPw_(o, d.p, pc, 'login');
    if (!c.ok) return c;
    o.terakhir_masuk = now_(); writeUser_(o); log_(o.username, 'login', pc, o.website, '');
    return { ok: true, token: makeToken_(o), user: publicUser_(o), ann: announcement_(), web: webUrl_() };
  }

  var me = readToken_(d.t);
  if (!me) return { ok: false, expired: true, msg: 'Sesi berakhir, silakan login lagi.' };

  if (a === 'me') return { ok: true, user: publicUser_(me), ann: announcement_(), web: webUrl_() };
  if (a === 'verify') {                                    // buka kunci layar (idle)
    var v = checkPw_(me, d.p, pc, 'buka kunci');
    if (v.ok) writeUser_(me);
    return v;
  }
  if (a === 'passwd') {
    var p = checkPw_(me, d.old, pc, 'ganti sandi');
    if (!p.ok) return p;
    var nw = String(d.new || '');
    if (nw.length < 6) { writeUser_(me); return { ok: false, msg: 'Sandi baru minimal 6 karakter.' }; }
    if (nw === String(d.old)) { writeUser_(me); return { ok: false, msg: 'Sandi baru harus beda dengan sandi lama.' }; }
    me.salt = rand_().substring(0, 24); me.hash = hashPw_(nw, me.salt); me.wajib_ganti = '';
    writeUser_(me); log_(me.username, 'ganti sandi', pc, me.website, '');
    return { ok: true, user: publicUser_(me) };
  }
  if (a === 'rename') {                                    // ganti username sendiri (nama tampilan tetap, hanya admin yang bisa ubah)
    var raw = String(d.nu || '').trim().toLowerCase(), nu = uname_(raw);
    if (nu !== raw || nu.length < 3) return { ok: false, msg: 'Username 3-30 karakter: huruf kecil, angka, titik, strip, garis bawah.' };
    if (nu === me.username) return { ok: false, msg: 'Username baru sama dengan yang sekarang.' };
    var rp = checkPw_(me, d.p, pc, 'ganti username');
    if (!rp.ok) return rp;
    if (findUser_(nu)) { writeUser_(me); return { ok: false, msg: 'Username "' + nu + '" sudah dipakai akun lain.' }; }
    var oldU = me.username;
    me.username = nu; writeUser_(me); log_(nu, 'ganti username', pc, me.website, oldU + ' -> ' + nu);
    return { ok: true, token: makeToken_(me), user: publicUser_(me) };
  }
  if (a === 'logout') { log_(me.username, 'logout', pc, me.website, clean_(d.info, 80)); return { ok: true }; }
  if (a === 'event') { log_(me.username, clean_(d.ev, 40), pc, me.website, clean_(d.info, 200)); return { ok: true }; }

  // ---------------- khusus admin
  if (String(me.role) !== 'admin') return { ok: false, msg: 'Khusus admin.' };
  if (a === 'users') return { ok: true, users: readUsers_().map(publicUser_) };
  if (a === 'history') {
    var s = tab_('Riwayat', RIW_HEAD), n = s.getLastRow(), lim = Math.min(Number(d.limit) || 200, 1000);
    if (n < 2) return { ok: true, rows: [] };
    var start = Math.max(2, n - lim + 1);
    var v = s.getRange(start, 1, n - start + 1, RIW_HEAD.length).getValues().reverse();
    return { ok: true, rows: v.map(function (r) { return { waktu: fmt_(r[0]), username: r[1], kejadian: r[2], pc: r[3], website: r[4], info: r[5] }; }) };
  }
  if (a === 'setweb') {                                   // alamat MEGA OFFICE web (dipakai menu Cek Rekening di aplikasi PC)
    var w = String(d.web || '').trim().replace(/\/+$/, '');
    if (w && !/^https:\/\/[A-Za-z0-9.-]+(:\d+)?$/.test(w)) return { ok: false, msg: 'Alamat web harus seperti https://nama.vercel.app' };
    props_().setProperty('MO_WEB', w);
    log_(me.username, 'alamat web', pc, '', w);
    return { ok: true, web: w };
  }
  if (a === 'announce') {
    var teks = clean_(d.teks, 500);
    tab_('Pengumuman', PENG_HEAD).appendRow([now_(), me.username, teks]);
    log_(me.username, 'pengumuman', pc, '', teks.substring(0, 80));
    return { ok: true, ann: announcement_() };
  }
  if (a === 'save') {                                      // tambah / ubah akun
    var u = d.user || {}, un = uname_(u.username);
    if (un.length < 3) return { ok: false, msg: 'Username minimal 3 huruf/angka (boleh titik, strip, garis bawah).' };
    var cur = findUser_(un);
    var role = u.role === 'admin' ? 'admin' : 'staff';
    if (cur && cur.username === me.username && u.role != null && role !== 'admin') return { ok: false, msg: 'Tidak bisa menurunkan akun admin yang sedang dipakai.' };
    if (cur && cur.username === me.username && u.status != null && u.status !== 'aktif') return { ok: false, msg: 'Tidak bisa menonaktifkan akun yang sedang dipakai.' };
    var o2 = cur || { username: un, gagal: 0, dibuat: now_() };
    // field yang tidak dikirim = tidak diubah (untuk akun yang sudah ada)
    if (u.nama != null || !cur) o2.nama = clean_(u.nama || un, 40);
    if (u.role != null || !cur) o2.role = role;
    if (u.website != null || !cur) o2.website = clean_(u.website, 30).toUpperCase().replace(/[^A-Z0-9_-]/g, '');
    if (u.shift != null || !cur) o2.shift = u.shift === 'malam' ? 'malam' : 'pagi';
    if (u.apps != null || !cur) o2.apps = (u.apps || []).map(function (x) { return String(x).replace(/[^a-z]/g, ''); }).filter(String).join(',');
    if (u.status != null || !cur) o2.status = u.status === 'nonaktif' ? 'nonaktif' : 'aktif';
    if (!cur) {
      var pw = String(d.pw || '');
      if (pw.length < 6) return { ok: false, msg: 'Sandi awal minimal 6 karakter.' };
      o2.salt = rand_().substring(0, 24); o2.hash = hashPw_(pw, o2.salt); o2.wajib_ganti = '1';
    }
    writeUser_(o2); log_(me.username, cur ? 'ubah akun' : 'tambah akun', pc, o2.website, o2.username);
    return { ok: true, user: publicUser_(o2) };
  }
  var target = findUser_(d.username);
  if (!target) return { ok: false, msg: 'Akun tidak ditemukan.' };
  if (a === 'reset') {
    var np = String(d.pw || '');
    if (np.length < 6) return { ok: false, msg: 'Sandi sementara minimal 6 karakter.' };
    target.salt = rand_().substring(0, 24); target.hash = hashPw_(np, target.salt); target.wajib_ganti = '1';
    target.gagal = 0; target.kunci_sampai = '';
    writeUser_(target); log_(me.username, 'reset sandi', pc, target.website, target.username);
    return { ok: true, user: publicUser_(target) };
  }
  if (a === 'unlock') {
    target.gagal = 0; target.kunci_sampai = '';
    writeUser_(target); log_(me.username, 'buka kunci akun', pc, target.website, target.username);
    return { ok: true, user: publicUser_(target) };
  }
  if (a === 'delete') {
    if (target.username === me.username) return { ok: false, msg: 'Tidak bisa menghapus akun yang sedang dipakai.' };
    tab_('Akun', AKUN_HEAD).deleteRow(target._row);
    log_(me.username, 'hapus akun', pc, target.website, target.username);
    return { ok: true };
  }
  return { ok: false, msg: 'aksi tidak dikenal' };
}

// ------------------------------------------------------------------ menu di Google Sheet
function onOpen() {
  SpreadsheetApp.getUi().createMenu('MEGA OFFICE')
    .addItem('1. Siapkan Pusat & akun admin', 'siapkanPusat')
    .addItem('2. Tampilkan Kode Pusat', 'tampilkanKode')
    .addSeparator()
    .addItem('Reset sandi admin (darurat)', 'resetAdminDarurat')
    .addToUi();
}

function siapkanPusat() {
  var ui = SpreadsheetApp.getUi(), P = props_();
  if (!P.getProperty('PUSAT_KEY')) P.setProperty('PUSAT_KEY', rand_());
  if (!P.getProperty('TOKEN_SECRET')) P.setProperty('TOKEN_SECRET', rand_());
  tab_('Akun', AKUN_HEAD); tab_('Riwayat', RIW_HEAD); tab_('Pengumuman', PENG_HEAD);
  var ada = readUsers_().filter(function (o) { return o.role === 'admin'; });
  if (ada.length) { ui.alert('Pusat sudah siap. Admin: ' + ada.map(function (o) { return o.username; }).join(', ') + '\nLanjut ke langkah Deploy (lihat PASANG-PUSAT.txt).'); return; }
  var r1 = ui.prompt('Akun admin', 'Username admin (huruf kecil, misal: ketupat):', ui.ButtonSet.OK_CANCEL);
  if (r1.getSelectedButton() !== ui.Button.OK) return;
  var un = uname_(r1.getResponseText());
  if (un.length < 3) { ui.alert('Username minimal 3 huruf.'); return; }
  var r2 = ui.prompt('Akun admin', 'Sandi admin (minimal 6 karakter). Catat baik-baik:', ui.ButtonSet.OK_CANCEL);
  if (r2.getSelectedButton() !== ui.Button.OK) return;
  var pw = r2.getResponseText();
  if (pw.length < 6) { ui.alert('Sandi minimal 6 karakter.'); return; }
  var salt = rand_().substring(0, 24);
  writeUser_({ username: un, nama: un.charAt(0).toUpperCase() + un.substring(1), role: 'admin', website: '', shift: 'pagi', apps: 'selisih,depo', status: 'aktif',
               gagal: 0, kunci_sampai: '', wajib_ganti: '', terakhir_masuk: '', dibuat: now_(), salt: salt, hash: hashPw_(pw, salt) });
  log_(un, 'admin dibuat', 'Google Sheet', '', '');
  ui.alert('Admin "' + un + '" dibuat.\nSekarang Deploy sebagai Web app (lihat PASANG-PUSAT.txt), lalu pilih menu "2. Tampilkan Kode Pusat".');
}

function tampilkanKode() {
  var ui = SpreadsheetApp.getUi(), key = props_().getProperty('PUSAT_KEY');
  if (!key) { ui.alert('Jalankan menu "1. Siapkan Pusat" dulu.'); return; }
  var auto = '';
  try { auto = ScriptApp.getService().getUrl() || ''; } catch (e) { auto = ''; }
  var saved = props_().getProperty('WEBAPP_URL') || '';
  var r = ui.prompt('Alamat Web app', 'Tempel "Web app URL" dari Deploy (berakhiran /exec).\nKosongkan lalu OK untuk memakai: ' + (saved || auto || '(belum ada)'), ui.ButtonSet.OK_CANCEL);
  if (r.getSelectedButton() !== ui.Button.OK) return;
  var url = String(r.getResponseText() || '').trim() || saved || auto;
  if (!/^https:\/\/script\.google\.com\/.+\/exec$/.test(url)) { ui.alert('Alamat harus Web app URL yang berakhiran /exec (Deploy > Manage deployments > salin Web app URL).'); return; }
  props_().setProperty('WEBAPP_URL', url);
  var code = 'MOP1.' + b64_(JSON.stringify({ u: url, k: key }));
  var html = HtmlService.createHtmlOutput('<div style="font:14px Arial;padding:4px"><p>Salin kode ini, lalu tempel di MEGA OFFICE (layar <b>Hubungkan ke Pusat</b>) di setiap PC. Kode ini rahasia: jangan dikirim ke grup.</p>'
    + '<textarea style="width:100%;height:120px;font:12px monospace" readonly onclick="this.select()">' + code + '</textarea></div>').setWidth(520).setHeight(230);
  ui.showModalDialog(html, 'Kode Pusat MEGA OFFICE');
}

function resetAdminDarurat() {
  var ui = SpreadsheetApp.getUi();
  var r1 = ui.prompt('Reset sandi admin', 'Username admin:', ui.ButtonSet.OK_CANCEL);
  if (r1.getSelectedButton() !== ui.Button.OK) return;
  var o = findUser_(r1.getResponseText());
  if (!o || o.role !== 'admin') { ui.alert('Admin tidak ditemukan.'); return; }
  var r2 = ui.prompt('Reset sandi admin', 'Sandi baru (minimal 6 karakter):', ui.ButtonSet.OK_CANCEL);
  if (r2.getSelectedButton() !== ui.Button.OK) return;
  var pw = r2.getResponseText();
  if (pw.length < 6) { ui.alert('Sandi minimal 6 karakter.'); return; }
  o.salt = rand_().substring(0, 24); o.hash = hashPw_(pw, o.salt); o.gagal = 0; o.kunci_sampai = ''; o.status = 'aktif';
  writeUser_(o); log_(o.username, 'reset sandi admin', 'Google Sheet', '', '');
  ui.alert('Sandi admin "' + o.username + '" sudah diganti.');
}
