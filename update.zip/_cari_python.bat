@echo off
rem Mencari Python portable di folder ini. Kalau belum ada, diunduh sekali dari python.org.
set PY=python\python.exe
if exist "%PY%" goto :eof
echo.
echo Python portable belum ada. Mengunduh dari python.org (sekali saja, +/- 10 MB)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-embed-amd64.zip' -OutFile 'py.zip'; Expand-Archive -Force 'py.zip' 'python'; Remove-Item 'py.zip'"
if exist "%PY%" goto :eof
echo.
echo GAGAL mengunduh Python. Cek koneksi internet, lalu jalankan ulang.
pause
exit /b 1
