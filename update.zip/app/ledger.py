"""Buku deposit lokal (pengganti Google Sheet): satu baris per deposit, User ID + Deposit ID diisi dari BO."""
import os, re, json, time, threading

def norm(x): return re.sub(r"\s+", " ", re.sub(r"[^A-Z ]", " ", str(x or "").upper())).strip()

def lev(a, b):
    m, n = len(a), len(b)
    if not m: return n
    if not n: return m
    prev = list(range(n + 1))
    for i in range(1, m + 1):
        cur = [i]
        for j in range(1, n + 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (0 if a[i - 1] == b[j - 1] else 1)))
        prev = cur
    return prev[n]

def sim(a, b):
    a, b = norm(a), norm(b)
    if not a or not b: return 0.0
    aj, bj = a.replace(" ", ""), b.replace(" ", "")
    joined = 1 - lev(aj, bj) / max(len(aj), len(bj))
    ta, tb = a.split(" "), b.split(" ")
    hit = sum(1 for t in ta if any(u == t or (len(t) > 3 and len(u) > 3 and lev(t, u) <= 1) for u in tb))
    return max(joined, hit / max(len(ta), len(tb)))

# nama di mutasi/notifikasi yang bukan nama orang (e-wallet / gateway): tidak bisa dibandingkan dengan nama di BO
GENERIC = re.compile(r"\b(ESPAY|DOMPET ANAK BANGSA|GOPAY|GO PAY|OVO|DANA|SHOPEE|SHOPEEPAY|LINKAJA|LINK AJA|ISAKU|DEBIT INDONE|GOJEK|FINNET|MIDTRANS|XENDIT|DOKU|TELKOM|TOKOPEDIA|BUKALAPAK|FLIP|JENIUS)\b", re.I)
def generic(name): return bool(GENERIC.search(str(name or "")))

def ts_epoch(ts):
    try: return time.mktime(time.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S"))
    except Exception: return 0

class Ledger:
    def __init__(self, path):
        self.path, self.lock, self.rows = path, threading.RLock(), []
        try:
            with open(path, encoding="utf-8") as f: self.rows = json.load(f)
        except Exception: self.rows = []

    def _save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f: json.dump(self.rows, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError: pass

    def add(self, id, ts, name, amount, pend=False):
        with self.lock:
            if any(r["id"] == id for r in self.rows): return False
            self.rows.append({"id": id, "ts": ts, "name": name or "", "amount": int(amount), "user": "", "txid": "", "pend": bool(pend), "unsure": False, "confirmed": False})
            self.rows = self.rows[-5000:]; self._save(); return True

    def match(self, txid, user, name, amount):
        """Sama dengan Code.gs: kembalikan {ok, sure, pend, confirmed, sheetName}."""
        none = {"ok": False}
        txid = str(txid)
        with self.lock:
            for r in self.rows:
                if r["txid"] == txid:
                    return {"ok": True, "sure": not r["unsure"], "pend": r["pend"], "confirmed": r["confirmed"], "sheetName": r["name"]}
            cand = [(i, sim(r["name"], name)) for i, r in enumerate(self.rows) if not r["user"] and not r["txid"] and r["amount"] == int(amount)]
            if not cand: return none
            cand.sort(key=lambda c: (-c[1], -c[0]))
            bi, bs = cand[0]; strong = bs >= 0.5
            if not strong and len(cand) != 1: return none               # nominal kembar, nama tidak cocok: jangan menebak
            sure = strong and (len(cand) == 1 or cand[1][1] < 0.5)
            r = self.rows[bi]; r["user"] = str(user or ""); r["txid"] = txid
            if not strong: r["unsure"] = True
            self._save()
            return {"ok": True, "sure": sure, "pend": r["pend"], "confirmed": False, "sheetName": r["name"]}

    def mark_confirmed(self, txid):
        with self.lock:
            for r in self.rows:
                if r["txid"] == str(txid):
                    if not r["confirmed"]: r["confirmed"] = True; self._save()
                    return True
        return False

    def delete(self, ids=None, day=None):
        with self.lock:
            n = len(self.rows)
            if ids is not None: s = set(ids); self.rows = [r for r in self.rows if r["id"] not in s]
            elif day: self.rows = [r for r in self.rows if r["ts"][:10] != day]
            self._save(); return n - len(self.rows)

    def edit(self, id, field, value):
        if field not in ("user", "txid"): return False
        with self.lock:
            for r in self.rows:
                if r["id"] == id:
                    r[field] = str(value or "").strip()
                    if field == "user" and r[field]: r["unsure"] = False
                    self._save(); return True
        return False

    def unassign(self, txid):
        """Setelah deposit BO di-reject: lepaskan pasangannya supaya baris bank bisa dipakai deposit lain."""
        with self.lock:
            for r in self.rows:
                if r["txid"] == str(txid):
                    r["user"] = ""; r["txid"] = ""; r["unsure"] = False; self._save(); return True
        return False

    def judge(self, items, now, since, grace, window=3 * 3600):
        """Putuskan tiap deposit BO (In Progress, Fund Method Bank): reject / ok / skip.
        items: [{txid,name,amount,bornAt(ms),noReceipt}]. Hanya reject kalau buktinya jelas; selebihnya skip (cek manual)."""
        out = {}
        def skip(why): return {"v": "skip", "why": why}
        with self.lock:
            by_tx = {r["txid"]: r for r in self.rows if r["txid"]}
            cand = [r for r in self.rows if not r["user"] and not r["txid"] and now - ts_epoch(r["ts"]) <= window]
            n_amt = {}
            for it in items: n_amt[int(it["amount"])] = n_amt.get(int(it["amount"]), 0) + 1
            for it in items:
                tx, amt = str(it["txid"]), int(it["amount"])
                born = (it.get("bornAt") or 0) / 1000.0
                if since is None: out[tx] = skip("aplikasi belum sehat / belum membaca HP"); continue
                if not born: out[tx] = skip("jam deposit tidak terbaca"); continue
                if born < since: out[tx] = skip("deposit lebih tua dari pemantauan aplikasi"); continue
                if now - born < grace: out[tx] = skip("masih dalam masa tunggu"); continue
                c = by_tx.get(tx)
                if c:
                    if c["unsure"] and not generic(c["name"]) and sim(c["name"], it["name"]) >= 0.35:
                        out[tx] = skip("nama agak mirip, cek manual")
                    elif c["unsure"] and not generic(c["name"]):
                        out[tx] = ({"v": "reject", "reason": "NAME", "why": f'nominal sama tapi nama beda: bank "{c["name"]}" vs BO "{it["name"]}"'}
                                   if n_amt[amt] == 1 else skip("nama beda tapi ada deposit BO bernominal sama, cek manual"))
                    else: out[tx] = {"v": "ok"}
                    continue
                same = [r for r in cand if r["amount"] == amt]
                if same:
                    if any(sim(r["name"], it["name"]) >= 0.5 and not generic(r["name"]) for r in same): out[tx] = {"v": "ok"}
                    elif any(generic(r["name"]) for r in same): out[tx] = skip("nama di bank e-wallet/gateway, cek manual")
                    else: out[tx] = skip("nominal sama dengan beberapa transfer, cek manual")
                    continue
                nm = [r for r in cand if not generic(r["name"]) and sim(r["name"], it["name"]) >= 0.6 and r["amount"] != amt and n_amt.get(r["amount"], 0) == 0]
                if len(nm) == 1:
                    out[tx] = {"v": "reject", "reason": "AMOUNT", "why": f'nama cocok tapi nominal beda: bank Rp {nm[0]["amount"]:,} vs BO Rp {amt:,}'.replace(",", ".")}
                elif len(nm) > 1: out[tx] = skip("beberapa transfer dengan nama mirip, cek manual")
                elif it.get("noReceipt"): out[tx] = {"v": "reject", "reason": "RECEIPT", "why": "tidak ada bukti dan tidak ada transfer dengan nama pengirim itu"}
                else: out[tx] = skip("belum ada transfer, tapi ada bukti: cek manual")
        return out

    def view(self):
        with self.lock: return [dict(r) for r in self.rows]


class ListStore:
    """Catatan sederhana (daftar baris) di satu file JSON: log confirm / reject / transfer keluar."""
    def __init__(self, path, cap=5000):
        self.path, self.cap, self.lock = path, cap, threading.Lock()
        try:
            with open(path, encoding="utf-8") as f: self.rows = json.load(f)
        except Exception: self.rows = []
    def add(self, row):
        with self.lock:
            row = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), **row}
            self.rows.append(row)
            if len(self.rows) > self.cap: self.rows = self.rows[-self.cap:]
            self._save(); return row
    def has(self, key, val):
        with self.lock: return any(r.get(key) == val for r in self.rows)
    def view(self):
        with self.lock: return list(self.rows)
    def _save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f: json.dump(self.rows, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except Exception: pass
