"""MEGA GAMING - server lokal + pembuka jendela aplikasi. Hanya mendengarkan 127.0.0.1."""
import os, re, sys, json, time, secrets, threading, subprocess, socket, traceback, webbrowser
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import engine, updater
from engine import Engine, BASE, APP
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import urllib.request

PORT = int(os.environ.get("MEGA_PORT", "8765"))
TOKEN = secrets.token_urlsafe(16)
UI = os.path.join(APP, "ui")
ENG = Engine()
LAST_SEEN = [time.time()]
UPD = {"avail": False, "version": "", "notes": "", "msg": "", "busy": False, "checked": 0}
def upd_url(): return (ENG.cfg.get("update_url") or updater.DEFAULT_URL or "").strip()
def upd_check():
    r = updater.check(upd_url())
    UPD.update(avail=bool(r.get("avail")), version=r.get("version", ""), notes=r.get("notes", ""), msg=r.get("msg", ""), checked=time.time())
    return r
def upd_loop():
    time.sleep(8)
    while True:
        try: upd_check()
        except Exception: pass
        time.sleep(3600)
def upd_apply():
    UPD["busy"] = True
    try:
        r = updater.apply(upd_url())
        UPD["msg"] = r["msg"]
        if r["ok"]:
            ENG.log("INFO", "Pembaruan terpasang: " + r["msg"] + ". Memulai ulang")
            _halt(ENG); updater.restart(); time.sleep(.6); os._exit(0)
    except Exception as ex: UPD["msg"] = "gagal: " + str(ex)[:80]
    UPD["busy"] = False
BROWSER = {"proc": None}

def read(name, mode="rb"):
    with open(os.path.join(UI, name), mode) as f: return f.read()

def tg_action(name, d):
    e = ENG
    token = (d.get("token") or "").strip()
    if token.startswith("•"): token = e.cfg["telegram_token"]
    chat = (d.get("chat") or e.cfg["telegram_chat_id"]).strip()
    topic = (d.get("topic") if d.get("topic") is not None else e.cfg["telegram_topic_id"]).strip()
    if name == "tg_test":
        old = dict(e.cfg); e.cfg.update(telegram_token=token or old["telegram_token"], telegram_chat_id=chat, telegram_topic_id=topic)
        try: ok, why = e.deliver({"type": "INFO", "label": e.cfg["label"], "msg": "tes notifikasi MEGA GAMING"})
        finally: e.cfg = old
        return {"ok": ok, "msg": "Terkirim ke Telegram" if ok else "Gagal: " + why}
    if name == "tg_ids":
        r = e.tg_api("getUpdates", token=token or e.cfg["telegram_token"])
        if not r.get("ok"): return {"ok": False, "msg": "Gagal: " + str(r.get("description"))}
        seen = {}
        for u in r.get("result", []):
            m = u.get("message") or u.get("channel_post") or {}
            c = m.get("chat") or (u.get("my_chat_member") or {}).get("chat")
            if not c: continue
            tp = m.get("message_thread_id") if m.get("is_topic_message") else None
            seen[(c["id"], tp)] = c.get("title") or c.get("username") or c.get("first_name") or ""
        items = [{"chat": str(k[0]), "topic": str(k[1] or ""), "name": v} for k, v in seen.items()]
        return {"ok": bool(items), "items": items, "msg": "" if items else "Belum ada pesan. Kirim 'halo' ke bot atau ke topik di grup, lalu coba lagi."}
    if name == "tg_topic":
        nm = (d.get("name") or e.cfg["label"] or "Deposit BCA")[:128]
        r = e.tg_api("createForumTopic", {"chat_id": chat, "name": nm}, token=token or e.cfg["telegram_token"])
        if r.get("ok"): return {"ok": True, "topic": str(r["result"]["message_thread_id"]), "msg": f'Topik "{nm}" dibuat'}
        return {"ok": False, "msg": "Gagal: " + str(r.get("description")) + " (grup harus supergroup dengan Topics aktif, bot admin dengan izin Manage Topics)"}

def _halt(e):
    """Hentikan pemantauan dan tunggu siklus yang sedang jalan selesai, supaya tidak menulis ke folder website lain."""
    e.stop()
    t = getattr(e, "thread", None)
    if t and t.is_alive() and t is not threading.current_thread(): t.join(timeout=30)

def do_action(name, d):
    global ENG
    e = ENG
    if name == "update_check":
        r = upd_check(); return {"ok": r["ok"], "avail": r.get("avail", False), "msg": r.get("msg", "")}
    if name == "update_apply":
        if UPD["busy"]: return {"ok": True}
        if not UPD["avail"]: return {"ok": False, "msg": "belum ada versi baru"}
        threading.Thread(target=upd_apply, daemon=True).start(); return {"ok": True}
    if name == "profile_switch":
        nm = str(d.get("name", "")).strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]{2,30}", nm): return {"ok": False, "msg": "nama website tidak valid"}
        _halt(e); engine.set_profile(nm); ENG = Engine(); ENG.log("INFO", "Masuk ke website " + nm)
        c = ENG.cfg
        if c["autostart"] == "1" and c["serial"] and ENG.tg_ready(): ENG.start()
        return {"ok": True}
    if name == "profile_exit":
        _halt(e); engine.set_profile(None); ENG = Engine(); return {"ok": True}
    if name == "start": e.start(); return {"ok": True}
    if name == "stop": e.stop(); return {"ok": True}
    if name == "pause": e.toggle_pause(); return {"ok": True}
    if name == "check_now": e.check_now(); return {"ok": True}
    if name == "save_config": e.set_config(d); return {"ok": True}
    if name == "devices": return {"ok": True, "devices": e.devices(), "serial": e.cfg["serial"]}
    if name == "wizard_wifi": return e.wizard_wifi(d.get("ip", ""))
    if name == "wizard_usb": return e.wizard_usb()
    if name == "logout": return e.logout_mybca()
    if name == "sheet_test": return e.sheet_test(d.get("url", ""), d.get("secret", ""))
    if name == "buku_delete": return {"ok": True, "n": ENG.ledger.delete(ids=d.get("ids"), day=d.get("day"))}
    if name == "buku_edit": return {"ok": ENG.ledger.edit(d.get("id"), d.get("field"), d.get("value"))}
    if name == "lock_check": return {"ok": e.lock_check(d.get("user", ""), d.get("pw", ""))}
    if name == "test_connect": return e.test_connect()
    if name == "compat": return e.compat()
    if name == "flush": return {"ok": True, "sent": e.flush_pending()}
    if name == "clear_log": e.logs.clear(); return {"ok": True}
    if name in ("tg_test", "tg_ids", "tg_topic"): return tg_action(name, d)
    if name == "quit":
        e.stop(); threading.Timer(.4, lambda: os._exit(0)).start(); return {"ok": True}
    return {"ok": False, "msg": "aksi tidak dikenal"}

class H(BaseHTTPRequestHandler):
    server_version = "MEGA"
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json", extra=None):
        if isinstance(body, str): body = body.encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items(): self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)
    def _host_ok(self):
        return (self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost"))
    def _auth(self, q):
        return self.headers.get("X-Mega") == TOKEN or (q.get("k") or [""])[0] == TOKEN
    def do_GET(self):
        u = urlparse(self.path); q = parse_qs(u.query)
        if not self._host_ok(): return self._send(403, "x", "text/plain")
        if u.path == "/":
            html = open(os.path.join(UI, "index.html"), encoding="utf-8").read().replace("__TOKEN__", TOKEN)
            return self._send(200, html, "text/html; charset=utf-8")
        if u.path == "/logo.svg": return self._send(200, read("logo.svg"), "image/svg+xml")
        if u.path == "/icon.png": return self._send(200, read("icon.png"), "image/png")
        if u.path == "/icon.ico": return self._send(200, open(os.path.join(APP, "icon.ico"), "rb").read(), "image/x-icon")
        if u.path == "/api/ping": return self._send(200, json.dumps({"app": "mega-gaming"}))
        if u.path == "/bo": return self._send(200, json.dumps({"ok": True, "info": "MEGA GAMING buku siap"}))
        if not self._auth(q): return self._send(403, json.dumps({"ok": False}))
        LAST_SEEN[0] = time.time()
        if u.path == "/api/buku": return self._send(200, json.dumps({"rows": ENG.ledger.view(), "bo_url": f"http://127.0.0.1:{PORT}/bo", "bo_secret": ENG.cfg.get("bo_secret", "")}, ensure_ascii=False))
        if u.path == "/api/log":
            k = (q.get("kind") or [""])[0]
            rows = [r for r in ENG.act.view() if r.get("kind") == k] if k in ("confirm", "reject") else (ENG.out.view() if k == "out" else [])
            return self._send(200, json.dumps({"rows": rows[-1500:]}, ensure_ascii=False))
        if u.path == "/api/state": return self._send(200, json.dumps({**ENG.state(), "update": UPD}, ensure_ascii=False))
        if u.path == "/api/export.csv":
            try: data = open(engine.CSV_FILE, "rb").read()
            except OSError: data = b"id,seen_at,date,type,amount,name,raw\n"
            return self._send(200, data, "text/csv; charset=utf-8", {"Content-Disposition": 'attachment; filename="riwayat-deposit.csv"'})
        return self._send(404, "{}")
    def do_POST(self):
        u = urlparse(self.path)
        if u.path == "/bo":                                         # dari script BO (Tampermonkey), pakai kode rahasia sendiri
            if not self._host_ok(): return self._send(403, json.dumps({"ok": False}))
            try:
                n = int(self.headers.get("Content-Length") or 0)
                return self._send(200, json.dumps(ENG.bo_post(json.loads(self.rfile.read(n) or b"{}")), ensure_ascii=False))
            except Exception as ex: return self._send(200, json.dumps({"ok": False, "error": str(ex)[:120]}))
        if not self._host_ok() or not self._auth({}): return self._send(403, json.dumps({"ok": False}))
        if not u.path.startswith("/api/"): return self._send(404, "{}")
        try:
            n = int(self.headers.get("Content-Length") or 0); d = json.loads(self.rfile.read(n) or b"{}")
            LAST_SEEN[0] = time.time()
            r = do_action(u.path[5:], d)
        except Exception as ex:
            ENG.log("ERR", "Aksi gagal: " + str(ex)[:120]); r = {"ok": False, "msg": str(ex)[:160]}
        self._send(200, json.dumps(r, ensure_ascii=False))

def already_running():
    try: return json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/ping", timeout=1.5).read()).get("app") == "mega-gaming"
    except Exception: return False

def find_browser():
    pf = [os.environ.get(k, "") for k in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData")]
    for base in pf:
        for rel in (r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"):
            p = os.path.join(base, rel)
            if base and os.path.exists(p): return p
    return None

def open_window(port):
    url = f"http://127.0.0.1:{port}/"
    if os.environ.get("NO_BROWSER"): return None
    exe = find_browser()
    if not exe:
        webbrowser.open(url); return None
    prof = os.path.join(APP, "profile")
    try:
        return subprocess.Popen([exe, f"--app={url}", "--window-size=1240,840", f"--user-data-dir={prof}", "--no-first-run",
                                 "--no-default-browser-check", "--disable-features=Translate,msEdgeHubApp"])
    except Exception:
        webbrowser.open(url); return None

def brand_window():
    """Windows: beri jendela identitas aplikasi sendiri (ikon + nama MEGA GAMING di taskbar, bukan Chrome)."""
    if os.name != "nt": return
    try:
        import ctypes
        from ctypes import wintypes as W
        u32 = ctypes.windll.user32; sh = ctypes.windll.shell32; ole = ctypes.windll.ole32
        class GUID(ctypes.Structure): _fields_ = [("a", ctypes.c_ulong), ("b", ctypes.c_ushort), ("c", ctypes.c_ushort), ("d", ctypes.c_ubyte * 8)]
        def guid(t):
            import uuid; u = uuid.UUID(t); return GUID(u.time_low, u.time_mid, u.time_hi_version, (ctypes.c_ubyte * 8)(*u.bytes[8:]))
        class PKEY(ctypes.Structure): _fields_ = [("fmtid", GUID), ("pid", ctypes.c_ulong)]
        class PV(ctypes.Structure): _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort), ("r3", ctypes.c_ushort), ("p", ctypes.c_void_p), ("q", ctypes.c_void_p)]
        fm = guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3")
        bat = os.path.abspath(os.path.join(APP, "..", "MEGA-GAMING.bat")); ico = os.path.join(APP, "icon.ico")
        vals = [(5, "MegaGaming.App"), (2, '"%s"' % bat), (3, ico + ",0"), (4, "MEGA GAMING")]
        sh.SHGetPropertyStoreForWindow.argtypes = [W.HWND, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
        found = []
        EP = ctypes.WINFUNCTYPE(W.BOOL, W.HWND, W.LPARAM)
        def cb(h, l):
            if u32.IsWindowVisible(h):
                b = ctypes.create_unicode_buffer(256); u32.GetWindowTextW(h, b, 256)
                if b.value.strip() == "MEGA GAMING": found.append(h)
            return True
        for _ in range(40):
            found.clear(); u32.EnumWindows(EP(cb), 0)
            if found: break
            time.sleep(0.5)
        for h in found:
            iid = guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"); pp = ctypes.c_void_p()
            if sh.SHGetPropertyStoreForWindow(h, ctypes.byref(iid), ctypes.byref(pp)) != 0: continue
            vt = ctypes.cast(ctypes.cast(pp, ctypes.POINTER(ctypes.c_void_p))[0], ctypes.POINTER(ctypes.c_void_p))
            SetValue = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p, ctypes.POINTER(PKEY), ctypes.POINTER(PV))(vt[6])
            Commit = ctypes.WINFUNCTYPE(ctypes.HRESULT, ctypes.c_void_p)(vt[7])
            Release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vt[2])
            for pid, v in vals:
                buf = ctypes.create_unicode_buffer(v); n = ctypes.sizeof(buf)
                ole.CoTaskMemAlloc.restype = ctypes.c_void_p; ole.CoTaskMemAlloc.argtypes = [ctypes.c_size_t]
                mem = ole.CoTaskMemAlloc(n); ctypes.memmove(mem, buf, n)
                pv = PV(); pv.vt = 31; pv.p = mem
                SetValue(pp, ctypes.byref(PKEY(fm, pid)), ctypes.byref(pv))
            Commit(pp); Release(pp)
    except Exception:
        try:
            with open(os.path.join(BASE, "error.log"), "a", encoding="utf-8") as f: f.write(time.strftime("%F %T ") + "brand_window: " + traceback.format_exc() + "\n")
        except Exception: pass

def watchdog():
    started = time.time()
    while True:
        time.sleep(3)
        p = BROWSER["proc"]
        if p is not None and p.poll() is not None:
            if time.time() - started < 20: BROWSER["proc"] = None     # peluncur Edge langsung keluar (serah-terima) -> pakai detak jantung saja
            else: os._exit(0)                                         # jendela ditutup -> aplikasi selesai
        if time.time() - LAST_SEEN[0] > 150: os._exit(0)  # tidak ada jendela yang membuka lagi

def main():
    global PORT
    if already_running():
        open_window(PORT); return
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    except OSError:
        s = socket.socket(); s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]; s.close()
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    BROWSER["proc"] = None if os.environ.get("MEGA_RESTART") else open_window(PORT)      # setelah pembaruan, jendela lama memuat ulang sendiri
    threading.Thread(target=brand_window, daemon=True).start()
    threading.Thread(target=upd_loop, daemon=True).start()
    watchdog()

if __name__ == "__main__":
    try: main()
    except Exception:
        with open(os.path.join(BASE, "error.log"), "a", encoding="utf-8") as f: f.write(time.strftime("%F %T ") + traceback.format_exc() + "\n")
