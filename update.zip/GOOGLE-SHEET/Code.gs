// MEGA GAMING -> Google Sheet. Tempel seluruh isi file ini di Extensions > Apps Script.
// GANTI kode rahasia di bawah (sama persis dengan yang diisi di Pengaturan aplikasi).
//
// - Tiap rekening punya TAB sendiri bernama sesuai "Nama rekening" di aplikasi (misal VIP555).
// - Satu tab terus menyambung. Setiap ganti hari ditambah baris pemisah gelap.
// - Kolom dibuat sama dengan buku hitungan: Jenis | Jam | Nama | User ID | Nominal | Deposit ID.
//   Nominal berupa teks 150.000 (titik ribuan). User ID dan Deposit ID dikosongkan untuk diisi sendiri. Kolom G (Status) dan H (ID, disembunyikan) tambahan.
// - Saldo semua rekening masuk ke tab "Saldo".
const SECRET = 'GANTI-KODE-RAHASIA';

const DEP_HEAD = ['Jenis', 'Jam', 'Nama', 'User ID', 'Nominal', 'Deposit ID', 'Status', 'ID'];
const SALDO_HEAD = ['Waktu', 'Label', 'Saldo', 'Perubahan', 'Deposit tercatat', 'Keluar / lain'];
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

function tab_(name, head, hideLast) {
  const ss = SpreadsheetApp.getActive();
  let s = ss.getSheetByName(name);
  if (!s) s = ss.insertSheet(name);
  if (s.getLastRow() === 0) {
    s.appendRow(head);
    s.setFrozenRows(1);
    s.getRange(1, 1, 1, head.length).setFontWeight('bold').setHorizontalAlignment('center');
    if (hideLast) s.hideColumns(head.length);
  }
  return s;
}

function tabName_(label) {
  const n = String(label || '').replace(/[\[\]\*\?\:\/\\]/g, ' ').trim().substring(0, 90);
  return n || 'Deposit';
}

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// "2026-10-20 02:19:29" -> {day: '2026-10-20', label: '20 Okt 2026', time: '02:19:29'}
function parts_(ts) {
  const m = String(ts).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2}:\d{2})/);
  if (!m) return { day: String(ts), label: String(ts), time: '' };
  return { day: m[1] + '-' + m[2] + '-' + m[3], label: parseInt(m[3], 10) + ' ' + BULAN[parseInt(m[2], 10) - 1] + ' ' + m[1], time: m[4] };
}

function rp_(n) {
  return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function separator_(s, label) {
  s.appendRow([label]);
  const r = s.getLastRow();
  s.getRange(r, 1, 1, DEP_HEAD.length).setBackground('#0b1620').setFontColor('#ffffff').setFontWeight('bold');
}


// ---- Isi User ID + Deposit ID dari BO (dikirim script Tampermonkey BO-ISI-ID) ----
function norm_(x) { return String(x || '').toUpperCase().replace(/[^A-Z ]/g, ' ').replace(/\s+/g, ' ').trim(); }

function lev_(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  let prev = [], cur = [];
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}

function sim_(a, b) {
  a = norm_(a); b = norm_(b);
  if (!a || !b) return 0;
  const joined = 1 - lev_(a.replace(/ /g, ''), b.replace(/ /g, '')) / Math.max(a.replace(/ /g, '').length, b.replace(/ /g, '').length);
  const ta = a.split(' '), tb = b.split(' ');
  let hit = 0;
  ta.forEach(function (t) { if (tb.some(function (u) { return u === t || (t.length > 3 && u.length > 3 && lev_(t, u) <= 1); })) hit++; });
  return Math.max(joined, hit / Math.max(ta.length, tb.length));
}

function statusFlags_(st) {
  st = String(st || '');
  return { pend: /PEND/i.test(st), uncertain: /\(cek\)/i.test(st), confirmed: /CONFIRMED/i.test(st) };
}

function match_(r) {
  const none = { ok: false };
  const s = SpreadsheetApp.getActive().getSheetByName(tabName_(r.label));
  if (!s || s.getLastRow() < 2) return none;
  const n = s.getLastRow() - 1;
  const rows = s.getRange(2, 1, n, 8).getValues();
  const want = String(r.txid);
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][5]) === want) {                      // sudah terisi sebelumnya
      const f = statusFlags_(rows[i][6]);
      return { ok: true, sure: !f.uncertain, pend: f.pend, confirmed: f.confirmed, sheetName: String(rows[i][2]) };
    }
  }
  const cand = [];
  for (let i = 0; i < rows.length; i++) {
    const x = rows[i];
    if (x[0] !== 'DP' || x[3] !== '' || x[5] !== '') continue;
    if (parseInt(String(x[4]).replace(/\D/g, ''), 10) !== Number(r.amount)) continue;
    cand.push({ i: i, score: sim_(x[2], r.name) });
  }
  if (!cand.length) return none;
  cand.sort(function (p, q) { return q.score - p.score || q.i - p.i; });
  const best = cand[0];
  const strong = best.score >= 0.5;
  if (!strong && cand.length !== 1) return none;           // nominal kembar dan nama tidak cocok: jangan menebak
  // "sure" (boleh auto confirm) hanya kalau nama cocok DAN tidak ada kandidat lain yang sama kuat
  const sure = strong && (cand.length === 1 || cand[1].score < 0.5);
  const row = best.i + 2;
  const f = statusFlags_(rows[best.i][6]);
  s.getRange(row, 4).setValue(r.user);
  s.getRange(row, 6).setNumberFormat('@').setValue(want);
  if (!strong) s.getRange(row, 7).setValue(String(rows[best.i][6]) + ' (cek)');
  return { ok: true, sure: sure, pend: f.pend, confirmed: false, sheetName: String(rows[best.i][2]) };
}

function markConfirmed_(r) {
  const s = SpreadsheetApp.getActive().getSheetByName(tabName_(r.label));
  if (!s || s.getLastRow() < 2) return false;
  const rows = s.getRange(2, 1, s.getLastRow() - 1, 8).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][5]) === String(r.txid)) {
      if (!/CONFIRMED/i.test(String(rows[i][6]))) s.getRange(i + 2, 7).setValue(String(rows[i][6]) + ' | CONFIRMED');
      return true;
    }
  }
  return false;
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const b = JSON.parse(e.postData.contents);
    if (b.secret !== SECRET) return out_({ ok: false, error: 'kode rahasia salah' });
    const props = PropertiesService.getScriptProperties();
    const seen = {};   // id yang sudah ada per tab
    let added = 0;
    const results = [];
    (b.rows || []).forEach(function (r) {
      if (r.kind === 'deposit') {
        const name = tabName_(r.label);
        const s = tab_(name, DEP_HEAD, true);
        if (!seen[name]) seen[name] = s.getLastRow() > 1 ? s.getRange(2, 8, s.getLastRow() - 1, 1).getValues().map(function (x) { return String(x[0]); }) : [];
        const key = 'id:' + r.id;
        if (seen[name].indexOf(key) >= 0) return;
        const p = parts_(r.ts);
        const pk = 'day:' + name;
        if (props.getProperty(pk) !== p.day) { separator_(s, p.label); props.setProperty(pk, p.day); }
        s.appendRow(['DP', p.time, r.name, '', '', '', r.status, key]);
        // Nominal ditulis sebagai TEKS berformat titik ribuan (150.000) supaya bisa langsung disalin ke buku hitungan
        s.getRange(s.getLastRow(), 5).setNumberFormat('@').setValue(rp_(r.amount)).setHorizontalAlignment('right');
        seen[name].push(key); added++;
      } else if (r.kind === 'match') {
        const res = match_(r);
        results.push({ txid: r.txid, matched: res.ok, sure: !!res.sure, pend: !!res.pend, confirmed: !!res.confirmed, sheetName: res.sheetName || '' });
        if (res.ok) added++;
      } else if (r.kind === 'confirmed') {
        results.push({ txid: r.txid, marked: markConfirmed_(r) });
      } else if (r.kind === 'saldo') {
        tab_('Saldo', SALDO_HEAD, false).appendRow([r.ts, r.label, Number(r.amount), r.delta === '' ? '' : Number(r.delta), Number(r.dep || 0), r.other === '' ? '' : Number(r.other)]);
        added++;
      }
    });
    return out_({ ok: true, added: added, results: results });
  } catch (err) {
    return out_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function doGet() { return out_({ ok: true, info: 'MEGA GAMING sheet siap' }); }
