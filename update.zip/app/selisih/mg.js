/* MEGA OFFICE: hubungan halaman Cari Selisih dengan aplikasi induk.
   - warna ikut tema aplikasi
   - mode Simple / Detail (Simple = satu baris per temuan, alasan lewat "Why?")
   - ringkasan hasil dikirim ke Home (selisih -> ketemu -> sisa)
   - aktivitas di sini mencegah kunci layar otomatis */
(function () {
  var W = window.parent !== window ? window.parent : null, P = null;
  try { P = W ? W.document.documentElement : null; } catch (e) { P = null; }
  if (P) {
    var MAP = { '--ink': '--ink', '--muted': '--ink-muted', '--accent': '--accent', '--accent-soft': '--accent-soft', '--bad': '--danger', '--bad-soft': '--danger-soft',
      '--warn': '--warn', '--warn-soft': '--warn-soft', '--good': '--ok', '--good-soft': '--ok-soft', '--surface': '--glass-hi', '--line': '--edge-soft', '--strong': '--edge-strong' };
    var sync = function () {
      var cs = W.getComputedStyle(P), st = document.documentElement.style;
      for (var k in MAP) { var v = cs.getPropertyValue(MAP[k]).trim(); if (v) st.setProperty(k, v); }
      st.setProperty('--bg', 'transparent'); st.colorScheme = cs.colorScheme || 'normal';
      var md = P.getAttribute('data-mode'); if (md) document.documentElement.setAttribute('data-mode', md); else document.documentElement.removeAttribute('data-mode');
    };
    sync();
    try { new MutationObserver(sync).observe(P, { attributes: true, attributeFilter: ['data-theme', 'data-mode'] }); } catch (e) {}
    ['mousemove', 'mousedown', 'keydown', 'wheel'].forEach(function (ev) { document.addEventListener(ev, function () { try { W.officeBump && W.officeBump(); } catch (e) {} }, { passive: true }); });
  }
  var web = new URLSearchParams(location.search).get('w');
  var MODE = 'simple'; try { MODE = localStorage.getItem('cs_mode') || 'simple'; } catch (e) {}
  function num(t) { var s = String(t || '').replace(/[−–]/g, '-').replace(/[^\d,.\-]/g, '').replace(/\./g, '').replace(',', '.'); var n = parseFloat(s); return isNaN(n) ? null : n; }
  var lastKey = '';
  function decorate() {
    var res = document.getElementById('result'); if (!res) return;
    document.body.classList.toggle('simple', MODE === 'simple');
    var lh = res.querySelector('.list-head');
    if (lh && !lh.querySelector('.mode-seg')) {
      var copy = lh.querySelector('#copyList'); var box = document.createElement('div'); box.className = 'tools';
      box.innerHTML = '<div class="mode-seg" role="group" aria-label="Tampilan"><button type="button" data-m="simple">Simple</button><button type="button" data-m="detail">Detail</button></div>';
      if (copy) { copy.textContent = 'Copy for chat'; box.appendChild(copy); }
      lh.appendChild(box);
    }
    res.querySelectorAll('.mode-seg button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-m') === MODE); });
    res.querySelectorAll('.fd').forEach(function (fd) {
      if (fd.querySelector('.why') || !(fd.querySelector('.fd-story') || fd.querySelector('.fd-ev'))) return;
      var head = fd.querySelector('.fd-head'); if (!head) return;
      var b = document.createElement('button'); b.type = 'button'; b.className = 'why'; b.textContent = 'Why?'; head.appendChild(b);
    });
    // kirim ringkasan ke Home (bukan contoh, sekali per hasil)
    var sum = res.querySelector('.summary');
    if (sum && !res.querySelector('.example') && W && W.officeSelisih) {
      var bigs = sum.querySelectorAll('.big'); var day = (document.getElementById('closeDay') || {}).value || '';
      if (bigs.length >= 3 && /^\d{4}-\d{2}-\d{2}$/.test(day)) {
        var d = { day: day, selisih: num(bigs[0].textContent), ketemu: num(bigs[1].textContent), sisa: num(bigs[2].textContent), n: res.querySelectorAll('.fd').length };
        var key = JSON.stringify(d);
        if (key !== lastKey) { lastKey = key; try { W.officeSelisih(d); } catch (e) {} }
      }
    }
  }
  document.addEventListener('click', function (e) {
    var m = e.target.closest && e.target.closest('.mode-seg button');
    if (m) { MODE = m.getAttribute('data-m'); try { localStorage.setItem('cs_mode', MODE); } catch (x) {} decorate(); return; }
    var w = e.target.closest && e.target.closest('.why');
    if (w) { var fd = w.closest('.fd'); fd.classList.toggle('open'); w.textContent = fd.classList.contains('open') ? 'Hide' : 'Why?'; }
  });
  document.addEventListener('DOMContentLoaded', function () {
    var e = document.querySelector('.eyebrow'); if (e && web) e.textContent = 'Website ' + web.toUpperCase();
    var res = document.getElementById('result');
    if (res) new MutationObserver(function () { decorate(); }).observe(res, { childList: true, subtree: false });
    decorate();
  });
})();
