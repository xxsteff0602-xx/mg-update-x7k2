// JAGA RUMUS BUKU HITUNGAN (versi PER BUKU) - MEGA GAMING
// Punya banyak buku? Pakai JAGA-RUMUS-PUSAT.gs: satu script, dipasang sekali untuk semua buku. File ini untuk satu buku saja.
// Tempel seluruh isi file ini di BUKU HITUNGAN (bukan sheet deposit): Extensions > Apps Script > hapus isi editor >
// tempel > Simpan (ikon disket / Ctrl+S). TIDAK perlu Deploy. Berlaku untuk semua yang memakai buku itu.
//
// Masalah: saat baris dari aplikasi ditempel (Ctrl+V) misal ke kolom C..R, kolom di antaranya (D, F, H, ...) ikut
// tertimpa KOSONG, jadi rumus / isi di situ hilang. Itu perilaku Google Sheets (tempel tidak bisa melewati sel kosong).
// Script ini jalan otomatis setiap ada tempelan/ketikan: sel yang menjadi kosong diisi kembali dengan rumus yang sama
// seperti baris-baris lain di kolom itu (dicontoh dari baris di bawah/atasnya, referensi menyesuaikan baris).
// Kolom yang berisi data biasa (jam, user ID, nominal, nama) tidak disentuh.
//
// PENGATURAN (opsional)
var TAB = [];            // nama tab yang dijaga, misal ['BUKU', 'OKTOBER']. Kosong [] = semua tab.
var KOLOM_TETAP = [];    // kolom berisi teks/angka yang SAMA di tiap baris (bukan rumus), misal ['D']. Diisi ulang dari baris di dekatnya.
var LIHAT = 40;          // berapa baris di bawah/atas yang dilihat untuk mencari rumus contoh
//
// Kalau buku ini sudah punya function onEdit lain: ganti nama function onEdit di bawah menjadi jagaRumus,
// lalu di onEdit yang lama tambahkan baris  jagaRumus(e);

function onEdit(e) {
  try { jaga_(e); } catch (err) { /* jangan sampai mengganggu pengetikan */ }
}

function jaga_(e) {
  if (!e || !e.range) return;
  var r = e.range, sh = r.getSheet();
  if (TAB.length && TAB.indexOf(sh.getName()) < 0) return;
  var r0 = r.getRow(), n = r.getNumRows(), c0 = r.getColumn(), nc = r.getNumColumns();
  if (n > 1000 || nc > 60) return;                             // bukan tempelan baris buku
  if (n === 1 && nc === 1 && e.value !== undefined && e.value !== '') return;   // ketik satu sel berisi: tidak perlu dicek
  var vals = r.getValues(), fs = r.getFormulas();
  var kosong = {}, ada = false;
  for (var j = 0; j < nc; j++) {
    var b = [];
    for (var i = 0; i < n; i++) if (fs[i][j] === '' && (vals[i][j] === '' || vals[i][j] === null)) b.push(i);
    if (b.length) { kosong[j] = b; ada = true; }
  }
  if (!ada) return;
  var k = konteks_(sh, r0, n, c0, nc);
  var tetap = KOLOM_TETAP.map(colIdx_);
  for (var jj in kosong) {
    var j2 = Number(jj), c = c0 + j2, blanks = kosong[jj];
    var f = contohRumus_(k, j2);
    if (f) {
      runs_(blanks).forEach(function (x) { var arr = []; for (var q = 0; q < x[1]; q++) arr.push([f]); sh.getRange(r0 + x[0], c, x[1], 1).setFormulasR1C1(arr); });
      continue;
    }
    if (tetap.indexOf(c) >= 0) {
      var v = contohNilai_(k, j2);
      if (v !== null) runs_(blanks).forEach(function (x) { sh.getRange(r0 + x[0], c, x[1], 1).setValue(v); });
    }
  }
}

// Baris-baris di bawah dan di atas rentang yang diedit (sekali baca untuk semua kolom)
function konteks_(sh, r0, n, c0, nc) {
  var maxRow = sh.getMaxRows(), below = r0 + n;
  var kb = below <= maxRow ? Math.min(LIHAT, maxRow - below + 1) : 0;
  var top = Math.max(1, r0 - LIHAT), ka = r0 - top;
  var rb = kb ? sh.getRange(below, c0, kb, nc) : null, ra = ka ? sh.getRange(top, c0, ka, nc) : null;
  return { rb: rb, ra: ra, fb: rb ? rb.getFormulasR1C1() : [], fa: ra ? ra.getFormulasR1C1() : [], vb: null, va: null, gb: null, ga: null };
}

// Rumus (R1C1) yang dipakai baris-baris terdekat di kolom ke-j, di luar baris yang baru diedit.
// Hanya kalau minimal 2 dari (maks) 6 rumus terdekat sama persis dan jadi mayoritas -> kolom ini memang kolom rumus per baris.
function contohRumus_(k, j) {
  var cand = [];
  for (var i = 0; i < k.fb.length; i++) if (k.fb[i][j]) cand.push({ d: i + 1, f: k.fb[i][j] });
  for (var i2 = k.fa.length - 1; i2 >= 0; i2--) if (k.fa[i2][j]) cand.push({ d: k.fa.length - i2, f: k.fa[i2][j] });
  if (cand.length < 2) return null;
  cand.sort(function (p, q) { return p.d - q.d; });
  cand = cand.slice(0, 6);
  var cnt = {}, best = null;
  cand.forEach(function (x) { cnt[x.f] = (cnt[x.f] || 0) + 1; if (!best || cnt[x.f] > cnt[best]) best = x.f; });
  return cnt[best] >= 2 && cnt[best] * 2 > cand.length ? best : null;
}

// Isi (bukan rumus) baris terdekat di kolom ke-j, untuk KOLOM_TETAP.
function contohNilai_(k, j) {
  if (k.rb) {
    if (!k.vb) { k.vb = k.rb.getValues(); k.gb = k.rb.getFormulas(); }
    for (var i = 0; i < k.vb.length; i++) if (k.vb[i][j] !== '' && !k.gb[i][j]) return k.vb[i][j];
  }
  if (k.ra) {
    if (!k.va) { k.va = k.ra.getValues(); k.ga = k.ra.getFormulas(); }
    for (var i2 = k.va.length - 1; i2 >= 0; i2--) if (k.va[i2][j] !== '' && !k.ga[i2][j]) return k.va[i2][j];
  }
  return null;
}

// [0,1,2,5,6] -> [[0,3],[5,2]]  (awal, panjang) supaya penulisan ke sheet sedikit panggilan
function runs_(idx) {
  var out = [];
  idx.forEach(function (i) { var last = out[out.length - 1]; if (last && last[0] + last[1] === i) last[1]++; else out.push([i, 1]); });
  return out;
}

function colIdx_(L) {
  var s = String(L || '').toUpperCase().replace(/[^A-Z]/g, ''), x = 0;
  for (var i = 0; i < s.length; i++) x = x * 26 + (s.charCodeAt(i) - 64);
  return x;
}
