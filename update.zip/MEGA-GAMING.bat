@echo off
cd /d "%~dp0"
call _cari_python.bat
if errorlevel 1 exit /b 1
if not exist "python\pythonw.exe" (
  echo pythonw.exe tidak ditemukan di folder python. Hapus folder python lalu jalankan ulang.
  pause
  exit /b 1
)
start "" "python\pythonw.exe" "app\server.py"
exit /b 0
