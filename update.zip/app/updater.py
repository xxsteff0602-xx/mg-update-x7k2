"""Pembaruan otomatis dari GitHub: cek version.json, unduh update.zip, cek sidik digital (sha256), pasang, mulai ulang.
Yang diganti hanya folder app/, GOOGLE-SHEET/ dan file .txt/.bat di folder utama. Data (config, profil, buku, csv) tidak disentuh."""
import os, io, sys, json, time, hashlib, zipfile, shutil, subprocess, urllib.request

APP = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(APP)
NOWIN = 0x08000000 if os.name == "nt" else 0
# Isi dengan alamat raw GitHub, misal https://raw.githubusercontent.com/USER/REPO/main  (bisa ditimpa lewat update_url di config.ini)
DEFAULT_URL = "https://raw.githubusercontent.com/xxsteff0602-xx/mg-update-x7k2/main"
ALLOW_DIRS = ("app/", "GOOGLE-SHEET/")
NEVER = ("config.ini", "adb.exe", "AdbWinApi.dll", "AdbWinUsbApi.dll")

def local_version():
    try: return open(os.path.join(APP, "VERSION"), encoding="utf-8").read().strip()
    except OSError: return "0"

def vtuple(v):
    out = []
    for p in str(v).strip().lstrip("vV").split("."):
        try: out.append(int(p))
        except ValueError: out.append(0)
    return tuple(out)

def _get(url, timeout=15, limit=60_000_000):
    req = urllib.request.Request(url, headers={"User-Agent": "MEGA-GAMING-updater", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit: raise RuntimeError("file pembaruan terlalu besar")
    return data

def _base(url):
    return str(url or "").strip().rstrip("/")

def check(base_url):
    """-> {ok, avail, version, notes, msg}"""
    base = _base(base_url)
    if not base: return {"ok": False, "avail": False, "msg": "alamat pembaruan belum diisi"}
    try:
        info = json.loads(_get(base + "/version.json?t=" + str(int(time.time())), timeout=10, limit=200_000).decode("utf-8"))
    except Exception as ex:
        return {"ok": False, "avail": False, "msg": "tidak bisa cek pembaruan: " + str(ex)[:80]}
    v = str(info.get("version", "")).strip()
    if not v: return {"ok": False, "avail": False, "msg": "version.json tidak valid"}
    return {"ok": True, "avail": vtuple(v) > vtuple(local_version()), "version": v, "notes": str(info.get("notes", ""))[:400], "msg": "", "info": info}

def _safe_target(name):
    name = name.replace("\\", "/")
    if name.startswith("/") or ".." in name.split("/") or ":" in name: return None
    base = os.path.basename(name)
    if base in NEVER or "__pycache__" in name or name.startswith("app/profile/") or name.endswith(".pyc"): return None
    if name.startswith(ALLOW_DIRS): return name
    if "/" not in name and name.lower().endswith((".txt", ".bat")): return name
    return None

def apply(base_url):
    """Unduh, cek sha256, pasang. Kembali {ok, msg}. Tidak memulai ulang (lihat restart())."""
    c = check(base_url)
    if not c["ok"]: return {"ok": False, "msg": c["msg"]}
    if not c["avail"]: return {"ok": False, "msg": "sudah versi terbaru"}
    info, base = c["info"], _base(base_url)
    zname, want = str(info.get("zip", "update.zip")), str(info.get("sha256", "")).lower()
    if not want or len(want) != 64: return {"ok": False, "msg": "sidik digital (sha256) tidak ada di version.json, pembaruan ditolak"}
    try: data = _get(base + "/" + zname.lstrip("/"), timeout=60)
    except Exception as ex: return {"ok": False, "msg": "gagal mengunduh: " + str(ex)[:80]}
    if hashlib.sha256(data).hexdigest() != want: return {"ok": False, "msg": "sidik digital tidak cocok, pembaruan ditolak"}
    try: zf = zipfile.ZipFile(io.BytesIO(data))
    except Exception: return {"ok": False, "msg": "file pembaruan rusak"}
    plan = []
    for n in zf.namelist():
        if n.endswith("/"): continue
        t = _safe_target(n)
        if t: plan.append((n, t))
    if not any(t == "app/server.py" for _, t in plan): return {"ok": False, "msg": "isi pembaruan tidak lengkap (app/server.py tidak ada)"}
    stamp = time.strftime("%Y%m%d-%H%M%S"); bk = os.path.join(BASE, "_cadangan", stamp)
    try:
        for n, t in plan:                                            # cadangkan file lama dulu, supaya bisa dikembalikan manual
            dst = os.path.join(BASE, *t.split("/"))
            if os.path.exists(dst):
                os.makedirs(os.path.dirname(os.path.join(bk, *t.split("/"))), exist_ok=True); shutil.copy2(dst, os.path.join(bk, *t.split("/")))
        for n, t in plan:
            dst = os.path.join(BASE, *t.split("/")); os.makedirs(os.path.dirname(dst), exist_ok=True)
            tmp = dst + ".new"
            with open(tmp, "wb") as f: f.write(zf.read(n))
            os.replace(tmp, dst)
    except Exception as ex:
        return {"ok": False, "msg": "gagal memasang: " + str(ex)[:80] + f" (cadangan di _cadangan/{stamp})"}
    try:                                                              # simpan hanya 3 cadangan terakhir
        root = os.path.join(BASE, "_cadangan")
        for d in sorted(os.listdir(root))[:-3]: shutil.rmtree(os.path.join(root, d), ignore_errors=True)
    except Exception: pass
    return {"ok": True, "msg": "terpasang v" + c["version"], "version": c["version"]}

def restart():
    """Nyalakan server baru setelah yang lama berhenti. Jendela yang sedang terbuka memuat ulang sendiri."""
    env = dict(os.environ, MEGA_RESTART="1")
    if os.name == "nt":
        py = os.path.join(BASE, "python", "pythonw.exe")
        if not os.path.exists(py): py = sys.executable
        # langsung jalankan python (tanpa cmd /c: tanda kutip di path bisa rusak). Server baru menunggu server lama mati sendiri.
        subprocess.Popen([py, os.path.join(APP, "server.py")], cwd=BASE, env=env, creationflags=0x00000008 | 0x00000200, close_fds=True)
    else:
        subprocess.Popen([sys.executable, os.path.join(APP, "server.py")], cwd=BASE, env=env, start_new_session=True)
