/* MEGA OFFICE - lapisan kantor di atas MEGA GAMING:
   login per staff (Pusat), kunci layar otomatis, sidebar, Home, Cari Selisih, menu Admin.
   Dimuat setelah script MEGA GAMING; fungsi lama (renderDock, renderTop, mount, poll, onState, lockGate, applyTheme) diganti di sini. */
(function(){
const OFFICE_ICON=()=>`<svg class="logo" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="mgi${++OFFICE_ICON.n}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#818CF8"/><stop offset="1" stop-color="#22D3EE"/></linearGradient></defs><rect x="2" y="2" width="60" height="60" rx="16" fill="#1B1B3A"/><path d="M17 45V20.5c0-1.2 1.4-1.8 2.3-1L32 31l12.7-11.5c.9-.8 2.3-.2 2.3 1V45" fill="none" stroke="url(#mgi${OFFICE_ICON.n})" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
OFFICE_ICON.n=0;
Object.assign(IC,{
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
 moon:'<path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z"/>',
 sbclose:'<rect x="3" y="4" width="18" height="16" rx="3"/><path d="M9 4v16M15.5 10l-2 2 2 2"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 bank:'<path d="M3 21h18M5 18V10M10 18V10M14 18V10M19 18V10M2 10l10-6 10 6z"/>',
 bell:'<path d="M6 8a6 6 0 1 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 21h4"/>',
 lock:'<rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>',
 key:'<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9M17 6l3 3"/>',
 out:'<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h11"/>',
 arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
 chev:'<path d="m9 6 6 6-6 6"/>',chevd:'<path d="m6 9 6 6 6-6"/>',
 users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.5-3.5 3-5.5 6.5-5.5s6 2 6.5 5.5"/><circle cx="17" cy="9" r="2.8"/><path d="M16.5 14.6c2.6.3 4.3 2 4.8 5"/>',
 hist:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.5"/>',
 eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 cloud:'<path d="M7 18a5 5 0 1 1 .9-9.9A6 6 0 0 1 19 10a4 4 0 0 1-1 8z"/>',
 grid:'<rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/>',
 card:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18"/>',
 coin:'<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
 globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
});
window.MO_K=K;                                         // dipakai halaman Cek Rekening (iframe) untuk memanggil /api/office_rekening
const APPS=[['selisih','Cari Selisih'],['rekening','Cek Rekening'],['coin','Cek Coin Error'],['deposit','Selisih Deposit QRIS (web)'],['depo','BCA Depo Auto']];
const APPN=k=>k==='depo'?'Depo Auto':(APPS.find(a=>a[0]===k)||[k,k])[1];
const OV={d:null,t:0};                  // data /api/office terakhir
const DEPO=['beranda','riwayat','buku','transfer','pengaturan','log','sambung','web'];
const ADM=['adm_users','adm_hist','adm_ann'];
const U=()=>OV.d&&OV.d.user;
const isAdmin=()=>!!U()&&U().role==='admin';
const can=a=>!!U()&&(isAdmin()||(U().apps||[]).includes(a));
const initials=n=>String(n||'?').replace(/[^A-Za-z0-9 ]/g,'').split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase()||'?';
const p2=n=>String(n).padStart(2,'0');
const fmtN=n=>{if(n==null||isNaN(n))return '–';const neg=n<0;const a=Math.abs(n);const s=a.toLocaleString('id-ID',{maximumFractionDigits:2});return (neg?'−':'')+s};
const AVC=['#6366F1','#06B6D4','#EC4899','#F59E0B','#10B981','#8B5CF6','#0EA5E9','#EF4444'];
const avc=n=>{let h=0;for(const c of String(n))h=(h*31+c.charCodeAt(0))>>>0;return AVC[h%AVC.length]};

/* ---------------- tema: selalu tampilan MEGA OFFICE ---------------- */
THEMES.length=0; THEMES.push(['office','MEGA OFFICE',['#EEF1FB','#4F46E5','#06B6D4']]);
window.applyTheme=function(){document.documentElement.setAttribute('data-theme','office');try{localStorage.setItem('mg_theme','office');const m=localStorage.getItem('mo_mode');if(m)document.documentElement.dataset.mode=m}catch(e){}};
applyTheme();
document.title='MEGA OFFICE';

/* ---------------- kerangka: pindahkan #app ke dalam #shell bersama sidebar ---------------- */
(function(){const app=$('#app');const sh=document.createElement('div');sh.id='shell';const sd=document.createElement('aside');sd.id='side';app.parentNode.insertBefore(sh,app);sh.appendChild(sd);sh.appendChild(app);})();

/* ---------------- data kantor ---------------- */
async function ovLoad(){
  try{const r=await fetch('/api/office',{headers:{'X-Mega':K}});OV.d=await r.json();OV.t=Date.now()}catch(e){}
  return OV.d;
}
window.officeSelisih=async function(x){                // dipanggil halaman Cari Selisih setelah hasil keluar
  const r=await api('office_selisih',x);if(r.ok){await ovLoad();if(view==='home')V.home.update(true)}
};

/* ---------------- gerbang: kode pusat, login, kunci layar, wajib ganti sandi ---------------- */
let GATE='',DD=false;                                   // DD = menu akun (kanan atas) sedang terbuka
function gate(kind){
  const el=$('#lock');
  if(!kind){if(GATE){GATE='';el.className='';el.style.cssText='display:none';el.innerHTML='';$('#shell').style.visibility='';}return}
  if(GATE===kind)return; GATE=kind; openDD(false);
  el.className='gate'; el.style.cssText='position:fixed;inset:0;z-index:99999;display:grid;place-items:center;overflow:auto;'+(kind==='lock'?'background:rgba(238,241,251,.45);-webkit-backdrop-filter:blur(26px);backdrop-filter:blur(26px)':'background:transparent');
  if(kind!=='lock')$('#shell').style.visibility='hidden'; else $('#shell').style.visibility='';
  const eye=`<button class="eye" type="button" data-act="oeye" aria-label="Lihat sandi">${ic('eye',18)}</button>`;
  let h='';
  if(kind==='code') h=`<div class="okard gcard"><div class="ghead">${OFFICE_ICON()}<h2>Hubungkan ke Pusat</h2><div class="omu">Sekali saja di PC ini. Tempel Kode Pusat dari admin.</div></div>
    <div class="ofld">Kode Pusat<div class="oinp ta"><textarea id="g_code" spellcheck="false" placeholder="MOP1.…"></textarea></div></div>
    <div id="g_err"></div><button class="obtn wide" data-act="ocode">Hubungkan ${ic('arrow',16,2).replace('<svg','<svg class="go"')}</button>
    <div class="gsmall">Admin: buka Google Sheet Pusat → menu MEGA OFFICE → Tampilkan Kode Pusat.</div></div>`;
  if(kind==='login') h=`<div class="okard gcard"><div class="ghead">${OFFICE_ICON()}<h2>MEGA OFFICE</h2><div class="omu">Sign in untuk mulai shift</div></div>
    <div class="ofld">Username<div class="oinp">${ic('users',18)}<input id="g_user" autocomplete="username" spellcheck="false"></div></div>
    <div class="ofld">Password<div class="oinp">${ic('lock',18)}<input id="g_pw" type="password" autocomplete="current-password">${eye}</div></div>
    <div id="g_err"></div><button class="obtn wide" data-act="ologin">Sign in ${ic('arrow',16,2).replace('<svg','<svg class="go"')}</button>
    <div class="gsmall">Lupa password? Hubungi admin untuk reset.</div></div>`;
  if(kind==='lock'){const u=U()||{};h=`<div class="okard gcard"><div class="ghead"><span class="oav bigav">${esc(initials(u.nama))}</span><h2>${esc(u.nama||'')}</h2><div class="omu">${ic('lock',15)} Layar terkunci. Masukkan password untuk lanjut.</div></div>
    <div class="ofld">Password<div class="oinp">${ic('lock',18)}<input id="g_pw" type="password" autocomplete="current-password">${eye}</div></div>
    <div id="g_err"></div><button class="obtn wide" data-act="ounlock">Unlock ${ic('arrow',16,2).replace('<svg','<svg class="go"')}</button>
    <div class="gsmall">Pekerjaan yang terbuka tetap aman di balik kunci.<br>Bukan ${esc(u.nama||'kamu')}? <b data-act="osignout">Sign out</b></div></div>`}
  if(kind==='pw') h=`<div class="okard gcard"><div class="ghead">${OFFICE_ICON()}<h2>Ganti sandi dulu</h2><div class="omu">Sandi dari admin hanya sementara. Buat sandi kamu sendiri (minimal 6 karakter).</div></div>
    ${pwFields()}<div id="g_err"></div><button class="obtn wide" data-act="opwsave" data-g="1">Simpan sandi baru</button>
    <div class="gsmall"><b data-act="osignout">Sign out</b></div></div>`;
  el.innerHTML=h;
  setTimeout(()=>{const f=el.querySelector('input,textarea');f&&f.focus()},60);
  el.onkeydown=e=>{if(e.key!=='Enter'||e.target.tagName==='TEXTAREA')return;const b=el.querySelector('.obtn');b&&b.click()};
}
const pwFields=()=>`<div class="ofld">Sandi sekarang<div class="oinp">${ic('lock',18)}<input id="p_old" type="password" autocomplete="current-password"></div></div>
  <div class="ofld">Sandi baru<div class="oinp">${ic('key',18)}<input id="p_new" type="password" autocomplete="new-password"></div></div>
  <div class="ofld">Ulangi sandi baru<div class="oinp">${ic('key',18)}<input id="p_new2" type="password" autocomplete="new-password"></div></div>`;
const gErr=(m,info)=>{const e=$('#g_err')||$('#m_err');if(e)e.innerHTML=m?`<div class="${info?'oinfo':'oerr'}">${ic('info',16)}${esc(m)}</div>`:''};

/* ---------------- kunci layar otomatis ---------------- */
let lastAct=Date.now();
const bump=()=>{lastAct=Date.now()};
['mousemove','mousedown','keydown','wheel','touchstart'].forEach(ev=>document.addEventListener(ev,bump,{passive:true}));
window.officeBump=bump;                                // dipanggil juga dari halaman Cari Selisih (iframe)
setInterval(async()=>{
  if(!U()||OV.d.locked||GATE)return;
  if(Date.now()-lastAct>(OV.d.idle_min||10)*60000){await api('office_lock');await ovLoad();applyGate();}
},15000);

/* ---------------- sidebar ---------------- */
// sidebar bisa disembunyikan (diingat di PC ini); Terang/Gelap, Lock, akun ada di kanan atas
(function(){try{if(localStorage.getItem('mo_sb')==='hide')document.body.classList.add('sbhide')}catch(e){}
  const b=document.createElement('button');b.id='sbshow';b.type='button';b.dataset.act='osbshow';b.title='Tampilkan menu';b.setAttribute('aria-label','Tampilkan menu');b.innerHTML=OFFICE_ICON();document.body.appendChild(b)})();
window.renderDock=function(){
  const sd=$('#side'); if(!sd)return;
  const u=U(); $('#shell').classList.toggle('nosb',!u);
  if(!u){sd.innerHTML='';renderTbar();return}
  const it=(v,l,icn,cls='')=>`<button class="ni ${cls} ${view===v?'on':''}" data-act="go" data-v="${v}">${icn?ic(icn,18):''}${l}</button>`;
  let h=`<div class="sb-brand">${OFFICE_ICON()}<div><b>MEGA OFFICE</b><small>${esc(u.username)} · ${esc((S&&S.profile)||u.website||(isAdmin()?'Admin':'-'))}</small></div><button class="sb-hide" data-act="osbhide" title="Sembunyikan menu" aria-label="Sembunyikan menu">${ic('sbclose',16)}</button></div>
   <div class="sb-sec">Menu</div>${it('home','Home','home')}`;
  if(can('selisih'))h+=it('selisih','Cari Selisih','search');
  if(can('rekening'))h+=it('rekening','Cek Rekening','card');
  if(can('coin'))h+=it('coin','Cek Coin Error','coin');
  if(can('depo')){h+=it('beranda','BCA Depo Auto','bank');
    if(DEPO.includes(view)&&view!=='web')h+=[['buku','Deposit'],['riwayat','Riwayat'],['transfer','Transfer'],['pengaturan','Pengaturan'],['log','Log']].map(([v,l])=>it(v,l,'','sub')).join('');}
  if(isAdmin())h+=`<div class="sb-sec">Admin</div>${it('adm_users','Akun staff','users')}${it('adm_hist','Riwayat masuk','hist')}${it('adm_ann','Pengumuman','bell')}`+(S&&S.profile?'':it('web','Pilih website','grid'));
  h+=`<div class="sb-grow"></div>${OV.d.offline?`<div class="offpill">${ic('cloud',15)}Offline mode</div>`:''}`;
  if(sig('side',h))sd.innerHTML=h;
  renderTbar();
};
// kanan atas: Terang/Gelap, Lock, profil (klik → menu akun berisi Info akun, Ganti username, Ganti sandi, Sign out)
const ROLE_TXT=u=>(u.role==='admin'?'Admin':'Staff')+' · Shift '+u.shift;
function renderTbar(){
  const u=U();let tb=$('#tbar');
  if(!u){if(tb)tb.remove();sigs.tbar=null;openDD(false);return}
  if(!tb){tb=document.createElement('div');tb.id='tbar';$('#shell').appendChild(tb)}
  const dk=document.documentElement.dataset.mode==='dark',mt=dk?'Tampilan terang':'Tampilan gelap';
  const h=`<button class="tb ic" data-act="omode" title="${mt}" aria-label="${mt}">${ic(dk?'sun':'moon',17)}</button><button class="tb ic" data-act="olock" title="Kunci layar (Lock)" aria-label="Kunci layar">${ic('lock',17)}</button><button class="tb me${DD?' on':''}" data-act="omenu" aria-haspopup="menu" aria-expanded="${DD}"><span class="oav">${esc(initials(u.nama))}</span><span class="tm"><b>${esc(u.nama)}</b><small>${esc(ROLE_TXT(u))}</small></span>${ic('chevd',15)}</button>`;
  if(sig('tbar',h))tb.innerHTML=h;
}
function openDD(on){
  DD=!!on&&!!U();let d=$('#dd');
  if(DD){const u=U();
    if(!d){d=document.createElement('div');d.id='dd';d.setAttribute('role','menu');$('#shell').appendChild(d)}
    d.innerHTML=`<div class="h"><b>${esc(u.nama)}</b><small>${esc(u.username)} · ${esc(ROLE_TXT(u))}</small></div>
     <button data-act="ome">${ic('info',17)}Info akun</button><button data-act="oun">${ic('users',17)}Ganti username</button><button data-act="opw">${ic('key',17)}Ganti sandi</button><hr>
     <button class="red" data-act="osignout">${ic('out',17)}Sign out</button>`}
  else if(d)d.remove();
  const m=$('#tbar .me');if(m){m.classList.toggle('on',DD);m.setAttribute('aria-expanded',String(DD))}
  sigs.tbar=null;
}
// menu akun tutup kalau klik di luar, pilih salah satu item, atau tekan Escape
document.addEventListener('click',e=>{if(!DD)return;const b=e.target.closest('[data-act]');if(b&&b.dataset.act==='omenu')return;if(b||!e.target.closest('#dd'))openDD(false)});
window.addEventListener('keydown',e=>{if(e.key==='Escape')openDD(false)});

/* ---------------- topbar: hanya di halaman BCA Depo Auto ---------------- */
const oldTop=renderTop;
window.renderTop=function(){
  const tb=$('#topbar');
  const show=!!U()&&DEPO.includes(view)&&view!=='web'&&S&&S.profile;
  tb.classList.toggle('hide',!show); if(!show)return;
  const hp=S.hp,tg=S.tg;let hpc,hpt;
  if(!S.cfg.serial&&hp.state!=='ok'){hpc='warn';hpt='HP belum diatur'}
  else if(hp.state==='down'){hpc='danger';hpt='HP putus'}
  else if(S.screen_warn){hpc='warn';hpt='myBCA tidak di layar Mutasi'}
  else {hpc=S.cfg.serial?'ok':'warn';hpt=S.cfg.serial?'HP <span class="num muted" style="font-weight:500">'+esc(S.cfg.serial)+'</span>':'HP belum diatur'}
  const col={ok:['var(--ok)','var(--ok-soft)'],warn:['var(--warn)','var(--warn-soft)'],danger:['var(--danger)','var(--danger-soft)']};
  const pill=(c,icon,t)=>`<span class="pill"><i style="color:${col[c][0]};background:${col[c][1]}">${ic(icon,14,2)}</i>${t}</span>`;
  const tgc=tg.ready?'ok':'warn',tgt=tg.ready?'Telegram':'Telegram belum diatur';
  const btn=S.running?`<button class="btn danger sm" data-act="stop">${ic('stop',16,2)}Stop</button>`:`<button class="btn primary sm" data-act="start">${ic('play',14,2)}Mulai</button>`;
  const h=`<div class="col" style="flex:none;white-space:nowrap;padding-left:6px"><span class="h" style="line-height:20px">BCA Depo Auto</span><span class="cap muted">${esc(S.profile||'')}</span></div>
  <div class="grow"></div>${pill(hpc,'phone',hpt)}${pill(tgc,'send',tgt)}${btn}${updBtn()}<button class="btn sm" data-act="wbo">${ic('link',15,2)}Buka BO</button>${isAdmin()?`<button class="btn sm" data-act="wexit">${ic('refresh',15,2)}Ganti Website</button>`:''}`;
  if(sig('top',h))tb.innerHTML=h;
};
window.lockGate=function(){};                          // kunci lama MEGA GAMING diganti login MEGA OFFICE

/* ---------------- mount / onState / poll ---------------- */
function rekShow(on){
  let w=$('#rekwrap');
  if(on&&!w){w=document.createElement('div');w.id='rekwrap';w.className='okard';w.innerHTML='<iframe id="rekframe" title="Cek Rekening" allow="clipboard-read; clipboard-write"></iframe>';$('#app').appendChild(w)}
  if(w){const f=$('#rekframe');if(on&&!f.getAttribute('src'))f.src='/rekening/';w.style.display=on?'flex':'none'}
}
function coinShow(on){
  let w=$('#coinwrap');
  if(on&&!w){w=document.createElement('div');w.id='coinwrap';w.className='okard';w.innerHTML='<iframe id="coinframe" title="Cek Coin Error" allow="clipboard-write"></iframe>';$('#app').appendChild(w)}
  if(w){const f=$('#coinframe');if(on&&!f.getAttribute('src'))f.src='/coin/';w.style.display=on?'flex':'none'}
}
function selisihShow(on){
  let w=$('#selwrap');
  if(on&&!w){w=document.createElement('div');w.id='selwrap';w.className='okard';w.innerHTML='<iframe id="selframe" title="Cari Selisih" allow="clipboard-write"></iframe>';$('#app').appendChild(w)}
  if(w){const f=$('#selframe'),p=(S&&S.profile)||'';
    if(on&&(!f.getAttribute('src')||selisihShow.p!==p)){selisihShow.p=p;f.src='/selisih/page.html?w='+encodeURIComponent(p)}
    w.style.display=on?'flex':'none'}
  $('#view').style.display=on?'none':'';
}
function allowed(v){
  if(v==='selisih'||v==='rekening')return can(v);
  if(v==='coin')return can('coin');
  if(DEPO.includes(v))return v==='web'?isAdmin():can('depo');
  if(ADM.includes(v))return isAdmin();
  return v==='home';
}
window.mount=function(){
  if(!U()){renderDock();return}
  if(!allowed(view)){view='home';history.replaceState(null,'','#home')}
  if(DEPO.includes(view)&&view!=='web'&&!(S&&S.profile)){view=isAdmin()?'web':'home';history.replaceState(null,'','#'+view)}
  document.body.dataset.view=view; renderDock(); renderTop();
  const sel=view==='selisih',rek=view==='rekening',coin=view==='coin'; selisihShow(sel); rekShow(rek); coinShow(coin); $('#view').style.display=(sel||rek||coin)?'none':''; if(sel||rek||coin){$('#view').innerHTML='';return}
  const v=V[view]||V.home; $('#view').innerHTML=v.mount(); if(S||!DEPO.includes(view))v.update&&v.update(true); window.scrollTo(0,0);
};
window.onState=function(){
  applyTheme();
  if(!U())return;
  if(S&&!S.profile&&DEPO.includes(view)&&view!=='web'&&isAdmin()){view='web';history.replaceState(null,'','#web');mount()}
  else if(S&&S.profile&&view==='web'){view='beranda';history.replaceState(null,'','#beranda');mount()}
  if(view==='beranda'&&S&&S.needs_setup&&!onState.once){onState.once=true;go('sambung');return}
  renderTop(); renderDock(); tfBanner(); const v=V[view]; v&&v.update&&v.update(false);
};
function applyGate(){
  const d=OV.d;
  if(!d){return}
  if(!d.pusat&&!d.user){gate('code');return}
  if(!d.user){gate('login');return}
  if(d.locked){gate('lock');return}
  if(d.user.wajib_ganti&&!d.offline){gate('pw');return}
  if(GATE){gate('');sigs={};mount()}
}
window.poll=async function(){
  if(Date.now()-OV.t>2500||!OV.d){await ovLoad();applyGate()}
  if(U()&&!OV.d.locked&&!GATE){
    try{const r=await fetch('/api/state',{headers:{'X-Mega':K}});if(r.ok){S=await r.json();S._t=Date.now();onState()}else{await ovLoad();applyGate()}}catch(e){}
  }
  setTimeout(poll,1000);
};
window.reloadState=async function(){try{const r=await fetch('/api/state',{headers:{'X-Mega':K}});if(r.ok){S=await r.json();S._t=Date.now()}}catch(e){}};
/* tombol MEGA GAMING lama "Keluar" = Sign out */
A.wlogout=()=>A.osignout();

/* ---------------- Home ---------------- */
function shiftInfo(now){
  const u=U()||{};const pagi=(u.shift||'pagi')!=='malam';
  const m=now.getHours()*60+now.getMinutes()+now.getSeconds()/60;
  const S0=pagi?450:1170,len=720;                      // 07:30 / 19:30, 12 jam
  let el=(m-S0+1440)%1440;
  // jam shift dalam WIB, ditampilkan juga dalam jam Armenia
  const dz=tzDiff(),amT=hm=>{const q=hm.split(':').map(Number),t=((q[0]*60+q[1]-dz)%1440+1440)%1440;return p2(Math.floor(t/60))+':'+p2(t%60)};
  const w=pagi?['07:30','10:30','13:30','16:30','19:30']:['19:30','22:30','01:30','04:30','07:30'];
  const name=(pagi?'Shift pagi':'Shift malam')+', '+w[0]+' – '+w[4]+' WIB · '+amT(w[0])+' – '+amT(w[4])+' Armenia';
  const ticks=w.map((x,i)=>i===0?'<b>'+x+' <small>WIB</small></b><i>'+amT(x)+' Armenia</i>':i===4?'<b>'+x+' ganti shift</b><i>'+amT(x)+'</i>':'<b>'+x+'</b><i>'+amT(x)+'</i>');
  if(el<len){const left=len-el;return {name,ticks,pct:el/len*100,title:'Checkout in '+Math.floor(left/60)+'j '+p2(Math.floor(left%60))+'m '+p2(Math.floor(left*60%60))+'s',sub:Math.floor(el/len*100)+'% berjalan'}}
  const until=1440-el;
  if(until<=180)return {name,ticks,pct:0,title:'Shift mulai in '+Math.floor(until/60)+'j '+p2(Math.floor(until%60))+'m',sub:'belum mulai'};
  const over=el-len;return {name,ticks,pct:100,title:'Lewat checkout '+Math.floor(over/60)+'j '+p2(Math.floor(over%60))+'m',sub:'shift selesai'};
}
const greet=h=>h>=5&&h<12?'Good morning':h>=12&&h<18?'Good afternoon':'Good night';
const DAYS=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],MONS=['January','February','March','April','May','June','July','August','September','October','November','December'];
// jam Indonesia (WIB) + Armenia, dihitung dari zona waktu tetap (tidak ikut setelan jam PC/HP)
const TZ_ID='Asia/Jakarta',TZ_AM='Asia/Yerevan',_zf={};
function zoned(tz){
  try{const f=_zf[tz]||(_zf[tz]=new Intl.DateTimeFormat('en-US',{timeZone:tz,hourCycle:'h23',year:'numeric',month:'numeric',day:'numeric',hour:'numeric',minute:'numeric',second:'numeric',weekday:'short'}));
    const o={};f.formatToParts(new Date()).forEach(p=>o[p.type]=p.value);const wd=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(o.weekday);
    return {getHours:()=>(+o.hour)%24,getMinutes:()=>+o.minute,getSeconds:()=>+o.second,getDay:()=>wd,getDate:()=>+o.day,getMonth:()=>+o.month-1,getFullYear:()=>+o.year};
  }catch(e){return new Date()}
}
function tzDiff(){const a=zoned(TZ_ID),b=zoned(TZ_AM);return ((a.getHours()*60+a.getMinutes())-(b.getHours()*60+b.getMinutes())+1440)%1440}   // menit WIB - Armenia (180)
function tickHome(){
  if(view!=='home'||!$('#h_time'))return;
  const n=zoned(TZ_ID),am=zoned(TZ_AM);
  $('#h_greet').textContent=greet(n.getHours());
  $('#h_date').textContent=DAYS[n.getDay()]+', '+n.getDate()+' '+MONS[n.getMonth()]+' '+n.getFullYear()+' · WIB';
  $('#h_time').innerHTML=p2(n.getHours())+':'+p2(n.getMinutes())+'<small>:'+p2(n.getSeconds())+'</small>';
  const amx=' <span>'+DAYS[am.getDay()]+', '+am.getDate()+' '+MONS[am.getMonth()]+' '+am.getFullYear()+'</span>';
  if($('#h_am'))$('#h_am').innerHTML=p2(am.getHours())+':'+p2(am.getMinutes())+'<small>:'+p2(am.getSeconds())+'</small>'+amx;
  const s=shiftInfo(n);$('#h_shift').textContent=s.name;$('#h_pct').textContent=s.sub;$('#h_cd').textContent=s.title;
  $('#h_fill').style.width=s.pct+'%';$('#h_knob').style.left=s.pct+'%';
  const tk=s.ticks.map(x=>'<span>'+x+'</span>').join('');if($('#h_ticks').innerHTML!==tk)$('#h_ticks').innerHTML=tk;
}
setInterval(tickHome,1000);
function selisihCard(){
  const rows=(OV.d&&OV.d.selisih)||[];const last=rows[rows.length-1];
  const y=new Date(Date.now()-86400000);const yd=y.getFullYear()+'-'+p2(y.getMonth()+1)+'-'+p2(y.getDate());
  const done=rows.find(r=>r.day===yd);
  const dl=d=>{const p=d.split('-');return 'tgl '+(+p[2])};
  let chip=done?(Math.abs(done.sisa||0)<1000?`<span class="ost ok"><i></i>${dl(yd)} sudah dicek</span>`:`<span class="ost warn"><i></i>${dl(yd)} sisa ${fmtN(done.sisa)}</span>`):`<span class="ost bad"><i></i>${dl(yd)} belum dicek</span>`;
  const vals=rows.slice(-7);const mx=Math.max(1,...vals.map(r=>Math.abs(r.sisa||0)));
  let bars;
  if(vals.length){bars='<svg viewBox="0 0 240 96" width="240" height="96">'+vals.map((r,i)=>{const h=Math.max(8,Math.min(1,Math.abs(r.sisa||0)/mx)*86);const bad=Math.abs(r.sisa||0)>=1000;return `<rect class="obar${bad?' bad':(i===vals.length-1?' hi':'')}" x="${18+i*31}" y="${96-h}" width="20" height="${h}" rx="5"><title>${esc(dl(r.day))}: sisa ${fmtN(r.sisa)}</title></rect>`}).join('')+'</svg>'}
  else bars='<svg viewBox="0 0 240 96" width="240" height="96">'+[38,58,24,70,46,92,64].map((h,i)=>`<rect class="obar${i===5?' hi':''}" x="${18+i*31}" y="${96-h}" width="20" height="${h}" rx="5"/>`).join('')+'</svg>';
  return `<button class="okard oapp" data-act="go" data-v="selisih"><div class="opv">${bars}</div><div class="oab">${chip}<h3>Cari Selisih</h3><div class="odesc">Cocokkan buku dengan BO & qrishoki, langsung tunjuk baris yang bikin selisih.</div>
   <div class="ofoot"><span class="ometa">${last?`<span>Terakhir</span> ${esc(dl(last.day))}, sisa ${fmtN(last.sisa)}`:'<span>Belum ada hasil</span>'}</span><span class="obtn">Buka ${ic('arrow',16,2).replace('<svg','<svg class="go"')}</span></div></div></button>`;
}
function rekeningCard(){
  let H=[];try{H=JSON.parse(localStorage.getItem('cekrek_glass')||'[]').filter(h=>Date.now()-h.t<86400000)}catch(e){}
  const td=new Date().toDateString();const T=H.filter(h=>new Date(h.t).toDateString()===td);const ok=T.filter(h=>h.ok).length,bad=T.length-ok;
  const hr=new Array(12).fill(0);const now=Date.now();T.forEach(h=>{const i=11-Math.floor((now-h.t)/3600000);if(i>=0&&i<12)hr[i]++});const mx=Math.max(1,...hr);
  const bars='<svg viewBox="0 0 240 96" width="240" height="96">'+hr.map((v,i)=>{const h=Math.max(6,v/mx*86);return `<rect class="obar${i===11?' hi':''}" x="${12+i*19}" y="${96-h}" width="12" height="${h}" rx="4"/>`}).join('')+'</svg>';
  const web=OV.d&&OV.d.web;const chip=OV.d.offline?'<span class="ost warn"><i></i>Butuh internet</span>':web?'<span class="ost ok"><i></i>Online</span>':'<span class="ost warn"><i></i>Alamat web belum diatur</span>';
  return `<button class="okard oapp" data-act="go" data-v="rekening"><div class="opv">${bars}</div><div class="oab">${chip}<h3>Cek Rekening</h3><div class="odesc">Cek nama pemilik rekening bank & e-wallet. Ketik inisial, tempel nomor, langsung keluar.</div>
   <div class="ofoot"><span class="ometa"><span>Hari ini</span> ${T.length} cek, ${ok} valid${bad?', '+bad+' gagal':''}</span><span class="obtn">Buka ${ic('arrow',16,2).replace('<svg','<svg class="go"')}</span></div></div></button>`;
}
function depoCard(){
  const st=S||{};const t=st.today||{count:0,total:0};
  let chip;
  if(!st.profile)chip='<span class="ost mu"><i></i>Belum ada website</span>';
  else if(st.running&&st.hp&&st.hp.state==='down')chip='<span class="ost bad"><i></i>HP putus</span>';
  else if(st.running)chip=`<span class="ost ok"><i></i>${st.paused?'Dijeda':'Running'}</span>`;
  else chip='<span class="ost warn"><i></i>Belum dimulai</span>';
  const td=(st.events||[]).filter(e=>e.d===today());const hr=new Array(24).fill(0);
  td.forEach(e=>{const h=+String(e.seen_at||'').slice(11,13);if(!isNaN(h))hr[h]++});
  const now=new Date().getHours();const pts=[];for(let i=11;i>=0;i--)pts.push(hr[(now-i+24)%24]);
  const W=260,H=90,mx=Math.max(1,...pts),X=i=>10+(W-20)*i/11,Y=v=>H-10-(H-24)*v/mx;
  let d=`M${X(0)},${Y(pts[0])}`;for(let i=1;i<12;i++){const cx=(X(i-1)+X(i))/2;d+=` C${cx},${Y(pts[i-1])} ${cx},${Y(pts[i])} ${X(i)},${Y(pts[i])}`}
  const svg=`<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}"><defs><linearGradient id="hlg" x1="0" x2="1"><stop offset="0" stop-color="#6366F1"/><stop offset="1" stop-color="#06B6D4"/></linearGradient><linearGradient id="hlf" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#6366F1" stop-opacity=".22"/><stop offset="1" stop-color="#6366F1" stop-opacity="0"/></linearGradient></defs><path d="${d} L${X(11)},${H} L${X(0)},${H} Z" fill="url(#hlf)"/><path d="${d}" fill="none" stroke="url(#hlg)" stroke-width="2.6" stroke-linecap="round"/></svg>`;
  return `<button class="okard oapp" data-act="go" data-v="beranda"><div class="opv">${svg}</div><div class="oab">${chip}<h3>BCA Depo Auto</h3><div class="odesc">Catat deposit masuk myBCA otomatis ke Telegram dan buku.</div>
   <div class="ofoot"><span class="ometa"><span>Hari ini</span> ${t.count} deposit, Rp ${rp(t.total||0)}</span><span class="obtn">Buka ${ic('arrow',16,2).replace('<svg','<svg class="go"')}</span></div></div></button>`;
}
V.home={
 mount(){const u=U();return `<div class="ohome">
  <div><div class="ohi" id="h_greet">Good morning</div><h1 class="oh1">Welcome to MEGA OFFICE, ${esc(u.nama)}!</h1></div>
  <div class="orow"><div class="okard oclk"><div class="olbl">${ic('clock',16)}<span id="h_date"></span></div><div class="otrow"><div class="otime" id="h_time">--:--</div><span class="otz">WIB</span></div><div class="oam"><span class="otz am">Armenia</span><b id="h_am">--:--</b></div></div>
   <div class="okard ocd"><div class="ocdh"><span id="h_shift"></span><span id="h_pct"></span></div><div class="ocdt" id="h_cd"></div><div class="otrack"><div class="ofill" id="h_fill"></div><div class="oknob" id="h_knob"></div></div><div class="oticks" id="h_ticks"></div></div></div>
  <div class="oapps" id="h_apps"></div><div id="h_ann"></div></div>`},
 update(force){
  tickHome();
  const a=(can('selisih')?selisihCard():'')+(can('rekening')?rekeningCard():'')+(can('depo')?depoCard():'');
  if(sig('h_apps',[a]))$('#h_apps').innerHTML=a||'<div class="okard oempty">Belum ada aplikasi untuk akun ini. Hubungi admin.</div>';
  const n=OV.d.ann;const ah=n&&n.teks?`<div class="okard oann"><span class="ii">${ic('bell',17)}</span><div><b>${esc(n.oleh)}</b> <span class="omu" style="font-size:12.5px">${esc(n.waktu)}</span><div>${esc(n.teks)}</div></div></div>`:'';
  if(sig('h_ann',ah))$('#h_ann').innerHTML=ah;
 }};

/* ---------------- Admin ---------------- */
const AD={users:null,f:'all',sel:null,hist:null,hq:'',busy:false};
async function adUsers(){const r=await api('admin_users');if(r.ok)AD.users=r.users;else toast(r.msg||'Gagal memuat akun');return r.ok}
const SITE_NAMES=()=>SITES.map(s=>s[0]);
function drawer(){
  const u=AD.sel;if(!u)return `<div class="okard odrawer"><div class="oempty">Pilih akun di tabel untuk mengubah, atau tekan <b>Tambah akun</b>.</div></div>`;
  const isNew=!u.username;const apps=u.apps||[];
  const opt=SITE_NAMES().map(n=>`<option ${u.website===n?'selected':''}>${n}</option>`).join('');
  return `<div class="okard odrawer">
   ${isNew?'<b style="font-size:17px;font-weight:800">Akun baru</b>':`<div class="uc"><span class="uav" style="background:${avc(u.username)};width:42px;height:42px">${esc(initials(u.nama))}</span><div><b style="font-size:17px;font-weight:800">${esc(u.nama)}</b><small>${esc(u.username)} · terakhir masuk ${esc(u.terakhir_masuk||'belum pernah')}</small></div></div>`}
   ${u.terkunci?`<div class="oerr">${ic('info',16)}Terkunci karena salah sandi berulang</div>`:''}
   ${isNew?`<div class="ofld">Username<div class="oinp"><input id="d_user" spellcheck="false" placeholder="misal rina"></div></div>`:''}
   <div class="ofld">Nama tampilan<div class="oinp"><input id="d_nama" value="${esc(u.nama||'')}"></div></div>
   <div class="ofld">Website<div class="oinp"><select id="d_web"><option value="">(tidak ada)</option>${opt}</select></div></div>
   <div class="ofld">Shift<div class="oseg" id="d_shift"><button class="${u.shift!=='malam'?'on':''}" data-act="oseg" data-v="pagi">Pagi</button><button class="${u.shift==='malam'?'on':''}" data-act="oseg" data-v="malam">Malam</button></div></div>
   <div class="ofld" style="gap:8px">Akses aplikasi
    ${APPS.map(([k,l])=>`<div class="otg"><span>${l}</span><button class="osw ${apps.includes(k)?'y':''}" data-act="otog" data-k="${k}" aria-label="${l}"></button></div>`).join('')}
    <div class="otg"><span>Admin</span><button class="osw ${u.role==='admin'?'y':''}" data-act="otog" data-k="admin" aria-label="Admin"></button></div>
    <div class="otg"><span>Akun aktif</span><button class="osw ${u.status!=='nonaktif'?'y':''}" data-act="otog" data-k="aktif" aria-label="Akun aktif"></button></div></div>
   ${isNew?`<div class="ofld">Sandi awal (minimal 6, staff wajib ganti saat login)<div class="oinp"><input id="d_pw" spellcheck="false"></div></div>`:''}
   <div id="m_err"></div>
   <div style="display:flex;gap:8px;flex-wrap:wrap">${isNew?'':`<button class="obtn ghost" data-act="oreset">${ic('key',16)}Reset sandi</button>`}${u.terkunci?`<button class="obtn ghost" data-act="ounlk">Buka kunci</button>`:''}<button class="obtn" style="flex:1" data-act="osaveu">${isNew?'Tambah akun':'Simpan'}</button></div>
   ${isNew||u.username===U().username?'':`<button class="obtn red" data-act="odelu">Hapus akun</button>`}</div>`;
}
V.adm_users={
 mount(){return `<div class="oadm"><div class="ohead"><div><div class="ohi">Admin</div><h1 class="oh1" style="font-size:28px">Akun staff</h1></div><div style="display:flex;gap:8px"><button class="obtn ghost" data-act="oreload">${ic('refresh',16)}Muat ulang</button><button class="obtn" data-act="onewu">${ic('plus',16,2)}Tambah akun</button></div></div>
  <div class="otabs" id="a_tabs"></div><div class="ogrid"><div class="okard otable" id="a_tbl"><div class="oempty">Memuat…</div></div><div id="a_drw">${drawer()}</div></div></div>`},
 async update(force){
  if(force&&!AD.busy){AD.busy=true;await adUsers();AD.busy=false}
  if(!AD.users||!$('#a_tbl'))return;
  const L=AD.users,cnt={all:L.length,pagi:L.filter(u=>u.shift!=='malam').length,malam:L.filter(u=>u.shift==='malam').length,lock:L.filter(u=>u.terkunci).length};
  const tabs=[['all','Semua'],['pagi','Shift pagi'],['malam','Shift malam'],['lock','Terkunci']].map(([k,l])=>`<button class="otab ${AD.f===k?'on':''}" data-act="oftab" data-v="${k}">${l} (${cnt[k]})</button>`).join('');
  if(sig('a_tabs',tabs))$('#a_tabs').innerHTML=tabs;
  const rows=L.filter(u=>AD.f==='all'||(AD.f==='lock'?u.terkunci:(AD.f==='malam')===(u.shift==='malam')));
  const st=u=>u.terkunci?['Terkunci','var(--danger)']:u.status==='nonaktif'?['Nonaktif','var(--ink-muted)']:!u.terakhir_masuk?['Baru','var(--warn)']:['Aktif','var(--ok)'];
  const h=rows.length?`<table><thead><tr><th>Nama</th><th>Website</th><th>Shift</th><th>Aplikasi</th><th>Status</th></tr></thead><tbody>${rows.map(u=>{const s=st(u);return `<tr class="${AD.sel&&AD.sel.username===u.username?'sel':''}" data-act="opicku" data-u="${esc(u.username)}"><td><div class="uc"><span class="uav" style="background:${avc(u.username)}">${esc(initials(u.nama))}</span><div><b style="font-weight:700">${esc(u.nama)}</b>${u.role==='admin'?' <span class="ochip">Admin</span>':''}<small>${esc(u.username)}</small></div></div></td><td>${esc(u.website||'–')}</td><td>${u.shift==='malam'?'Malam':'Pagi'}</td><td>${(u.apps||[]).map(a=>`<span class="ochip">${esc(APPN(a))}</span>`).join('')||'<span class="omu">–</span>'}</td><td><span class="ost" style="color:${s[1]};padding:0"><i></i>${s[0]}</span></td></tr>`}).join('')}</tbody></table>`:'<div class="oempty">Tidak ada akun di filter ini.</div>';
  if(sig('a_tbl',h))$('#a_tbl').innerHTML=h;
 }};
V.adm_hist={
 mount(){return `<div class="oadm"><div class="ohead"><div><div class="ohi">Admin</div><h1 class="oh1" style="font-size:28px">Riwayat masuk</h1></div><div style="display:flex;gap:8px;align-items:center"><div class="oinp ofilter">${ic('search',16)}<input id="h_q" placeholder="Cari nama, PC, kejadian" value="${esc(AD.hq)}"></div><button class="obtn ghost" data-act="ohreload">${ic('refresh',16)}Muat ulang</button></div></div>
  <div class="okard otable" id="h_tbl" style="flex:1;min-height:0"><div class="oempty">Memuat…</div></div></div>`},
 async update(force){
  if(force){const r=await api('admin_history',{limit:400});AD.hist=r.ok?r.rows:[];if(!r.ok)toast(r.msg||'Gagal memuat')}
  if(!AD.hist||!$('#h_tbl'))return;
  const q=AD.hq.toLowerCase();const rows=AD.hist.filter(r=>!q||JSON.stringify(r).toLowerCase().includes(q));
  const bad=k=>/gagal|terkunci|ditolak/.test(k);
  const h=rows.length?`<table><thead><tr><th>Waktu</th><th>User</th><th>Kejadian</th><th>Website</th><th>PC</th><th>Info</th></tr></thead><tbody>${rows.map(r=>`<tr style="cursor:default"><td class="omu" style="white-space:nowrap">${esc(r.waktu)}</td><td><b style="font-weight:700">${esc(r.username)}</b></td><td><span class="ost ${bad(String(r.kejadian))?'bad':r.kejadian==='login'?'ok':'mu'}"><i></i>${esc(r.kejadian)}</span></td><td>${esc(r.website||'')}</td><td class="omu">${esc(r.pc||'')}</td><td class="omu">${esc(r.info||'')}</td></tr>`).join('')}</tbody></table>`:'<div class="oempty">Belum ada riwayat.</div>';
  if(sig('h_tbl',h))$('#h_tbl').innerHTML=h;
 }};
V.adm_ann={
 mount(){const n=OV.d.ann;return `<div class="oadm" style="max-width:760px"><div><div class="ohi">Admin</div><h1 class="oh1" style="font-size:28px">Pengumuman</h1></div>
  <div class="okard" style="padding:20px;display:flex;flex-direction:column;gap:12px"><div class="omu">Tampil di Home semua staff (diperbarui tiap 1 menit).</div>
   <div class="oinp ta"><textarea id="a_ann" maxlength="500" placeholder="Tulis pengumuman…">${esc(n&&n.teks||'')}</textarea></div><div id="m_err"></div>
   <div style="display:flex;gap:8px;justify-content:flex-end"><button class="obtn ghost" data-act="oannclr">Hapus pengumuman</button><button class="obtn" data-act="oannsave">${ic('send',16)}Kirim pengumuman</button></div></div>
  ${n&&n.teks?`<div class="okard oann"><span class="ii">${ic('bell',17)}</span><div><b>${esc(n.oleh)}</b> <span class="omu" style="font-size:12.5px">${esc(n.waktu)}</span><div>${esc(n.teks)}</div></div></div>`:''}
  <div class="okard" style="padding:20px;display:flex;flex-direction:column;gap:10px"><b style="font-size:16px;font-weight:800">Alamat MEGA OFFICE web</b>
   <div class="omu">Dipakai menu Cek Rekening di aplikasi ini (semua PC). Isi dengan alamat web dari Vercel, misal https://mega-office.vercel.app</div>
   <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><div class="oinp" style="flex:1;min-width:260px"><input id="a_web" value="${esc(OV.d.web||'')}" placeholder="https://….vercel.app" spellcheck="false"></div><button class="obtn" data-act="osetweb">Simpan alamat</button></div><div id="w_err"></div></div></div>`},
 update(){}};
document.addEventListener('input',e=>{if(e.target.id==='h_q'){AD.hq=e.target.value;sigs.h_tbl=null;V.adm_hist.update(false)}});

/* ---------------- aksi ---------------- */
const busyBtn=(b,on)=>{if(b)b.disabled=on};
// layar loading: muncul kalau menunggu lebih dari sebentar (biar tidak berkedip untuk jawaban cepat)
const LOAD={t:null,since:0};
function loading(on,txt){const o=$('#oload');if(!o)return;clearTimeout(LOAD.t);
  if(on){const t=o.querySelector('.ol-txt');if(t)t.textContent=txt||'Memuat…';LOAD.t=setTimeout(()=>{o.classList.add('on');LOAD.since=Date.now()},150)}
  else{const sisa=o.classList.contains('on')?Math.max(0,450-(Date.now()-LOAD.since)):0;LOAD.t=setTimeout(()=>o.classList.remove('on'),sisa)}}
Object.assign(A,{
 omenu:()=>openDD(!DD),
 osbhide:()=>{document.body.classList.add('sbhide');try{localStorage.setItem('mo_sb','hide')}catch(e){}},
 osbshow:()=>{document.body.classList.remove('sbhide');try{localStorage.setItem('mo_sb','show')}catch(e){}},
 omode:()=>{const d=document.documentElement.dataset.mode==='dark'?'light':'dark';document.documentElement.dataset.mode=d;try{localStorage.setItem('mo_mode',d)}catch(e){}sigs.side=null;renderDock();toast(d==='dark'?'Tampilan gelap':'Tampilan terang')},
 oeye:b=>{const i=b.parentElement.querySelector('input');if(i)i.type=i.type==='password'?'text':'password'},
 ocode:async b=>{busyBtn(b,true);gErr('Menghubungi Pusat…',true);loading(true,'Menghubungi Pusat…');const r=await api('office_code',{code:$('#g_code').value});busyBtn(b,false);if(!r.ok){loading(false);gErr(r.msg);return}toast(r.msg);await ovLoad();GATE='';applyGate();loading(false)},
 ologin:async b=>{const u=$('#g_user').value.trim(),p=$('#g_pw').value;if(!u||!p){gErr('Isi username dan password.');return}
   busyBtn(b,true);gErr('Masuk…',true);loading(true,'Masuk…');const r=await api('office_login',{user:u,pw:p});busyBtn(b,false);
   if(!r.ok){loading(false);gErr(r.msg||'Login gagal');$('#g_pw').value='';$('#g_pw').focus();return}
   if(r.offline)toast('Mode offline: Pusat tidak terjangkau');if(r.warn)toast(r.warn);
   bump();await ovLoad();await reloadState();view='home';history.replaceState(null,'','#home');sigs={};GATE='x';applyGate();if(!GATE){sigs={};mount()}loading(false)},
 ounlock:async b=>{const p=$('#g_pw').value;if(!p){gErr('Isi password.');return}busyBtn(b,true);loading(true,'Membuka kunci…');const r=await api('office_unlock',{pw:p});busyBtn(b,false);loading(false);
   if(!r.ok){gErr(r.msg||'Sandi salah');$('#g_pw').value='';if(r.locked||r.expired){await ovLoad();GATE='';applyGate()}return}
   bump();await ovLoad();applyGate()},
 olock:async()=>{await api('office_lock');await ovLoad();applyGate()},
 osignout:async()=>{if(S&&S.tf&&S.tf.phase==='ready'){toast('Transfer sedang menunggu PIN, selesaikan dulu');return}
   await api('office_logout');closeModal();S=null;sigs={};selisihShow.p=null;const w=$('#selwrap');if(w)w.remove();const rw=$('#rekwrap');if(rw)rw.remove();const cw=$('#coinwrap');if(cw)cw.remove();$('#view').innerHTML='';AD.users=null;AD.hist=null;AD.sel=null;
   await ovLoad();GATE='';applyGate()},
 oun:()=>{const u=U();modal(`<span class="h">Ganti username</span>
   <div class="omu">Username dipakai untuk login. Nama tampilan <b>${esc(u.nama)}</b> tidak berubah (hanya admin yang bisa mengganti nama).</div>
   <div class="ofld">Username sekarang<div class="oinp">${ic('users',18)}<input value="${esc(u.username)}" disabled></div></div>
   <div class="ofld">Username baru<div class="oinp">${ic('users',18)}<input id="u_new" autocomplete="off" spellcheck="false" autocapitalize="off" maxlength="30"></div></div>
   <div class="omu" style="font-size:12px;margin-top:-4px">3-30 karakter: huruf kecil, angka, titik (.), strip (-), garis bawah (_).</div>
   <div class="ofld">Sandi sekarang (konfirmasi)<div class="oinp">${ic('lock',18)}<input id="u_pw" type="password" autocomplete="current-password"></div></div>
   <div id="g_err"></div><div class="row" style="gap:8px"><div class="grow"></div><button class="obtn ghost" data-act="closem">Batal</button><button class="obtn" data-act="ounsave">Simpan</button></div>`);setTimeout(()=>{const i=$('#u_new');i&&i.focus()},60)},
 ounsave:async b=>{const v=$('#u_new').value.trim().toLowerCase(),p=$('#u_pw').value;
   if(!/^[a-z0-9._-]{3,30}$/.test(v)){gErr('Username 3-30 karakter: huruf kecil, angka, titik, strip, garis bawah (tanpa spasi).');return}
   if(v===U().username){gErr('Username baru sama dengan yang sekarang.');return}
   if(!p){gErr('Isi sandi sekarang untuk konfirmasi.');return}
   busyBtn(b,true);const r=await api('office_rename',{new:v,pw:p});busyBtn(b,false);
   if(!r.ok){gErr(r.msg||'Gagal');if(r.locked||r.expired){closeModal();await ovLoad();GATE='';applyGate()}return}
   closeModal();toast('Username diganti jadi '+v+'. Login berikutnya pakai username ini.');await ovLoad();sigs.side=null;renderDock();applyGate()},
 opw:()=>{modal(`<span class="h">Ganti sandi</span>${pwFields()}<div id="g_err"></div><div class="row" style="gap:8px"><div class="grow"></div><button class="obtn ghost" data-act="closem">Batal</button><button class="obtn" data-act="opwsave">Simpan</button></div>`);setTimeout(()=>{const i=$('#p_old');i&&i.focus()},60)},
 opwsave:async b=>{const o=$('#p_old').value,n=$('#p_new').value,n2=$('#p_new2').value;
   if(n.length<6){gErr('Sandi baru minimal 6 karakter.');return}if(n!==n2){gErr('Sandi baru dan ulangi tidak sama.');return}
   busyBtn(b,true);const r=await api('office_passwd',{old:o,new:n});busyBtn(b,false);
   if(!r.ok){gErr(r.msg||'Gagal');if(r.locked||r.expired){closeModal();await ovLoad();GATE='';applyGate()}return}
   closeModal();toast('Sandi diganti');await ovLoad();applyGate()},
 ome:()=>{const u=U();modal(`<div class="uc"><span class="oav bigav" style="width:52px;height:52px;font-size:18px">${esc(initials(u.nama))}</span><div><span class="h">${esc(u.nama)}</span><small>${esc(u.username)} · ${u.role==='admin'?'Admin':'Staff'}</small></div></div>
   <div class="col" style="gap:6px"><div class="row"><span class="omu" style="width:120px">Website</span><b>${esc((S&&S.profile)||u.website||'–')}</b></div><div class="row"><span class="omu" style="width:120px">Shift</span><b>${esc(u.shift)}</b></div><div class="row"><span class="omu" style="width:120px">PC</span><b>${esc(OV.d.pc)}</b></div><div class="row"><span class="omu" style="width:120px">Versi app</span><b>v${esc(OV.d.version)}</b></div>${OV.d.offline?'<div class="oinfo">Mode offline: Pusat tidak terjangkau, menu admin & ganti sandi belum bisa.</div>':''}</div>
   <div class="row" style="gap:8px"><button class="obtn ghost" data-act="oun">${ic('users',16)}Ganti username</button><button class="obtn ghost" data-act="opw">${ic('key',16)}Ganti sandi</button><div class="grow"></div><button class="obtn red" data-act="osignout">${ic('out',16)}Sign out</button></div>`)},
 // admin: akun
 oreload:async()=>{AD.busy=true;await adUsers();AD.busy=false;sigs.a_tbl=null;sigs.a_tabs=null;V.adm_users.update(false);toast('Dimuat ulang')},
 oftab:b=>{AD.f=b.dataset.v;sigs.a_tbl=null;sigs.a_tabs=null;V.adm_users.update(false)},
 opicku:b=>{AD.sel=JSON.parse(JSON.stringify(AD.users.find(u=>u.username===b.dataset.u)||null));$('#a_drw').innerHTML=drawer();sigs.a_tbl=null;V.adm_users.update(false)},
 onewu:()=>{AD.sel={username:'',nama:'',website:'',shift:'pagi',apps:['selisih','rekening','coin','deposit','depo'],role:'staff',status:'aktif'};$('#a_drw').innerHTML=drawer();setTimeout(()=>{const i=$('#d_user');i&&i.focus()},50)},
 oseg:b=>{b.parentElement.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b))},
 otog:b=>b.classList.toggle('y'),
 osaveu:async b=>{const u=AD.sel;if(!u)return;const isNew=!u.username;
   const on=k=>{const x=$(`.osw[data-k="${k}"]`);return !!x&&x.classList.contains('y')};
   const keep=(u.apps||[]).filter(a=>!APPS.some(x=>x[0]===a));
   const obj={username:isNew?$('#d_user').value.trim():u.username,nama:$('#d_nama').value.trim(),website:$('#d_web').value,shift:($('#d_shift .on')||{dataset:{v:'pagi'}}).dataset.v,
     apps:APPS.map(a=>a[0]).filter(on).concat(keep),role:on('admin')?'admin':'staff',status:on('aktif')?'aktif':'nonaktif'};
   if(!obj.nama){gErr('Isi nama tampilan.');return}
   if(isNew&&!obj.username){gErr('Isi username.');return}
   if(isNew&&AD.users.some(x=>x.username===obj.username.toLowerCase())){gErr('Username sudah dipakai.');return}
   busyBtn(b,true);const r=await api('admin_save',{user:obj,pw:isNew?$('#d_pw').value:undefined});busyBtn(b,false);
   if(!r.ok){gErr(r.msg||'Gagal menyimpan');return}
   toast(isNew?'Akun dibuat':'Disimpan');await adUsers();AD.sel=AD.users.find(x=>x.username===r.user.username)||null;$('#a_drw').innerHTML=drawer();sigs.a_tbl=null;sigs.a_tabs=null;V.adm_users.update(false);
   if(r.user.username===U().username){await ovLoad();sigs.side=null;renderDock()}},
 oreset:()=>{const u=AD.sel;modal(`<span class="h">Reset sandi ${esc(u.nama)}</span><div class="omu">Buat sandi sementara (minimal 6 karakter). ${esc(u.nama)} wajib menggantinya saat login berikutnya. Kunci akun juga dibuka.</div>
   <div class="ofld">Sandi sementara<div class="oinp"><input id="r_pw" spellcheck="false"></div></div><div id="g_err"></div><div class="row" style="gap:8px"><div class="grow"></div><button class="obtn ghost" data-act="closem">Batal</button><button class="obtn" data-act="oresetgo">Reset sandi</button></div>`);setTimeout(()=>$('#r_pw').focus(),60)},
 oresetgo:async b=>{const pw=$('#r_pw').value;if(pw.length<6){gErr('Minimal 6 karakter.');return}busyBtn(b,true);const r=await api('admin_reset',{username:AD.sel.username,pw});busyBtn(b,false);
   if(!r.ok){gErr(r.msg||'Gagal');return}closeModal();toast('Sandi direset. Kirim sandi sementara ke '+AD.sel.nama);await adUsers();AD.sel=AD.users.find(x=>x.username===r.user.username);$('#a_drw').innerHTML=drawer();sigs.a_tbl=null;V.adm_users.update(false)},
 ounlk:async b=>{busyBtn(b,true);const r=await api('admin_unlock',{username:AD.sel.username});busyBtn(b,false);if(!r.ok){gErr(r.msg);return}toast('Kunci dibuka');await adUsers();AD.sel=AD.users.find(x=>x.username===r.user.username);$('#a_drw').innerHTML=drawer();sigs.a_tbl=null;sigs.a_tabs=null;V.adm_users.update(false)},
 odelu:()=>modal(`<span class="h">Hapus akun ${esc(AD.sel.nama)}?</span><div class="omu">Akun tidak bisa login lagi. Riwayat masuk tetap tersimpan. Kalau hanya sementara, matikan saja "Akun aktif".</div><div class="row" style="gap:8px"><div class="grow"></div><button class="obtn ghost" data-act="closem">Batal</button><button class="obtn red" data-act="odelgo">Hapus</button></div>`),
 odelgo:async b=>{busyBtn(b,true);const r=await api('admin_delete',{username:AD.sel.username});busyBtn(b,false);closeModal();if(!r.ok){toast(r.msg||'Gagal');return}toast('Akun dihapus');AD.sel=null;await adUsers();$('#a_drw').innerHTML=drawer();sigs.a_tbl=null;sigs.a_tabs=null;V.adm_users.update(false)},
 ohreload:()=>V.adm_hist.update(true),
 oannsave:async b=>{const t=$('#a_ann').value.trim();if(!t){gErr('Tulis pengumuman dulu.');return}busyBtn(b,true);const r=await api('admin_announce',{teks:t});busyBtn(b,false);if(!r.ok){gErr(r.msg);return}toast('Pengumuman terkirim');await ovLoad();mount()},
 osetweb:async b=>{const w=$('#a_web').value.trim().replace(/\/+$/,'');const e=$('#w_err');busyBtn(b,true);const r=await api('admin_setweb',{web:w});busyBtn(b,false);
   if(e)e.innerHTML=r.ok?`<div class="oinfo">${ic('info',16)}Tersimpan. Semua PC memakai alamat ini (diperbarui tiap 1 menit).</div>`:`<div class="oerr">${ic('info',16)}${esc(r.msg||'Gagal')}</div>`;if(r.ok){await ovLoad()}},
 oannclr:async b=>{busyBtn(b,true);const r=await api('admin_announce',{teks:''});busyBtn(b,false);if(!r.ok){gErr(r.msg);return}toast('Pengumuman dihapus');await ovLoad();mount()},
});
/* tampilan G1 untuk tombol-tombol lama di halaman Depo */
const oldGo=go;
window.go=function(v){if(!allowed(v)){toast('Menu ini tidak aktif untuk akun kamu');return}oldGo(v)};

/* ---------------- mulai ---------------- */
if(!location.hash||location.hash==='#beranda')view='home';
(async()=>{LOAD.since=Date.now();try{await ovLoad();applyGate();if(U()&&!GATE){await reloadState();mount()}}finally{loading(false)}poll()})();
})();
