/* MEGA OFFICE - Cek Coin Error: baca credit log agen (GIGA / UG), cari baris yang saldonya tidak cocok.
   Cara hitung sama dengan rumus sheet coin log:
     saldo seharusnya = saldo sebelumnya + credit - debit ; beda = Balance - saldo seharusnya
   Tambahan:
   - TID yang tercatat 2x: dicek apakah coin agen benar-benar terpotong lagi atau baris dobel saja.
   - Top-up agen tidak tercatat sebagai baris: beda yang PERSIS kelipatan 10 juta = top-up.
     Beda yang bukan kelipatan 10 juta ditampilkan penuh (tidak dibulatkan).
   - Transaksi di detik yang sama sering menulis Balance lama, jadi beda baru dihitung kalau menetap beberapa baris. */
(function (root) {
  'use strict';
  const TOPUP = 1e7, W = 5;
  const r2 = x => Math.round(x * 100) / 100;
  const sec = at => Date.parse(String(at).replace(' ', 'T') + 'Z') / 1000;
  const low = s => String(s == null ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();

  function num(v) {
    if (typeof v === 'number') return v;
    let s = String(v == null ? '' : v).replace(/[^\d.,-]/g, '');
    if (!s) return 0;
    const c = s.lastIndexOf(','), d = s.lastIndexOf('.');
    if (c > -1 && d > -1) s = c > d ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    else if (c > -1) s = /,\d{1,2}$/.test(s) && (s.match(/,/g) || []).length === 1 ? s.replace(',', '.') : s.replace(/,/g, '');
    else if ((s.match(/\./g) || []).length > 1) s = s.replace(/\./g, '');
    const n = parseFloat(s);
    return isNaN(n) ? 0 : n;
  }
  const p2 = n => String(n).padStart(2, '0');
  function excelDate(v) {
    if (v == null || v === '') return '';
    if (typeof v === 'number' && v > 20000 && v < 80000) {
      const ms = Math.round((v - 25569) * 86400000), d = new Date(ms);
      return d.getUTCFullYear() + '-' + p2(d.getUTCMonth() + 1) + '-' + p2(d.getUTCDate()) + ' ' + p2(d.getUTCHours()) + ':' + p2(d.getUTCMinutes()) + ':' + p2(d.getUTCSeconds());
    }
    if (v instanceof Date) return v.getFullYear() + '-' + p2(v.getMonth() + 1) + '-' + p2(v.getDate()) + ' ' + p2(v.getHours()) + ':' + p2(v.getMinutes()) + ':' + p2(v.getSeconds());
    const s = String(v).trim();
    let m = /^(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(s);
    if (m) return m[1] + '-' + p2(m[2]) + '-' + p2(m[3]) + ' ' + p2(m[4]) + ':' + m[5] + ':' + (m[6] || '00');
    m = /^(\d{1,2})[/-](\d{1,2})[/-](\d{4})[ T,]+(\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(s);
    if (m) return m[3] + '-' + p2(m[2]) + '-' + p2(m[1]) + ' ' + p2(m[4]) + ':' + m[5] + ':' + (m[6] || '00');
    return s;
  }

  // ---------- baca baris tabel (hasil XLSX.utils.sheet_to_json header:1) ----------
  function findHeader(rows) {
    for (let i = 0; i < Math.min(rows.length, 30); i++) {
      const r = (rows[i] || []).map(low);
      const at = k => r.findIndex(c => c === k);
      const has = f => r.findIndex(f);
      const bal = has(c => c === 'balance' || c === 'saldo' || c === 'balance after');
      const deb = has(c => c === 'debit');
      const cre = has(c => c === 'credit');
      if (bal < 0 || (deb < 0 && cre < 0)) continue;
      const tid = has(c => /^(transaction id|trx id|tid|transaction no|transaction number|ref(erence)?( no)?)$/.test(c));
      const type = has(c => /^(transaction type|type|tipe|jenis|description)$/.test(c));
      const date = has(c => /date|time|tanggal|waktu/.test(c));
      if (tid < 0 || date < 0) continue;
      return { i, no: at('#') >= 0 ? at('#') : at('no'), at: date, tid, type, debit: deb, credit: cre, bal, by: has(c => /credited by|^by$|operator|created by|admin/.test(c)) };
    }
    return null;
  }
  function parseRows(rows, src) {
    const h = findHeader(rows); if (!h) return null;
    const out = [];
    for (let i = h.i + 1; i < rows.length; i++) {
      const r = rows[i]; if (!r) continue;
      const tid = r[h.tid], bal = r[h.bal];
      if (tid == null || String(tid).trim() === '' || bal == null || String(bal).trim() === '') continue;
      const at = excelDate(r[h.at]); if (!/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d/.test(at)) continue;
      out.push({ no: h.no >= 0 ? num(r[h.no]) : null, at, tid: String(tid).trim().replace(/\.0$/, ''), type: h.type >= 0 ? String(r[h.type] || '').trim() : '',
        debit: h.debit >= 0 ? Math.abs(num(r[h.debit])) : 0, credit: h.credit >= 0 ? Math.abs(num(r[h.credit])) : 0, bal: num(bal),
        by: h.by >= 0 ? String(r[h.by] || '').trim() : '', src, idx: i });
    }
    return out;
  }

  // ---------- urutkan dari yang paling lama ----------
  function chrono(list) {
    const seen = new Set(), L = [];
    list.forEach((c, k) => { const key = [c.at, c.tid, c.type, c.debit, c.credit, c.bal].join('|'); if (!seen.has(key)) { seen.add(key); L.push({ ...c, k }); } });
    // export biasanya terbaru di atas (# kecil = terbaru). Di detik yang sama: # besar / baris bawah = lebih dulu.
    const newestFirst = (() => { const a = L.filter(c => c.src === (L[0] || {}).src); return a.length > 1 && a[0].at > a[a.length - 1].at; })();
    L.sort((p, q) => p.at < q.at ? -1 : p.at > q.at ? 1 :
      (p.no != null && q.no != null && p.no !== q.no ? q.no - p.no : (newestFirst ? q.k - p.k : p.k - q.k)));
    return L;
  }

  // subset kecil yang jumlahnya pas
  function subsetSum(items, target) {
    const n = items.length; if (n > 16) return null;
    for (let m = 1; m < (1 << n); m++) {
      let s = 0; for (let j = 0; j < n; j++) if (m & (1 << j)) s += items[j].v;
      if (Math.abs(s - target) < 0.5) return items.filter((_, j) => m & (1 << j));
    }
    return null;
  }

  function audit(list) {
    const L = chrono(list);
    if (!L.length) return null;
    // TID yang muncul lebih dari sekali (tipe sama): kemunculan kedua dst = baris dobel
    const firstSeen = new Map(), dups = [];
    L.forEach((c, i) => { const key = c.tid.toUpperCase() + '|' + low(c.type);
      if (firstSeen.has(key)) { c.dup = firstSeen.get(key); dups.push(i); } else firstSeen.set(key, i); });
    // beda = Balance - saldo seharusnya ; baris dobel: Balance-nya tidak dipakai (sering angka sisipan)
    // hitung dalam sen (bilangan bulat) supaya tidak ada sisa pembulatan setelah ribuan baris
    const cn = x => Math.round(x * 100);
    let s = cn(L[0].bal) + cn(L[0].debit) - cn(L[0].credit);
    const e = L.map(c => { s += cn(c.credit) - cn(c.debit); return c.dup != null ? null : (cn(c.bal) - s) / 100; });
    // level beda yang menetap
    // harus diikuti W-1 baris dengan beda yang sama (baris di ujung file yang belum cukup diikuti tidak dihitung)
    const steady = i => { let n = 0; for (let j = i + 1; j < e.length && n < W - 1; j++) { if (e[j] == null) continue; if (Math.abs(e[j] - e[i]) >= 0.5) return false; n++; } return n >= W - 1; };
    // patokan awal = beda pertama yang menetap (baris pertama bisa saja Balance "lama" karena detik yang sama)
    let lvl = null, lastAt = -1, base = 0;
    for (let i = 0; i < e.length; i++) if (e[i] != null && steady(i)) { lvl = base = e[i]; lastAt = i; break; }
    const events = [];
    for (let i = lastAt + 1; lvl != null && i < e.length; i++) {
      if (e[i] == null) continue;
      if (Math.abs(e[i] - lvl) < 0.5) { lastAt = i; continue; }
      if (!steady(i)) continue;
      events.push({ from: lastAt + 1, to: i, delta: r2(e[i] - lvl) });
      lvl = e[i]; lastAt = i;
    }
    const tail = lvl == null ? e.length : e.length - 1 - lastAt;   // baris akhir yang belum bisa dipastikan
    const used = new Set(), topups = [], errors = [], dupRes = [];
    const fmtRow = c => ({ at: c.at, tid: c.tid, type: c.type, debit: c.debit, credit: c.credit, bal: c.bal, by: c.by });
    for (const ev of events) {
      // baris dobel di sekitar perubahan: debit dobel yang TIDAK terpotong -> beda naik ; credit dobel yang TIDAK masuk -> beda turun
      // baris dobel di sekitar waktu perubahan (urutan di detik yang sama tidak bisa dipercaya, jadi pakai jam: 2 menit sebelum s/d 1 menit sesudah)
      const t0 = sec(L[Math.max(0, ev.from)].at) - 120, t1 = sec(L[ev.to].at) + 60;
      const near = dups.filter(i => !used.has(i) && sec(L[i].at) >= t0 && sec(L[i].at) <= t1);
      const cand = near.map(i => ({ i, v: L[i].debit ? L[i].debit : -L[i].credit }));
      const hit = cand.length ? subsetSum(cand, ev.delta) : null;
      if (hit) { hit.forEach(h => { used.add(h.i); dupRes.push({ i: h.i, ok: true }); }); continue; }
      const span = L.slice(Math.max(0, ev.from), ev.to + 1);
      // top-up / tarik coin agen: PERSIS kelipatan 10 juta (toleransi di bawah 1 rupiah). Selain itu ditampilkan penuh sebagai beda.
      const mult = Math.round(ev.delta / TOPUP) * TOPUP;
      if (mult !== 0 && Math.abs(ev.delta - mult) < 1) { topups.push({ at: L[ev.to].at, amt: mult }); continue; }
      const same = span.filter(c => Math.abs((c.debit || c.credit) - Math.abs(ev.delta)) < 0.5);
      errors.push({ at: L[ev.to].at, from: span[0] ? span[0].at : L[ev.to].at, delta: ev.delta, rows: span.slice(-12).map(fmtRow), likely: same.map(fmtRow),
        bigTop: Math.abs(ev.delta) >= TOPUP ? Math.round(ev.delta / TOPUP) * TOPUP : 0 });
    }
    // baris dobel yang tidak menjelaskan perubahan apa pun = saldo ikut berubah lagi (terpotong / masuk dua kali)
    for (const i of dups) if (!used.has(i)) dupRes.push({ i, ok: false });
    const groups = new Map();
    for (const d of dupRes) {
      const c = L[d.i], o = L[c.dup];
      const key = c.tid.toUpperCase() + '|' + low(c.type);
      const g = groups.get(key) || { tid: c.tid, type: c.type, amt: c.debit || c.credit, side: c.debit ? 'debit' : 'credit', first: fmtRow(o), copies: [] };
      g.copies.push({ ...fmtRow(c), charged: !d.ok });
      groups.set(key, g);
    }
    const dupGroups = [...groups.values()].map(g => ({ ...g, extra: g.copies.filter(x => x.charged).length * g.amt }))
      .sort((a, b) => a.first.at < b.first.at ? -1 : 1);
    // efek ke coin agen: positif = agen dapat coin lebih, negatif = coin agen hilang
    const effect = r2(errors.reduce((s, x) => s + x.delta, 0) + dupGroups.reduce((s, g) => s + (g.side === 'debit' ? -g.extra : g.extra), 0));
    const types = {}; L.forEach(c => { const t = c.type || '-'; types[t] = types[t] || { n: 0, debit: 0, credit: 0 }; types[t].n++; types[t].debit += c.debit; types[t].credit += c.credit; });
    return { n: L.length, from: L[0].at, to: L[L.length - 1].at, startBal: r2(L[0].bal + L[0].debit - L[0].credit), endBal: L[L.length - 1].bal,
      topups, errors, dupGroups, effect, types, tail };
  }

  const api = { num, excelDate, findHeader, parseRows, chrono, audit };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.CoinCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
