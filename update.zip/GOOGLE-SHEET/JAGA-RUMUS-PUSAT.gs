// JAGA RUMUS PUSAT - MEGA GAMING
// SATU script untuk SEMUA buku hitungan. Dipasang SEKALI oleh lead/pemilik, dari akun Google yang punya akses EDIT
// ke semua buku (akun sendiri atau akun automation). Staff tidak perlu memasang apa pun di bukunya.
//
// PASANG (sekitar 3 menit, sekali saja)
// 1. Buka script.google.com > New project. Hapus isi editor, tempel seluruh file ini.
// 2. Isi daftar BUKU di bawah dengan link semua buku hitungan (satu baris satu buku). Simpan (Ctrl+S).
// 3. Di atas editor pilih function  pasangSemua  lalu klik Run. Pertama kali: Review permissions > pilih akun >
//    Advanced > Go to ... (unsafe) > Allow. Lihat Execution log: "Terpasang: NAMA BUKU" untuk tiap buku.
// 4. Selesai. Menambah buku baru = tambah link-nya di daftar, Run pasangSemua lagi (yang sudah ada tidak dobel).
//    Melepas semua: Run lepasSemua.  Melihat status: Run cekSemua.
//
// APA YANG DIKERJAKAN
// Saat baris dari aplikasi ditempel (Ctrl+V) misal ke kolom C..R, kolom di antaranya (D, F, H, ...) ikut tertimpa KOSONG,
// jadi rumus / isi di situ hilang. Itu perilaku Google Sheets (tempel tidak bisa melewati sel kosong).
// Script ini jalan otomatis setiap ada tempelan/ketikan di buku mana pun yang terdaftar (siapa pun yang mengedit):
// sel yang menjadi kosong diisi kembali dengan rumus yang sama seperti baris-baris lain di kolom itu
// (dicontoh dari baris di bawah/atasnya, referensi menyesuaikan baris). Kolom data (jam, user ID, nominal, nama) tidak disentuh.
//
// BATAS GOOGLE: maksimal 20 buku per project script. Lebih dari 20: buat project kedua (salin script ini, isi link sisanya).

var BUKU = [
  // 'https://docs.google.com/spreadsheets/d/1AbCdEf.../edit',   // VIP555
  // 'https://docs.google.com/spreadsheets/d/1GhIjKl.../edit',   // MEGA288
];
var FOLDER = '';         // opsional: link/ID folder Drive. Semua Google Sheet di folder itu ikut dijaga (selain daftar BUKU).
var TAB = [];            // nama tab yang dijaga, misal ['BUKU', 'OKTOBER']. Kosong [] = semua tab.
var KOLOM_TETAP = [];    // kolom berisi teks/angka yang SAMA di tiap baris (bukan rumus), misal ['D']. Diisi ulang dari baris di dekatnya.
var LIHAT = 40;          // berapa baris di bawah/atas yang dilihat untuk mencari rumus contoh

// ===================== pasang / lepas / cek =====================
function pasangSemua() {
  var ids = daftar_();
  if (!ids.length) { Logger.log('Daftar BUKU masih kosong. Isi link buku hitungan di bagian atas script, Simpan, lalu Run lagi.'); return; }
  var ada = {}, dilepas = 0;
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() !== 'jagaBuku') return;
    var sid = t.getTriggerSourceId();
    if (ids.indexOf(sid) < 0) { ScriptApp.deleteTrigger(t); dilepas++; } else ada[sid] = 1;
  });
  var baru = 0, gagal = [];
  ids.forEach(function (id) {
    if (ada[id]) return;
    var nm = id;
    try {
      nm = SpreadsheetApp.openById(id).getName();
      ScriptApp.newTrigger('jagaBuku').forSpreadsheet(id).onEdit().create();
      baru++; Logger.log('Terpasang: ' + nm);
    } catch (err) { gagal.push(nm + ' -> ' + String(err).replace(/^Exception: /, '')); }
  });
  Logger.log('Selesai. Buku terdaftar: ' + ids.length + ', baru dipasang: ' + baru + ', sudah ada: ' + Object.keys(ada).length + ', dilepas (tidak ada di daftar lagi): ' + dilepas + (gagal.length ? '\nGAGAL:\n' + gagal.join('\n') : ''));
  if (ids.length > 20) Logger.log('PERHATIAN: Google membatasi 20 buku per project script. Untuk sisanya, buat project baru (salin script ini) dan isi link sisanya di sana.');
  if (gagal.length) Logger.log('Buku yang gagal: pastikan akun ini punya akses EDIT ke buku tersebut dan link-nya benar.');
}

function lepasSemua() {
  var n = 0;
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'jagaBuku') { ScriptApp.deleteTrigger(t); n++; } });
  Logger.log('Dilepas dari ' + n + ' buku.');
}

function cekSemua() {
  var out = [];
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() !== 'jagaBuku') return;
    var id = t.getTriggerSourceId(), nm = id;
    try { nm = SpreadsheetApp.openById(id).getName(); } catch (err) { nm = id + ' (tidak bisa dibuka: akses hilang?)'; }
    out.push('- ' + nm);
  });
  Logger.log(out.length ? 'Dijaga (' + out.length + ' buku):\n' + out.join('\n') : 'Belum ada buku yang dijaga. Run pasangSemua.');
}

function daftar_() {
  var ids = [];
  BUKU.forEach(function (u) { var id = id_(u); if (id && ids.indexOf(id) < 0) ids.push(id); });
  var fid = id_(FOLDER, true);
  if (fid) {
    var files = DriveApp.getFolderById(fid).getFilesByType(MimeType.GOOGLE_SHEETS);
    while (files.hasNext()) { var id2 = files.next().getId(); if (ids.indexOf(id2) < 0) ids.push(id2); }
  }
  return ids;
}

function id_(s, folder) {
  s = String(s || '').trim();
  if (!s) return '';
  var m = s.match(folder ? /\/folders\/([A-Za-z0-9_-]+)/ : /\/d\/([A-Za-z0-9_-]+)/);
  if (m) return m[1];
  return /^[A-Za-z0-9_-]{20,}$/.test(s) ? s : '';
}

// ===================== penjaga =====================
function jagaBuku(e) {
  try { jaga_(e); } catch (err) { /* jangan sampai mengganggu pengetikan */ }
}

function jaga_(e) {
  if (!e || !e.range) return;
  var r = e.range, sh = r.getSheet();
  if (TAB.length && TAB.indexOf(sh.getName()) < 0) return;
  var r0 = r.getRow(), n = r.getNumRows(), c0 = r.getColumn(), nc = r.getNumColumns();
  if (n > 1000 || nc > 60) return;                             // bukan tempelan baris buku
  if (n === 1 && nc === 1 && e.value !== undefined && e.value !== '') return;   // ketik satu sel berisi: tidak perlu dicek
  var vals = r.getValues(), fs = r.getFormulas();
  var kosong = {}, ada = false;
  for (var j = 0; j < nc; j++) {
    var b = [];
    for (var i = 0; i < n; i++) if (fs[i][j] === '' && (vals[i][j] === '' || vals[i][j] === null)) b.push(i);
    if (b.length) { kosong[j] = b; ada = true; }
  }
  if (!ada) return;
  var k = konteks_(sh, r0, n, c0, nc);
  var tetap = KOLOM_TETAP.map(colIdx_);
  for (var jj in kosong) {
    var j2 = Number(jj), c = c0 + j2, blanks = kosong[jj];
    var f = contohRumus_(k, j2);
    if (f) {
      runs_(blanks).forEach(function (x) { var arr = []; for (var q = 0; q < x[1]; q++) arr.push([f]); sh.getRange(r0 + x[0], c, x[1], 1).setFormulasR1C1(arr); });
      continue;
    }
    if (tetap.indexOf(c) >= 0) {
      var v = contohNilai_(k, j2);
      if (v !== null) runs_(blanks).forEach(function (x) { sh.getRange(r0 + x[0], c, x[1], 1).setValue(v); });
    }
  }
}

// Baris-baris di bawah dan di atas rentang yang diedit (sekali baca untuk semua kolom)
function konteks_(sh, r0, n, c0, nc) {
  var maxRow = sh.getMaxRows(), below = r0 + n;
  var kb = below <= maxRow ? Math.min(LIHAT, maxRow - below + 1) : 0;
  var top = Math.max(1, r0 - LIHAT), ka = r0 - top;
  var rb = kb ? sh.getRange(below, c0, kb, nc) : null, ra = ka ? sh.getRange(top, c0, ka, nc) : null;
  return { rb: rb, ra: ra, fb: rb ? rb.getFormulasR1C1() : [], fa: ra ? ra.getFormulasR1C1() : [], vb: null, va: null, gb: null, ga: null };
}

// Rumus (R1C1) yang dipakai baris-baris terdekat di kolom ke-j, di luar baris yang baru diedit.
// Hanya kalau minimal 2 dari (maks) 6 rumus terdekat sama persis dan jadi mayoritas -> kolom ini memang kolom rumus per baris.
function contohRumus_(k, j) {
  var cand = [];
  for (var i = 0; i < k.fb.length; i++) if (k.fb[i][j]) cand.push({ d: i + 1, f: k.fb[i][j] });
  for (var i2 = k.fa.length - 1; i2 >= 0; i2--) if (k.fa[i2][j]) cand.push({ d: k.fa.length - i2, f: k.fa[i2][j] });
  if (cand.length < 2) return null;
  cand.sort(function (p, q) { return p.d - q.d; });
  cand = cand.slice(0, 6);
  var cnt = {}, best = null;
  cand.forEach(function (x) { cnt[x.f] = (cnt[x.f] || 0) + 1; if (!best || cnt[x.f] > cnt[best]) best = x.f; });
  return cnt[best] >= 2 && cnt[best] * 2 > cand.length ? best : null;
}

// Isi (bukan rumus) baris terdekat di kolom ke-j, untuk KOLOM_TETAP.
function contohNilai_(k, j) {
  if (k.rb) {
    if (!k.vb) { k.vb = k.rb.getValues(); k.gb = k.rb.getFormulas(); }
    for (var i = 0; i < k.vb.length; i++) if (k.vb[i][j] !== '' && !k.gb[i][j]) return k.vb[i][j];
  }
  if (k.ra) {
    if (!k.va) { k.va = k.ra.getValues(); k.ga = k.ra.getFormulas(); }
    for (var i2 = k.va.length - 1; i2 >= 0; i2--) if (k.va[i2][j] !== '' && !k.ga[i2][j]) return k.va[i2][j];
  }
  return null;
}

// [0,1,2,5,6] -> [[0,3],[5,2]]  (awal, panjang) supaya penulisan ke sheet sedikit panggilan
function runs_(idx) {
  var out = [];
  idx.forEach(function (i) { var last = out[out.length - 1]; if (last && last[0] + last[1] === i) last[1]++; else out.push([i, 1]); });
  return out;
}

function colIdx_(L) {
  var s = String(L || '').toUpperCase().replace(/[^A-Z]/g, ''), x = 0;
  for (var i = 0; i < s.length; i++) x = x * 26 + (s.charCodeAt(i) - 64);
  return x;
}
