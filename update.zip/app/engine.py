"""MEGA GAMING - mesin pemantau mutasi myBCA (ADB + uiautomator) + Telegram.
Logika baca layar sama dengan mybca_mutasi.py yang sudah terbukti jalan; dibungkus jadi Engine yang bisa dikontrol dari GUI."""
import os, sys, re, csv, json, time, hashlib, hmac, threading, subprocess, configparser, html, collections
import urllib.request, urllib.error
import xml.etree.ElementTree as ET
import secrets as _secrets
from ledger import Ledger, ListStore
from datetime import datetime, timedelta

APP = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(APP)
CONFIG_FILE = os.path.join(BASE, "config.ini")
CSV_FILE = os.path.join(BASE, "mybca_mutasi.csv")
PENDING_FILE = os.path.join(BASE, "pending.jsonl")
SETTLED_FILE = os.path.join(BASE, "pending_settled.txt")
SALDO_FILE = os.path.join(BASE, "saldo.csv")
SHEET_FILE = os.path.join(BASE, "sheet_pending.jsonl")
NOTIF_FILE = os.path.join(BASE, "notif_prev.json")
EXTRA_SEEN = os.path.join(BASE, "seen_extra.txt")
NOWIN = 0x08000000 if os.name == "nt" else 0          # jangan munculkan jendela CMD tiap panggil adb
TG_BASE = os.environ.get("TG_API_BASE", "https://api.telegram.org")
try: VERSION = open(os.path.join(APP, "VERSION"), encoding="utf-8").read().strip() or "2.0"
except OSError: VERSION = "2.0"

DEFAULTS = {
    "label": "NAMA-REKENING", "serial": "", "interval": "30", "pages": "1", "swipe_ms": "1200", "scroll_pct": "0.20",
    "refresh": "1", "refresh_mode": "reenter", "enter_text": "View Account Transactions", "stay_awake": "1",
    "alerts": "1", "autostart": "1", "show_balance": "1", "source": "auto", "balance_every": "5", "bo_secret": "", "sites": "", "update_url": "", "theme": "awal", "sheet_url": "", "sheet_secret": "",
    "telegram_token": "", "telegram_chat_id": "", "telegram_topic_id": "",
    # pencocokan nama + auto reject (diatur di Pengaturan)
    "rej_wait": "10", "rej_window": "3", "name_min": "60", "name_diff": "35", "rej_receipt": "1", "rej_name": "1", "rej_amount": "1",
    # nama e-wallet: teks yang muncul di mutasi/notifikasi = nama yang dicatat
    "ewallet_map": "ESPAY=DANA, VISIONET=OVO, DOMPET ANAK BANGSA=GOPAY, GOPAY=GOPAY, GOJEK=GOPAY, AIRPAY=SHOPEEPAY, SHOPEE=SHOPEEPAY, FINARYA=LINKAJA, FINTEK KARYA=LINKAJA, LINKAJA=LINKAJA",
    # kolom buku hitungan (per website) untuk tombol salin
    "sheet_cols": "jam=C,user=E,nominal=G,nama=R", "sheet_jam": "hms",
    # peringatan besar di Beranda kalau saldo myBCA sudah >= ini (0 = mati)
    "saldo_max": "3000000",
}
MON_ID = {"Jan": "Jan", "Feb": "Feb", "Mar": "Mar", "Apr": "Apr", "May": "Mei", "Jun": "Jun", "Jul": "Jul", "Aug": "Agu",
          "Sep": "Sep", "Oct": "Okt", "Nov": "Nov", "Dec": "Des"}

# ======================= parsing layar myBCA (sama seperti script lama) =======================
BOUNDS = re.compile(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]")
IDR = re.compile(r"^IDR\s*([\d.,]+)$", re.I)
MONTH_HDR = re.compile(r"^(January|February|March|April|May|June|July|August|September|October|November|December|"
                       r"Januari|Februari|Maret|Mei|Juni|Juli|Agustus|Oktober|Desember)$", re.I)
STOP = {"TRSF", "TRANSFER", "E-BANKING", "EBANKING", "CR", "DB", "DR", "DARI", "FROM", "KE", "TO", "BI-FAST", "BIFAST", "SWITCHING",
        "TRANSAKSI", "MUTASI", "SALDO", "TANGGAL", "KREDIT", "DEBIT", "MYBCA", "BCA", "KODE", "BERHASIL", "NEWS", "KETERANGAN"}
SUFFIX_NOISE = ["ESPAY DEBIT INDONESIA", "ESPAY DEBIT INDONE"]

def texts(xml):
    root = ET.fromstring(xml)
    items = []
    for n in root.iter("node"):
        t = (n.get("text") or "").strip() or (n.get("content-desc") or "").strip()
        if not t: continue
        m = BOUNDS.match(n.get("bounds") or "")
        if not m: continue
        x1, y1, x2, y2 = map(int, m.groups())
        items.append({"t": t, "x": x1, "y": y1, "x2": x2, "y2": y2})
    items.sort(key=lambda a: (a["y"], a["x"]))
    return items

def rawnodes(xml):
    out = []
    for n in ET.fromstring(xml).iter("node"):
        m = BOUNDS.match(n.get("bounds") or "")
        if not m: continue
        x1, y1, x2, y2 = map(int, m.groups())
        out.append({"t": (n.get("text") or "").strip() or (n.get("content-desc") or "").strip(), "x": x1, "y": y1, "x2": x2, "y2": y2,
                    "click": n.get("clickable") == "true", "id": n.get("resource-id") or ""})
    return out

LOGOUT_RE = re.compile(r"log\s?out|sign\s?out|keluar", re.I)
CONFIRM_RE = re.compile(r"^(yes|ya|ok|oke|logout|log out|keluar|confirm|sure|continue)$", re.I)

def to_int(s):
    s = re.sub(r"[.,]\d{1,2}$", "", s) if re.search(r"[.,]\d{1,2}$", s) and not re.search(r"[.,]\d{3}$", s) else s
    return int(re.sub(r"\D", "", s) or 0)

EWALLET = []          # [(teks di mutasi, nama e-wallet)], diisi dari config (ewallet_map)

def parse_ewallet(txt):
    out = []
    for part in re.split(r"[,;\n]+", str(txt or "")):
        if "=" not in part: continue
        k, v = part.split("=", 1)
        k, v = " ".join(k.upper().split()), " ".join(v.upper().split())
        if len(k) >= 3 and v: out.append((k, v))
    return sorted(out, key=lambda kv: -len(kv[0]))           # teks terpanjang dicek duluan

def set_ewallet(txt):
    global EWALLET
    EWALLET = parse_ewallet(txt)
    try:
        import ledger as _lg; _lg.set_generic([k for k, _ in EWALLET] + [v for _, v in EWALLET])
    except Exception: pass

def ewallet_of(desc):
    u = " ".join(str(desc or "").upper().split())
    return next((v for k, v in EWALLET if k in u), "")

def clean_name(desc):
    ew = ewallet_of(desc)
    if ew: return ew                                           # top up / transfer dari e-wallet: catat nama e-wallet-nya
    u = re.sub(r"TANGGAL\s*:\s*\d+/\d+", " ", desc.upper())
    for n in SUFFIX_NOISE: u = u.replace(n, " ")
    if "GOPAY" in u: return "GOPAY"
    m = re.match(r"^\s*TRF\s+(.+?)\s+\d{3}\s", u + " ")
    if m: return m.group(1).strip()
    m = re.match(r"^\s*TRANSFER\s+(?:DR|CR)?\s*\d{3}\s+(.+)$", u)
    if m: return m.group(1).strip()
    words = []
    for w in u.split():
        if "-" in w and re.match(r"^[A-Z]{3,8}-", w): w = w.split("-", 1)[1]
        if not w or re.search(r"[\d/]", w) or w in STOP: continue
        words.append(w)
    return " ".join(words).strip(" -:.")

def parse_entries(items, only_credit=True):
    entries, buf = [], []
    for it in sorted(items, key=lambda a: (a["y"], a["x"])):
        t = it["t"]
        if it["x"] < 60 and MONTH_HDR.match(t):
            buf = [b for b in buf if b["y"] >= it["y"] - 40]; continue     # header "October" kadang menimpa baris pertama
        m = IDR.match(t)
        if not m:
            buf.append(it); continue
        amount = to_int(m.group(1))
        tx = [b["t"] for b in buf]
        tipe = next((x for x in tx if re.search(r"\b(CR|DB|DR)$", x.strip(), re.I)), "")
        day = next((x for x in tx if re.fullmatch(r"\d{1,2}", x)), "")
        mon = next((x for x in tx if re.fullmatch(r"[A-Za-z]{3}", x)), "")
        yr = next((x for x in tx if re.fullmatch(r"20\d\d", x)), "")
        pend = any(x.strip().upper() == "PEND" for x in tx) and not (day and mon)
        desc = next((x for x in tx if x != tipe and x not in (day, mon, yr) and x.strip().upper() != "PEND" and not re.fullmatch(r"[A-Za-z]{3}", x)), "")
        buf = []
        if not (desc and tipe and ((day and mon) or pend)): continue
        ttype = "DB" if re.search(r"(DB|DR)$", tipe.strip(), re.I) else "CR"
        if pend:
            entries.append({"date": time.strftime("%d %b %Y"), "amount": amount, "type": ttype, "pending": True,
                            "name": clean_name(desc), "raw": f"{desc} | {tipe} | PEND | IDR {m.group(1)}"})
            continue
        entries.append({"date": f"{day} {mon} {yr or time.localtime().tm_year}", "amount": amount, "type": ttype,
                        "name": clean_name(desc), "raw": f"{desc} | {tipe} | {day} {mon} {yr} | IDR {m.group(1)}"})
    if only_credit: entries = [e for e in entries if e["type"] == "CR"]
    return entries

def eid(e):
    desc = e["raw"].split(" | ")[0]
    dm = "PEND" if " | PEND | " in e["raw"] else " ".join(e["date"].split()[:2])
    return hashlib.md5(f'{desc}|{e["amount"]}|{dm}'.encode()).hexdigest()[:16]

def with_ids(entries):
    cnt, out = {}, []
    for e in entries:
        b = eid(e); n = cnt.get(b, 0); cnt[b] = n + 1
        out.append((b if n == 0 else f"{b}#{n}", e))
    return out

def find_node(items, needle):
    n = needle.lower()
    return next((i for i in items if n in i["t"].lower()), None)

def is_mutasi(items):
    return any(IDR.match(i["t"]) for i in items)

NOTIF_RES = [re.compile(p, re.I | re.S) for p in (
    r"You (?:have )?received\s+(?:IDR|Rp\.?)\s*([\d.,]+)\s+from\s+(.+?)(?:\s+at\s+.+?categor|\s+on\s+\d|\s+via\s+|\.\s|\.?$)",
    r"(?:Incoming|Received)\b.*?(?:IDR|Rp\.?)\s*([\d.,]+).*?\bfrom\s+(.+?)(?:\s+at\s+|\s+on\s+\d|\s+via\s+|\.\s|\.?$)",
    r"(?:Anda menerima|Dana masuk|Uang masuk)\b.*?(?:IDR|Rp\.?)\s*([\d.,]+).*?\bdari\s+(.+?)(?:\s+pada\s+|\s+ke\s+|\s+via\s+|\.\s|\.?$)",
    r"(?:Top ?up|Topup)\b.*?(?:IDR|Rp\.?)\s*([\d.,]+).*?\b(?:from|dari)\s+(.+?)(?:\s+at\s+|\s+pada\s+|\s+on\s+\d|\.\s|\.?$)",
)]
MONEY_RE = re.compile(r"(?:IDR|Rp\.?)\s*\d", re.I)

def notif_match(t):
    t = " ".join(str(t or "").split())
    for rx in NOTIF_RES:
        m = rx.search(t)
        if m and m.group(2).strip(" .,"): return to_int(m.group(1)), m.group(2).strip(" .,")
    return None
DATE_RE = re.compile(r"^\d{1,2}\s+[A-Za-z]{3}\w*\s+20\d\d$")

def is_feed(items):
    return any(i["t"].strip().lower() == "info & transactions" for i in items)

def parse_feed(items):
    """Layar For You > Info & Transactions: kalimat 'You received IDR x from NAMA at Account Transfer category.' + tanggal. Urut dari atas (terbaru)."""
    dates = [i for i in items if DATE_RE.match(i["t"].strip())]
    out = []
    for it in sorted(items, key=lambda a: (a["y"], a["x"])):
        m = notif_match(it["t"])
        if not m: continue
        d = [x for x in dates if x["y"] <= it["y"] and it["y"] - x["y"] < 120]
        date = max(d, key=lambda x: x["y"])["t"].strip() if d else time.strftime("%d %b %Y")
        name = " ".join(m[1].split())
        out.append({"amount": m[0], "name": clean_name(name) or name, "full": name, "date": date, "y": it["y"]})
    return out

def feed_unread(items):
    """Teks di layar notifikasi yang memuat nominal tapi tidak bisa dibaca (untuk diperiksa / ditambahkan polanya)."""
    return [it["t"] for it in items if MONEY_RE.search(it["t"]) and not notif_match(it["t"]) and len(it["t"]) > 12]

def feed_new(cur, prev):
    """cur/prev = daftar signature terbaru-di-atas. Kembalikan (jumlah_baru, pasti). Baru = baris di atas titik yang cocok dengan prev."""
    if not prev: return 0, True
    for k in range(len(cur) + 1):
        m = min(len(prev), len(cur) - k, 5)
        if m >= 1 and cur[k:k + m] == prev[:m]: return k, True
        if m < 1: break
    ps, n = collections.Counter(prev), 0
    for x in cur:
        if ps[x] > 0: ps[x] -= 1
        else: n += 1
    return n, False

def esc(x): return html.escape(str(x), quote=False)

def rp(n): return f"{int(n):,}".replace(",", ".")

def parse_tx_date(s):
    try:
        d, m, y = (s.split() + ["", "", ""])[:3]
        return datetime.strptime(f"{int(d)} {m[:3].title()} {y}", "%d %b %Y").date()
    except Exception:
        return None

# ======================= config + profil website =======================
# Tiap website (brand) punya folder sendiri di profil/<NAMA>/ : config, buku, csv, saldo. Token Telegram, chat id,
# kode rahasia BO, alamat website, dan link Sheet dipakai bersama (disimpan di config.ini utama).
SHARED = ("telegram_token", "telegram_chat_id", "bo_secret", "sites", "sheet_url", "sheet_secret", "update_url", "theme", "ewallet_map")
ROOT_CONFIG = os.path.join(BASE, "config.ini")
PROFILE = None
LEGACY_FILES = ("mybca_mutasi.csv", "saldo.csv", "buku.json", "notif_prev.json", "seen_extra.txt", "pending.jsonl", "pending_settled.txt", "sheet_pending.jsonl")

def prof_key(n): return re.sub(r"[^A-Z0-9]", "", str(n or "").upper())
def prof_dir(name): return os.path.join(BASE, "profil", re.sub(r"[^A-Za-z0-9_-]", "_", str(name)))

def _read_ini(path):
    cp = configparser.ConfigParser(interpolation=None)
    try: cp.read(path, encoding="utf-8")
    except Exception: pass
    return {k: v.strip() for k, v in cp["main"].items()} if cp.has_section("main") else {}

def _write_ini(path, cfg):
    lines = ["[main]", "; Diatur dari aplikasi MEGA GAMING (Pengaturan). Boleh juga diedit manual."]
    for k in DEFAULTS: lines.append(f"{k} = {cfg.get(k, DEFAULTS[k])}")
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\r\n") as f: f.write("\n".join(lines) + "\n")
    os.replace(tmp, path)

def set_profile(name):
    """Pindah folder data ke website `name` (None = belum memilih website)."""
    global PROFILE, ACT_FILE, OUT_FILE, CONFIG_FILE, CSV_FILE, PENDING_FILE, SETTLED_FILE, SALDO_FILE, SHEET_FILE, NOTIF_FILE, EXTRA_SEEN, LEDGER_FILE
    PROFILE = name or None
    if not PROFILE:
        d = BASE; CONFIG_FILE = ROOT_CONFIG
    else:
        d = prof_dir(PROFILE); first = not os.path.isdir(os.path.join(BASE, "profil")) or not os.listdir(os.path.join(BASE, "profil"))
        os.makedirs(d, exist_ok=True)
        CONFIG_FILE = os.path.join(d, "config.ini")
        if first and not os.path.exists(CONFIG_FILE):        # pemakaian lama (sebelum ada profil): data lama ikut ke website pertama yang dipilih
            import shutil
            for fn in LEGACY_FILES:
                if os.path.exists(os.path.join(BASE, fn)) and not os.path.exists(os.path.join(d, fn)):
                    try: shutil.copy2(os.path.join(BASE, fn), os.path.join(d, fn))
                    except Exception: pass
            old = _read_ini(ROOT_CONFIG)
            if old.get("serial"): _write_ini(CONFIG_FILE, {**DEFAULTS, **{k: v for k, v in old.items() if k in DEFAULTS and k not in SHARED}})
    CSV_FILE = os.path.join(d, "mybca_mutasi.csv"); PENDING_FILE = os.path.join(d, "pending.jsonl"); SETTLED_FILE = os.path.join(d, "pending_settled.txt")
    SALDO_FILE = os.path.join(d, "saldo.csv"); SHEET_FILE = os.path.join(d, "sheet_pending.jsonl"); NOTIF_FILE = os.path.join(d, "notif_prev.json")
    EXTRA_SEEN = os.path.join(d, "seen_extra.txt"); LEDGER_FILE = os.path.join(d, "buku.json")
    ACT_FILE = os.path.join(d, "aksi.json"); OUT_FILE = os.path.join(d, "keluar.json")

LEDGER_FILE = os.path.join(BASE, "buku.json")
ACT_FILE = os.path.join(BASE, "aksi.json")
OUT_FILE = os.path.join(BASE, "keluar.json")

def load_config():
    cfg = dict(DEFAULTS)
    root = _read_ini(ROOT_CONFIG)
    if not PROFILE:
        for k, v in root.items():
            if k in DEFAULTS or k == "webhook": cfg[k] = v
        return cfg
    for k in SHARED:
        if k in root: cfg[k] = root[k]
    for k, v in _read_ini(CONFIG_FILE).items():
        if k in DEFAULTS and k not in SHARED: cfg[k] = v
    cfg["label"] = PROFILE
    return cfg

def save_config(cfg):
    if not PROFILE:
        _write_ini(ROOT_CONFIG, cfg); return
    root = {**DEFAULTS, **_read_ini(ROOT_CONFIG)}
    for k in SHARED: root[k] = cfg.get(k, root.get(k, DEFAULTS[k]))
    _write_ini(ROOT_CONFIG, root)
    _write_ini(CONFIG_FILE, {**cfg, "label": PROFILE})

# ======================= engine =======================
class Engine:
    def __init__(self):
        self.lock = threading.RLock()
        self.cfg = load_config()
        self.logs = collections.deque(maxlen=400)
        self.running = False; self.paused = False; self.busy = False
        self.stop_ev = threading.Event(); self.wake_ev = threading.Event(); self.thread = None; self.gen = 0
        self.next_check = 0.0; self.last_check = 0.0
        self.hp = {"state": "unknown", "detail": ""}
        self.empty_streak = 0
        self.session_new = []
        self.stats = {"cek_ok": 0, "sambung_ulang": 0, "gagal_tg": 0}
        self.seen = set(); self.seen_pend = []; self.screen_hint = ""; self.balance = None; self.dep_since_bal = 0; self.bal_warned = False; self.backoff = 0; self.fb_until = 0; self.fb_wait = 0; self.notif_pool = []; self.ok_since = None
        self.sheet_lock = threading.Lock(); self.sheet_busy = False; self.sheet_err = ""; self.sheet_ok_at = 0
        self._csv_cache = (None, [])
        set_ewallet(self.cfg.get("ewallet_map", "")); self.mut_prev = None; self.unread_seen = set()
        self.blind_until = 0.0; self.unknown = []      # blind: auto reject dijeda (bacaan myBCA mungkin tidak lengkap); unknown: [(nominal, ts)] notif tak terbaca
        self.ledger = Ledger(LEDGER_FILE); self.ledger.configure(self.cfg); self.act = ListStore(ACT_FILE); self.out = ListStore(OUT_FILE); self.out_seen = {r.get('id') for r in self.out.view()}; self._out_last = {}
        if not self.cfg.get("bo_secret"):
            self.cfg["bo_secret"] = _secrets.token_hex(6)
            try: save_config(self.cfg)
            except Exception: pass
        self.log("INFO", f"MEGA GAMING v{VERSION} siap")

    # ---------- util ----------
    def log(self, level, msg):
        with self.lock: self.logs.append({"ts": time.time(), "lv": level, "msg": msg})

    @property
    def adb_path(self):
        p = os.path.join(BASE, "adb.exe")
        return p if os.path.exists(p) else "adb"

    def adb(self, *args, serial=None, timeout=30, use_serial=True):
        s = (self.cfg.get("serial", "") if serial is None else serial) if use_serial else ""
        cmd = [self.adb_path] + (["-s", s] if s else []) + list(args)
        try:
            r = subprocess.run(cmd, capture_output=True, timeout=timeout, creationflags=NOWIN)
        except subprocess.TimeoutExpired:
            return f"error: timed out ({timeout} detik, tidak ada respons dari HP)"
        return r.stdout.decode("utf-8", "ignore") + ("" if r.stdout else r.stderr.decode("utf-8", "ignore"))

    def dump_xml(self):
        out = self.adb("exec-out", "uiautomator", "dump", "/dev/tty")
        i, j = out.find("<?xml"), out.rfind("</hierarchy>")
        if i < 0 or j < 0: raise RuntimeError("layar tidak bisa dibaca (HP terkunci / app memblokir / adb putus): " + out.strip()[:120])
        return out[i:j + len("</hierarchy>")]

    def screen_size(self):
        m = re.search(r"(\d+)x(\d+)", self.adb("shell", "wm", "size"))
        return (int(m.group(1)), int(m.group(2))) if m else (1080, 2400)

    def swipe(self, x, y1, y2, ms=400):
        self.adb("shell", "input", "swipe", str(x), str(y1), str(x), str(y2), str(ms))

    def wait_for(self, pred, timeout, step=0.8):
        end = time.time() + timeout
        while time.time() < end and not self.stop_ev.is_set():
            try:
                items = texts(self.dump_xml())
                if pred(items): return items
            except Exception: pass
            time.sleep(step)
        return None

    def tap_node(self, it, mode="tap"):
        cx, cy = (it["x"] + it["x2"]) // 2, (it["y"] + it["y2"]) // 2
        if mode == "tap": self.adb("shell", "input", "tap", str(cx), str(cy))
        else: self.adb("shell", "input", "swipe", str(cx), str(cy), str(cx), str(cy), "120")

    # ---------- Google Sheet (Apps Script web app) ----------
    def sheet_on(self): return self.cfg.get("sheet_url", "").startswith("http")

    def sheet_count(self):
        try:
            with open(SHEET_FILE, encoding="utf-8") as f: return sum(1 for l in f if l.strip())
        except OSError: return 0

    def sheet_enqueue(self, row):
        if not self.sheet_on(): return
        row = {**row, "label": self.cfg.get("label", "")}
        with self.sheet_lock:
            with open(SHEET_FILE, "a", encoding="utf-8") as f: f.write(json.dumps(row, ensure_ascii=False) + "\n")
        self.sheet_kick()

    def sheet_kick(self):
        if self.sheet_busy or not self.sheet_on() or not self.sheet_count(): return
        threading.Thread(target=self._sheet_flush, daemon=True).start()

    def sheet_post(self, rows):
        body = json.dumps({"secret": self.cfg.get("sheet_secret", ""), "rows": rows}, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(self.cfg["sheet_url"], body, {"Content-Type": "text/plain;charset=utf-8"})
        raw = urllib.request.urlopen(req, timeout=30).read().decode("utf-8", "ignore")
        try: return json.loads(raw)
        except ValueError: return {"ok": False, "error": "balasan bukan dari Apps Script. Cek link (harus berakhiran /exec) dan akses 'Anyone'"}

    def _sheet_flush(self):
        if self.sheet_busy: return
        self.sheet_busy = True
        try:
            while True:
                with self.sheet_lock:
                    try: lines = [l for l in open(SHEET_FILE, encoding="utf-8").read().splitlines() if l.strip()]
                    except OSError: lines = []
                batch = lines[:50]
                if not batch: break
                rows = []
                for l in batch:
                    try: rows.append(json.loads(l))
                    except ValueError: pass
                try: r = self.sheet_post(rows)
                except Exception as ex: r = {"ok": False, "error": str(ex).replace(self.cfg.get("sheet_secret", "") or "\0", "***")[:100]}
                if not r.get("ok"):
                    err = str(r.get("error", "gagal"))[:100]
                    if err != self.sheet_err: self.log("WARN", "Google Sheet gagal: " + err)
                    self.sheet_err = err; break
                with self.sheet_lock:
                    try: cur = [l for l in open(SHEET_FILE, encoding="utf-8").read().splitlines() if l.strip()]
                    except OSError: cur = []
                    left = cur[len(batch):]
                    if left:
                        with open(SHEET_FILE, "w", encoding="utf-8") as f: f.write("\n".join(left) + "\n")
                    else:
                        try: os.remove(SHEET_FILE)
                        except OSError: pass
                if self.sheet_err: self.log("OK", "Google Sheet tersambung lagi")
                self.sheet_err = ""; self.sheet_ok_at = time.time()
        finally:
            self.sheet_busy = False

    def sheet_test(self, url="", secret=""):
        if url: self.cfg["sheet_url"] = url.strip()
        if secret and not secret.startswith("•"): self.cfg["sheet_secret"] = secret.strip()
        if not self.sheet_on(): return {"ok": False, "msg": "Isi link Web app (https://script.google.com/.../exec) dulu"}
        try: r = self.sheet_post([{"kind": "test"}])
        except Exception as ex: return {"ok": False, "msg": "Gagal tersambung: " + str(ex)[:100]}
        return {"ok": bool(r.get("ok")), "msg": "Tersambung ke Google Sheet" if r.get("ok") else "Ditolak: " + str(r.get("error", ""))[:100]}

    # ---------- saldo ----------
    def read_balance(self):
        """Saldo ada di kartu atas (di atas tab 'Account Transactions'). Ketuk ikon mata kalau tersembunyi. Return int atau None."""
        w, h = self.screen_size()
        def top(xml):
            items = texts(xml)
            tab = next((i for i in items if "account transactions" in i["t"].lower() and i["y"] < h * .4), None)
            limit = tab["y"] if tab else int(h * .25)
            cand = [i for i in items if i["y2"] <= limit and re.fullmatch(r"(IDR\s*)?\d[\d.,]{3,}", i["t"].strip(), re.I)]
            return limit, cand
        def val(cand):
            for c in cand:
                m = re.search(r"(\d[\d.,]*)", c["t"])
                if m: return to_int(m.group(1))
            return None
        xml = self.dump_xml(); limit, cand = top(xml)
        v = val(cand)
        if v is not None: return v
        if not any("account transactions" in i["t"].lower() for i in texts(xml)): return None   # bukan layar Mutasi: jangan ketuk apa pun
        eyes = [n for n in rawnodes(xml) if n["click"] and n["x"] > w * .7 and 180 < n["y"] and n["y2"] <= limit + 12 and n["y2"] - n["y"] < h * .08]
        if eyes: self.tap_node(max(eyes, key=lambda n: n["y"]))
        else: self.adb("shell", "input", "tap", str(int(w * .833)), str(int(h * .184)))
        time.sleep(1.0)
        xml2 = self.dump_xml(); limit, cand = top(xml2)
        v = val(cand)
        if v is None and not getattr(self, "bal_dumped", False):
            self.bal_dumped = True
            try:
                with open(os.path.join(BASE, "debug_saldo.xml"), "w", encoding="utf-8") as f: f.write(xml2)
                self.log("INFO", "Dump layar disimpan ke debug_saldo.xml untuk diperiksa")
            except OSError: pass
        return v

    def note_balance(self, val):
        prev = self.balance
        rec = {"amount": val, "ts": time.time(), "at": time.strftime("%H:%M:%S"), "delta": None, "dep": 0, "other": None}
        if prev and prev["amount"] == val:
            rec.update(delta=prev["delta"], dep=prev["dep"], other=prev["other"]);
            self.balance = rec; return                       # saldo belum berubah: deposit yang tercatat terus dihitung
        dep = self.dep_since_bal; self.dep_since_bal = 0
        if prev: rec.update(delta=val - prev["amount"], dep=dep, other=val - prev["amount"] - dep)
        self.balance = rec
        self.sheet_enqueue({"kind": "saldo", "ts": time.strftime("%Y-%m-%d %H:%M:%S"), "amount": val, "delta": "" if rec["delta"] is None else rec["delta"],
                            "dep": rec["dep"], "other": "" if rec["other"] is None else rec["other"]})
        ex = os.path.exists(SALDO_FILE)
        with open(SALDO_FILE, "a", newline="", encoding="utf-8") as f:
            wr = csv.writer(f)
            if not ex: wr.writerow(["waktu", "saldo", "selisih", "deposit_tercatat"])
            wr.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), val, "" if rec["delta"] is None else rec["delta"], dep])

    # ---------- logout myBCA (untuk ganti HP) ----------
    def logout_mybca(self):
        """Jeda pemantauan, kembali ke Beranda myBCA, ketuk ikon logout, konfirmasi."""
        self.paused = True
        end = time.time() + 40
        while self.busy and time.time() < end: time.sleep(.5)
        def shot():
            xml = self.dump_xml(); return xml, texts(xml)
        def sample(items): return ", ".join(i["t"][:25] for i in items[:10])
        try:
            xml, items = shot()
            if any(i["t"].strip().lower() in ("login", "log in") for i in items):
                self.log("INFO", "myBCA sudah di layar Login"); return {"ok": True, "msg": "myBCA sudah logout (layar Login). Pemantauan dijeda."}
            home = next((i for i in items if i["t"].upper().startswith("HELLO")), None)
            for _ in range(3):
                if home or any(i["t"].strip().lower() == "home" for i in items): break
                self.adb("shell", "input", "keyevent", "4"); time.sleep(1.5)
                xml, items = shot()
                home = next((i for i in items if i["t"].upper().startswith("HELLO")), None)
            if not home:
                tabs = [i for i in items if i["t"].strip().lower() == "home"]
                if tabs:
                    self.tap_node(max(tabs, key=lambda i: i["y"]))
                    items = self.wait_for(lambda it: any(i["t"].upper().startswith("HELLO") for i in it), 8) or []
                    xml, items = shot() if not items else (self.dump_xml(), items)
                    home = next((i for i in items if i["t"].upper().startswith("HELLO")), None)
            if not home: return {"ok": False, "msg": "Tidak menemukan Beranda myBCA. Layar terbaca: " + sample(items)}
            raw = rawnodes(xml); w, h = self.screen_size()
            cand = next((n for n in raw if LOGOUT_RE.search(n["t"]) or LOGOUT_RE.search(n["id"])), None)
            if not cand:
                row = [n for n in raw if n["click"] and n["y2"] <= home["y"] and n["y2"] - n["y"] < h * .12 and n["x"] > w * .6]
                cand = max(row, key=lambda n: n["x"]) if row else None
            if cand: self.tap_node(cand)
            else: self.adb("shell", "input", "tap", str(int(w * .918)), str(int(home["y"] - h * .046)))
            time.sleep(1.5)
            for _ in range(2):
                items = texts(self.dump_xml())
                if any(i["t"].strip().lower() in ("login", "log in") for i in items): break
                btn = next((i for i in items if CONFIRM_RE.match(i["t"].strip())), None)
                if btn: self.tap_node(btn); time.sleep(2)
            items = self.wait_for(lambda it: any(i["t"].strip().lower() in ("login", "log in") for i in it), 10) or []
            if items:
                self.log("OK", "Logout myBCA berhasil"); return {"ok": True, "msg": "Logout berhasil. Pemantauan dijeda; tekan Lanjut setelah login lagi di HP baru."}
            return {"ok": False, "msg": "Ikon logout sudah diketuk tapi layar Login belum muncul. Cek HP dan logout manual."}
        except Exception as ex:
            return {"ok": False, "msg": "Gagal: " + str(ex)[:140]}

    # ---------- navigasi otomatis ----------
    def ensure_mutasi(self):
        """Kalau myBCA ada di Beranda (sudah login), masuk otomatis: tab My Account -> View Account Transactions & Info."""
        enter = self.cfg["enter_text"] or "View Account Transactions"
        try: items = texts(self.dump_xml())
        except Exception: return
        self.screen_hint = ""
        if is_mutasi(items) or find_node(items, enter): return
        if any(i["t"].strip().lower() in ("login", "log in") for i in items):
            self.screen_hint = "login"; return
        tabs = [i for i in items if i["t"].strip().lower() == "my account"]
        if not tabs: return
        self.log("INFO", "myBCA di Beranda, masuk otomatis ke My Account")
        self.tap_node(max(tabs, key=lambda i: i["y"]))
        it = self.wait_for(lambda it: find_node(it, enter), 8)
        node = find_node(it or [], enter)
        if not node: self.log("WARN", f'Tombol "{enter}" tidak muncul setelah buka My Account'); return
        for mode in ("tap", "swipe"):
            self.tap_node(node, mode)
            if self.wait_for(is_mutasi, 9): self.log("OK", "Masuk otomatis ke Mutasi berhasil"); return
        self.log("WARN", "Gagal masuk otomatis ke Mutasi")

    # ---------- refresh / scan ----------
    def reenter(self):
        enter = self.cfg["enter_text"] or "View Account Transactions"
        items = self.wait_for(lambda it: it, 5) or []
        node = find_node(items, enter)
        if not node:
            if not find_node(items, "Account Transactions") and not is_mutasi(items):
                self.log("WARN", "Layar tidak dikenali (bukan Mutasi / My Account), BACK tidak ditekan"); return False
            self.adb("shell", "input", "keyevent", "4"); time.sleep(1.2)
            items = self.wait_for(lambda it: find_node(it, enter), 8) or []
            node = find_node(items, enter)
            if not node:
                self.log("WARN", f'Tombol "{enter}" tidak ditemukan setelah BACK'); return False
        for mode in ("tap", "swipe"):
            self.tap_node(node, mode)
            if self.wait_for(is_mutasi, 9): return True
        self.log("WARN", "Gagal masuk ulang ke Mutasi"); return False

    def pull_refresh(self):
        w, h = self.screen_size(); x = w // 2
        self.swipe(x, int(h * .35), int(h * .80), 250); time.sleep(.4)
        self.swipe(x, int(h * .35), int(h * .80), 250); time.sleep(2.0)

    def scan(self, pages, only_credit, swipe_ms):
        found, ok, shots, outs = {}, False, [], {}
        self._out_last = outs
        def collect():
            nonlocal ok
            items = texts(self.dump_xml())
            if any(IDR.match(i["t"]) for i in items): ok = True
            shots.append({eid(e) for e in parse_entries(items, False)})
            for i, e in with_ids(parse_entries(items, False)):
                if e["type"] == "DB": outs.setdefault(i, e)
                else: found.setdefault(i, e)
        collect()
        if pages > 0:
            w, h = self.screen_size()
            x, bot = w // 2, int(h * .72)
            top = bot - int(h * float(self.cfg["scroll_pct"] or .2))
            for _ in range(pages):
                self.swipe(x, bot, top, swipe_ms); time.sleep(1.0); collect()
            for _ in range(pages): self.swipe(x, top, bot, max(swipe_ms, 800))
            time.sleep(.8)
            for a, b in zip(shots, shots[1:]):
                if a and b and not (a & b):
                    self.log("WARN", "Scroll terlalu jauh, ada transaksi yang mungkin terlewat. Naikkan swipe_ms di config.ini"); break
        return found, ok

    # ---------- data ----------
    def load_seen(self):
        seen = set()
        for r in self.read_csv(force=True):
            seen.add(r["id"])
            try: seen.add(eid({"raw": r["raw"], "date": r["date"], "amount": int(r["amount"])}))
            except Exception: pass
        try: seen.update(open(EXTRA_SEEN, encoding="utf-8").read().split())
        except OSError: pass
        return seen

    def read_csv(self, force=False):
        try: mt = os.path.getmtime(CSV_FILE)
        except OSError: return []
        if not force and self._csv_cache[0] == mt: return self._csv_cache[1]
        rows = []
        try:
            with open(CSV_FILE, newline="", encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    try: r["amount"] = int(r["amount"]); rows.append(r)
                    except Exception: pass
        except Exception: pass
        self._csv_cache = (mt, rows)
        return rows

    def save(self, new):
        exists = os.path.exists(CSV_FILE)
        with open(CSV_FILE, "a", newline="", encoding="utf-8") as f:
            wr = csv.DictWriter(f, fieldnames=["id", "seen_at", "date", "type", "amount", "name", "raw"])
            if not exists: wr.writeheader()
            for i, e in new.items():
                wr.writerow({"id": i, "seen_at": time.strftime("%Y-%m-%d %H:%M:%S"), **{k: e[k] for k in ("date", "type", "amount", "name", "raw")}})

    # ---------- telegram ----------
    def tg_ready(self): return bool(self.cfg["telegram_token"] and self.cfg["telegram_chat_id"])

    def tg_api(self, method, payload=None, token=None):
        token = token or self.cfg["telegram_token"]
        url = f"{TG_BASE}/bot{token}/{method}"
        try:
            req = urllib.request.Request(url, json.dumps(payload or {}).encode(), {"Content-Type": "application/json"})
            return json.loads(urllib.request.urlopen(req, timeout=12).read())
        except urllib.error.HTTPError as ex:
            try: return json.loads(ex.read())
            except Exception: return {"ok": False, "description": f"HTTP {ex.code}"}
        except Exception as ex:
            return {"ok": False, "description": str(ex).replace(token, "***")}

    def tg_text(self, p):
        lab = f" · {esc(p.get('label'))}" if p.get("label") else ""
        if p.get("type") == "ALERT": return f"⚠️ <b>PERINGATAN</b>{lab}\n{esc(p.get('msg', ''))}"
        if p.get("type") == "INFO": return f"✅ <b>INFO</b>{lab}\n{esc(p.get('msg', ''))}"
        amt = int(p.get("amount", 0))
        return (f"💰 <b>DEPOSIT MASUK</b>{lab}\nNominal: <code>{amt}</code>  (Rp {rp(amt)})\n"
                f"Nama: <code>{esc(p.get('name') or '-')}</code>\nTgl: {esc(p.get('date', ''))}" + ("\nStatus: PENDING (belum diposting bank)" if p.get("pending") else ""))

    def deliver(self, payload):
        msg = {"chat_id": self.cfg["telegram_chat_id"], "text": self.tg_text(payload), "parse_mode": "HTML", "disable_web_page_preview": True}
        if self.cfg["telegram_topic_id"]:
            try: msg["message_thread_id"] = int(self.cfg["telegram_topic_id"])
            except ValueError: pass
        r = self.tg_api("sendMessage", msg)
        if not r.get("ok"): self.log("ERR", "Telegram gagal: " + str(r.get("description"))[:120])
        return bool(r.get("ok")), r.get("description", "")

    def notify(self, payload):
        if not self.tg_ready(): return
        ok, _ = self.deliver(payload)
        if not ok:
            self.stats["gagal_tg"] += 1
            with open(PENDING_FILE, "a", encoding="utf-8") as f: f.write(json.dumps({"kind": "tg", "payload": payload}, ensure_ascii=False) + "\n")

    def pending(self):
        out = []
        if os.path.exists(PENDING_FILE):
            for l in open(PENDING_FILE, encoding="utf-8").read().splitlines():
                try:
                    o = json.loads(l); out.append(o.get("payload", o))
                except Exception: pass
        return out

    def flush_pending(self):
        if not os.path.exists(PENDING_FILE) or not self.tg_ready(): return 0
        lines = [l for l in open(PENDING_FILE, encoding="utf-8").read().splitlines() if l.strip()]
        left = []
        for l in lines:
            try:
                o = json.loads(l)
                if not self.deliver(o.get("payload", o))[0]: left.append(l)
            except Exception: pass
        if left:
            with open(PENDING_FILE, "w", encoding="utf-8") as f: f.write("\n".join(left) + "\n")
        else:
            try: os.remove(PENDING_FILE)
            except OSError: pass
        sent = len(lines) - len(left)
        if sent: self.log("OK", f"{sent} pesan tertunda terkirim ulang")
        return sent

    # ---------- siklus ----------
    def ensure_connected(self):
        s = self.cfg["serial"]
        if ":" in s:
            try: self.adb("connect", s, timeout=15, use_serial=False)
            except Exception: pass

    def ensure_awake(self):
        try:
            if "mWakefulness=Awake" not in self.adb("shell", "dumpsys", "power"):
                self.adb("shell", "input", "keyevent", "224"); time.sleep(1.0)
        except Exception: pass

    def health(self, ok, why=""):
        if ok:
            if self.empty_streak >= 3:
                self.log("OK", "Layar Mutasi terbaca lagi")
                if self.cfg["alerts"] == "1": self.notify({"type": "INFO", "label": self.cfg["label"], "msg": "layar Mutasi terbaca lagi"})
            self.empty_streak = 0; return
        self.empty_streak += 1
        self.log("WARN", f"Layar Mutasi tidak terbaca ({self.empty_streak}x) {why}")
        if self.empty_streak == 3 and self.cfg["alerts"] == "1":
            self.notify({"type": "ALERT", "label": self.cfg["label"], "msg": ("myBCA minta login - buka HP dan masuk lagi" if getattr(self, "screen_hint", "") == "login" else "myBCA tidak di layar Mutasi / logout / layar mati - cek HP")})

    def _pend_pool(self):
        """Pending yang sudah dinotif dan belum 'lunas' (belum muncul dengan tanggal)."""
        pool = []
        for r in self.read_csv(force=True):
            if " | PEND | " in r.get("raw", ""): pool.append({"amount": r["amount"], "name": r.get("name", ""), "id": r["id"]})
        try: done = set(open(SETTLED_FILE, encoding="utf-8").read().split())
        except OSError: done = set()
        return [p for p in pool if p["id"] not in done]

    @staticmethod
    def _same_person(a, b):
        a, b = (a or "").strip(), (b or "").strip()
        if not a or not b: return a == b                      # dulu: nama kosong = cocok dengan siapa saja -> deposit lain bisa tertelan
        return a == b or a in b or b in a

    def _announce(self, new):
        """Catat + kirim notifikasi + antrekan ke Sheet untuk deposit baru (dict id -> entri)."""
        for i, e in new.items():
            self.dep_since_bal += e["amount"]
            if e.get("pending"): self.seen_pend.append({"amount": e["amount"], "name": e["name"], "id": i})
            self.log("OK", f'Deposit baru {e["name"] or "(nama tidak terbaca)"} Rp {rp(e["amount"])}')
            self.sheet_enqueue({"kind": "deposit", "ts": time.strftime("%Y-%m-%d %H:%M:%S"), "name": e["name"], "amount": e["amount"],
                                "status": "PEND" if e.get("pending") else "POSTING", "date": e["date"], "id": i})
            self.notify({**e, "label": self.cfg["label"], "id": i})
            self.ledger.add(i, time.strftime("%Y-%m-%d %H:%M:%S"), e["name"], e["amount"], bool(e.get("pending")))
            with self.lock:
                self.session_new.append({**e, "id": i, "ts": time.time(), "seen_at": time.strftime("%Y-%m-%d %H:%M:%S")})
                self.session_new = self.session_new[-50:]
        if new: self.save(new)
        self.seen.update(new)

    # ---------- sumber: layar notifikasi (For You > Info & Transactions) ----------
    def nav_feed(self):
        """Pastikan myBCA ada di For You > Info & Transactions. Kembalikan item layar, atau None."""
        w, h = self.screen_size()
        for _ in range(5):
            items = texts(self.dump_xml())
            if is_feed(items): return items
            nav = [i for i in items if i["t"].strip().lower() == "for you" and i["y"] > h * .8]
            if nav:
                self.tap_node(nav[0]); it = self.wait_for(lambda it: is_feed(it) or any(i["t"].strip().lower() == "info & transactions" for i in it), 6)
                if it:
                    tab = find_node(it, "info & transactions")
                    if tab and not is_feed(it): self.tap_node(tab)
                    return it
                continue
            if any(i["t"].strip().lower() in ("login", "log in") for i in items):
                self.screen_hint = "login"; return None
            if any(i["t"].strip().lower() == "my account" for i in items) or find_node(items, "Account Transactions"):
                self.adb("shell", "input", "keyevent", "4"); time.sleep(1.2); continue
            self.adb("shell", "input", "keyevent", "4"); time.sleep(1.2)
        return None

    def _load_prev(self):
        try:
            with open(NOTIF_FILE, encoding="utf-8") as f: return json.load(f)
        except Exception: return None

    def _save_prev(self, sigs):
        try:
            with open(NOTIF_FILE, "w", encoding="utf-8") as f: json.dump(sigs, f)
        except Exception: pass

    def cycle_notif(self):
        self.screen_hint = ""
        items = self.nav_feed()
        if items is None:
            self.health(False, "(layar For You tidak ditemukan)")
            if self.screen_hint != "login": self.log("WARN", "Layar For You > Info & Transactions tidak ditemukan. Buka myBCA, login, lalu coba lagi")
            return 0, False
        if self.cfg["refresh"] == "1":
            w, h = self.screen_size(); self.swipe(w // 2, int(h * .35), int(h * .80), 250); time.sleep(1.6)
            try: items = texts(self.dump_xml())
            except Exception: pass
        feed = parse_feed(items)
        ok = is_feed(items)
        for t in feed_unread(items):
            if t in self.unread_seen: continue
            self.unread_seen.add(t)
            self.log("WARN", "Notifikasi tidak terbaca (kirim teks ini ke pembuat aplikasi): " + t[:160])
            m = re.search(r"(?:IDR|Rp\.?)\s*([\d.,]+)", t, re.I)
            if m: self.unknown.append((to_int(m.group(1)), time.time()))     # deposit BO bernominal ini tidak di-reject otomatis
            else: self.blind(self.ledger.opt["window"], "ada notifikasi tidak terbaca")
            try:
                with open(os.path.join(os.path.dirname(CSV_FILE), "notif_tidak_terbaca.txt"), "a", encoding="utf-8") as f: f.write(time.strftime("%F %T ") + t + "\n")
            except OSError: pass
        self.health(ok)
        sigs = [f'{e["full"]}|{e["amount"]}|{e["date"]}' for e in feed]
        prev = getattr(self, "notif_prev", None)
        if prev is None and not getattr(self, "notif_prev_fresh", False): prev = self._load_prev()
        self.notif_prev_fresh = False
        if prev is None:
            self.log("INFO", f"Awal: {len(feed)} notifikasi di layar ditandai sudah ada. Menunggu deposit baru")
            self.notif_prev = sigs; self._save_prev(sigs)
            self._maybe_balance(force=True)
            return len(feed), ok
        if not feed:
            return 0, ok                                        # layar kosong sesaat: jangan timpa data lama
        k, sure = feed_new(sigs, prev)
        if k:
            if not sure: self.log("WARN", "Daftar notifikasi bergeser jauh, mungkin ada yang terlewat atau terhitung ganda. Cek manual"); self.blind(self.ledger.opt["window"], "notifikasi mungkin terlewat")
            if k >= len(feed) and sure: self.log("WARN", f"{k} notifikasi baru sekaligus, mungkin ada yang di luar layar"); self.blind(self.ledger.opt["window"], "notifikasi mungkin terlewat")
            new = {}
            for e in reversed(feed[:k]):
                i = "n" + hashlib.md5(f'{time.time()}|{e["full"]}|{e["amount"]}|{len(new)}'.encode()).hexdigest()[:15]
                new[i] = {"date": e["date"], "amount": e["amount"], "type": "CR", "name": e["name"], "pending": False,
                          "raw": f'{e["full"]} | CR | {e["date"]} | IDR {rp(e["amount"])}'}
            self._announce(new)
            if self.cfg.get("source") == "auto":
                self.notif_pool += [{"amount": e["amount"], "ts": time.time(), "name": e["name"]} for e in new.values()]
        self.notif_prev = sigs; self._save_prev(sigs)
        self._maybe_balance()
        return len(feed), ok

    def _maybe_balance(self, force=False):
        """Mode notifikasi: buka Mutasi hanya tiap beberapa menit untuk membaca saldo, lalu kembali ke For You."""
        if self.cfg.get("show_balance", "1") != "1" or self.cfg.get("source") == "auto": return     # mode cadangan: Mutasi sedang dibatasi
        try: every = float(self.cfg.get("balance_every") or 5) * 60
        except ValueError: every = 300
        if every <= 0: return
        if not force and time.time() - getattr(self, "last_bal_visit", 0) < every: return
        self.last_bal_visit = time.time()
        try:
            self.ensure_mutasi()
            items = texts(self.dump_xml())
            if not is_mutasi(items):
                enter = find_node(items, self.cfg["enter_text"] or "View Account Transactions")
                if enter:
                    for mode in ("tap", "swipe"):
                        self.tap_node(enter, mode)
                        if self.wait_for(is_mutasi, 9): break
            if self.rate_limited():
                self.log("WARN", "myBCA membatasi permintaan saat membaca saldo, dilewati")
            else:
                v = self.read_balance()
                if v is None:
                    if not self.bal_warned: self.log("WARN", "Saldo tidak terbaca di layar (cek tombol mata / teks Active Balance)"); self.bal_warned = True
                else: self.bal_warned = False; self.note_balance(v)
        except Exception as ex:
            if not self.bal_warned: self.log("WARN", "Saldo gagal dibaca: " + str(ex)[:80]); self.bal_warned = True
        finally:
            try: self.nav_feed()
            except Exception: pass

    def bo_post(self, body):
        """Dari script Tampermonkey BO (protokol sama dengan Apps Script): cocokkan + isi User ID/Deposit ID ke Buku."""
        if not body or body.get("secret") != self.cfg.get("bo_secret"): return {"ok": False, "error": "kode rahasia salah"}
        rows_in = body.get("rows") or []
        if rows_in:
            if not PROFILE: return {"ok": False, "error": "aplikasi belum masuk ke website mana pun: pilih website di aplikasi dulu"}
            lab = next((r.get("label") for r in rows_in if r.get("label")), "")
            if lab and prof_key(lab) != prof_key(PROFILE): return {"ok": False, "error": f"BO ini diatur untuk {lab}, tapi aplikasi sedang di {PROFILE}"}
        res, added = [], 0
        for r in body.get("rows") or []:
            k = r.get("kind")
            if k == "match":
                try: when = float(r.get("when") or 0) / 1000.0 or None
                except (TypeError, ValueError): when = None
                m = self.ledger.match(r.get("txid"), r.get("user"), r.get("name"), r.get("amount"), when=when, done=bool(r.get("done")))
                res.append({"txid": r.get("txid"), "matched": m["ok"], "sure": bool(m.get("sure")), "pend": bool(m.get("pend")),
                            "confirmed": bool(m.get("confirmed")), "sheetName": m.get("sheetName", "")})
                if m["ok"]: added += 1
            elif k == "confirmed":
                row = next((x for x in self.ledger.view() if x["txid"] == str(r.get("txid"))), None) or {}
                self.act.add({"kind": "confirm", "txid": str(r.get("txid")), "user": row.get("user") or r.get("user", ""), "name": row.get("name") or r.get("name", ""), "amount": row.get("amount") or r.get("amount") or 0})
                res.append({"txid": r.get("txid"), "marked": self.ledger.mark_confirmed(r.get("txid"))})
            elif k == "released":                                     # deposit BO di-reject / dibatalkan manual oleh staff: lepaskan baris banknya
                res.append({"txid": r.get("txid"), "released": self.ledger.unassign(r.get("txid"))})
            elif k == "rejected":
                self.act.add({"kind": "reject", "txid": str(r.get("txid")), "user": r.get("user", ""), "name": r.get("name", ""), "amount": r.get("amount") or 0, "reason": r.get("reason", ""), "why": r.get("why", "")})
                res.append({"txid": r.get("txid"), "released": self.ledger.unassign(r.get("txid"))})
        judge = [r for r in (body.get("rows") or []) if r.get("kind") == "judge"]
        verdicts = {}
        if judge:
            now = time.time()
            iv = max(10, int(self.cfg.get("interval") or 30))
            healthy = (self.running and not self.paused and self.ok_since is not None and (now - self.last_check) < iv * 3 + 40
                       and now >= self.blind_until)
            win = self.ledger.opt["window"] + self.ledger.opt["wait"]
            self.unknown = [(a, t) for a, t in self.unknown if now - t < win]
            verdicts = self.ledger.judge(judge, now, self.ok_since if healthy else None, unknown={a for a, _ in self.unknown})
        return {"ok": True, "added": added, "results": res, "verdicts": verdicts, "rev": self.ledger.rev}

    def _drop_notified(self, new):
        """Deposit yang sudah diberitahukan lewat layar notifikasi (saat cadangan) tidak diberitahukan lagi dari Mutasi."""
        now = time.time()
        self.notif_pool = [p for p in self.notif_pool if now - p["ts"] < 6 * 3600]
        from ledger import sim as _sim, generic as _gen
        for i, e in list(new.items()):
            # nominal sama SAJA tidak cukup (dulu deposit orang lain bernominal sama bisa tertelan): nama juga harus cocok
            cands = [p for p in self.notif_pool if p["amount"] == e["amount"]]
            def score(p):
                a, b = p.get("name", ""), e.get("name", "")
                if a and b and (_gen(a) or _gen(b)): return 0.7 if a == b else 0.5
                return _sim(a, b) if a and b else 0.0
            cands = sorted(((score(p), p) for p in cands), key=lambda x: -x[0])
            hit = cands[0][1] if cands and cands[0][0] >= 0.5 else None
            if not hit: continue
            self.notif_pool.remove(hit); del new[i]; self.seen.add(i)
            self.log("INFO", f'Rp {rp(e["amount"])} sudah diberitahukan lewat notifikasi, tidak diulang')
            try:
                with open(EXTRA_SEEN, "a", encoding="utf-8") as f: f.write(i + "\n")
            except OSError: pass

    def blind(self, secs, why):
        """Jeda auto reject: bacaan myBCA mungkin tidak lengkap, jadi 'tidak ada transfer' belum tentu benar."""
        until = time.time() + secs
        if until > self.blind_until:
            if time.time() >= self.blind_until: self.log("INFO", f"Auto reject dijeda {int(secs // 60)} menit ({why})")
            self.blind_until = until

    def rate_limited(self):
        """myBCA membatasi permintaan kalau terlalu sering: 'Your request exceeded the limit...'."""
        try: items = texts(self.dump_xml())
        except Exception: return False
        return any(re.search(r"exceeded the limit|try again in a few moments", i["t"], re.I) for i in items)

    def cycle(self, baseline=False):
        self.ensure_connected()
        self.flush_pending()
        self.sheet_kick()
        self.ensure_awake()
        src = self.cfg.get("source")
        if src == "notif": return self.cycle_notif()
        self.baseline_pending = False
        if src == "auto" and time.time() < self.fb_until: self.baseline_pending = baseline; return self.cycle_notif()      # cadangan: Mutasi sedang kena batas
        self.ensure_mutasi()
        if self.cfg["refresh"] == "1":
            if self.cfg["refresh_mode"] == "pull": self.pull_refresh()
            else: self.reenter()
        if self.rate_limited():
            if self.cfg.get("source") == "auto":
                self.fb_wait = min(900, max(60, (self.fb_wait or 30) * 2)); self.fb_until = time.time() + self.fb_wait
                self.blind(self.fb_wait + self.ledger.opt["wait"], "myBCA membatasi Mutasi")       # transfer di sela pergantian bisa belum tercatat
                self.notif_prev = None; self.notif_prev_fresh = True; self.baseline_pending = baseline; self.ok_since = time.time()
                self.log("WARN", f"Mutasi kena batas myBCA. Pindah ke layar notifikasi sebagai cadangan selama {self.fb_wait} detik, lalu coba Mutasi lagi")
                if not self.nav_feed(): return 0, False
                return self.cycle_notif()
            self.backoff = min(300, max(60, (self.backoff or 30) * 2))
            self.blind(self.backoff + self.ledger.opt["wait"], "myBCA membatasi permintaan")
            self.log("WARN", f"myBCA membatasi permintaan (terlalu sering). Istirahat {self.backoff} detik. Naikkan Interval di Pengaturan (disarankan 30+ detik)")
            return 0, True
        self.backoff = 0; self.fb_wait = 0
        bal_v = None
        if self.cfg.get("show_balance", "1") == "1":
            try:
                bal_v = self.read_balance()      # dibaca sebelum scroll, saat kartu saldo masih tampil di atas
                if bal_v is None:
                    if not self.bal_warned: self.log("WARN", "Saldo tidak terbaca di layar (cek tombol mata / teks Active Balance)"); self.bal_warned = True
                else: self.bal_warned = False
            except Exception as ex:
                if not self.bal_warned: self.log("WARN", "Saldo gagal dibaca: " + str(ex)[:80]); self.bal_warned = True
        pages = int(self.cfg["pages"] or 0)
        found, ok = self.scan(pages, True, int(self.cfg["swipe_ms"] or 1200))
        self.health(ok)
        if ok: self._note_out(baseline)
        new = {i: e for i, e in found.items() if i not in self.seen}
        if ok and not baseline and len(found) >= 3 and len(new) == len(found):
            # semua transaksi di layar baru: kemungkinan ada yang lebih bawah. Gulir lebih jauh sekali.
            self.log("WARN", f"Semua {len(found)} transaksi di layar baru, membaca lebih ke bawah supaya tidak ada yang terlewat")
            more, _ = self.scan(pages + 3, True, int(self.cfg["swipe_ms"] or 1200))
            for i, e in more.items(): found.setdefault(i, e)
            new = {i: e for i, e in found.items() if i not in self.seen}
        if ok: new.update(self._twins(found, new))
        if baseline:
            self.mut_prev = [i.split("#")[0] for i, e in found.items() if not e.get("pending")]
            self.log("INFO", f"Awal: {len(found)} transaksi di layar ditandai sudah ada. Menunggu transaksi baru")
            if new: self.save(new)
            self.seen_pend += [{"amount": e["amount"], "name": e["name"], "id": i} for i, e in new.items() if e.get("pending")]
            self.seen.update(new)
            if bal_v is not None: self.note_balance(bal_v)
            return len(found), ok
        if new and any(not e.get("pending") for e in new.values()):
            pool = self.seen_pend
            for i, e in list(new.items()):
                if e.get("pending"): continue
                hit = next((p for p in pool if p["amount"] == e["amount"] and self._same_person(p["name"], e["name"])), None)
                if hit:
                    pool.remove(hit); del new[i]; self.seen.add(i); self.ledger.unpend(hit["id"])
                    self.log("INFO", f'Pending Rp {rp(e["amount"])} sudah posting, tidak dinotif ulang')
                    with open(SETTLED_FILE, "a", encoding="utf-8") as f: f.write(hit["id"] + "\n")
            self.seen_pend = pool
        self._drop_notified(new)
        self._announce(new)
        if bal_v is not None: self.note_balance(bal_v)    # setelah deposit baru dihitung, supaya selisih cocok
        return len(found), ok

    def _twins(self, found, new):
        """Transfer kembar (nama, nominal, tanggal sama, tanpa nomor referensi) dapat ID yang sama. Kalau yang lama sudah
        tergulir keluar layar, yang baru dulu dianggap 'sudah ada' dan terlewat. Urutan layar dibandingkan dengan cek
        sebelumnya: baris yang baru muncul di atas tapi ID-nya sudah ada = transfer kembar baru."""
        extra = {}
        ids = [i for i, e in found.items() if not e.get("pending")]
        bases = [i.split("#")[0] for i in ids]
        prev = self.mut_prev; self.mut_prev = bases
        if not prev or not bases: return extra
        k, sure = feed_new(bases, prev)
        if not sure or k <= 0 or k >= len(bases): return extra
        top = collections.Counter(bases[:k])                       # baris baru menurut urutan layar
        by_id = collections.Counter(i.split("#")[0] for i in new)  # baris baru menurut ID
        taken = set(found) | set(self.seen)
        for b, cnt in top.items():
            for _ in range(cnt - by_id.get(b, 0)):
                n = 1
                while f"{b}#{n}" in taken: n += 1
                nid = f"{b}#{n}"; taken.add(nid)
                src = found[ids[bases.index(b)]]
                extra[nid] = dict(src)
                self.log("INFO", f'Transfer kembar terdeteksi: {src["name"]} Rp {rp(src["amount"])} (sama persis dengan yang sebelumnya)')
        return extra

    def _note_out(self, baseline):
        """Catat transfer keluar (DB) dari layar Mutasi. Yang sudah ada saat aplikasi mulai hanya ditandai, tidak dicatat."""
        for i, e in list(self._out_last.items()):
            if i in self.out_seen or e.get("pending"): continue
            self.out_seen.add(i)
            if baseline: continue
            self.out.add({"id": i, "date": e["date"], "amount": e["amount"], "name": e["name"], "pending": bool(e.get("pending")), "raw": e.get("raw", "")})
            self.log("INFO", f'Transfer keluar Rp {rp(e["amount"])} ({e["name"]}) dicatat')

    def _loop(self, g):
        self.backoff = 0
        self.seen = self.load_seen(); first = not self.seen; self.seen_pend = self._pend_pool()
        if self.cfg["stay_awake"] == "1":
            try: self.adb("shell", "svc", "power", "stayon", "true")
            except Exception: pass
        self.next_check = time.time()
        while g == self.gen and not self.stop_ev.is_set():
            if self.paused or time.time() < self.next_check:
                self.wake_ev.wait(.5); 
                if self.wake_ev.is_set() and not self.paused: self.wake_ev.clear(); self.next_check = 0
                continue
            self.busy = True
            try:
                was_down = self.hp["state"] == "down"
                t0 = time.time()
                n, ok = self.cycle(baseline=first)
                if ok and self.ok_since is None: self.ok_since = t0       # mulai "sehat": baris bank sebelum ini tidak ada di Buku
                if not ok: self.ok_since = None
                if not self.backoff and not getattr(self, "baseline_pending", False): first = False      # kena batas myBCA = belum membaca apa pun, baseline diulang
                self.hp = {"state": "ok", "detail": ""}
                if was_down:
                    self.stats["sambung_ulang"] += 1; self.log("OK", "Sambung ulang HP berhasil")
                self.stats["cek_ok"] += 1
                self.log("INFO", f"Cek selesai: {n} entri terbaca")
            except Exception as ex:
                msg = str(ex)[:160]
                if self.hp["state"] != "down": self.log("ERR", "HP tidak terjangkau: " + msg)
                self.hp = {"state": "down", "detail": msg}; self.ok_since = None
                self.health(False, "(" + msg[:60] + ")")
            finally:
                self.busy = False; self.last_check = time.time()
                self.next_check = time.time() + max(10, int(self.cfg["interval"] or 20), self.backoff)
        if g == self.gen: self.running = False

    # ---------- kontrol ----------
    def reload(self): self.cfg = load_config(); self.ledger.configure(self.cfg); set_ewallet(self.cfg.get("ewallet_map", ""))

    def start(self):
        with self.lock:
            if self.running: return
            self.reload(); self.paused = False; self.stop_ev.clear(); self.wake_ev.clear()
            self.gen += 1; self.running = True
            self.thread = threading.Thread(target=self._loop, args=(self.gen,), daemon=True); self.thread.start()
            self.log("INFO", "Pemantauan dimulai")

    def stop(self):
        with self.lock:
            if not self.running: return
            self.gen += 1; self.stop_ev.set(); self.wake_ev.set(); self.running = False
            self.log("INFO", "Pemantauan dihentikan")

    def toggle_pause(self):
        self.paused = not self.paused; self.log("INFO", "Dijeda" if self.paused else "Dilanjutkan")
        if not self.paused: self.next_check = 0

    def check_now(self):
        if self.running and not self.busy: self.paused = False; self.next_check = 0; self.wake_ev.set()

    # ---------- kunci aplikasi (login tetap, tidak bisa diubah dari aplikasi) ----------
    LOCK_USER, LOCK_SALT, LOCK_HASH = "admin", "mg7f3a91c2", "78d5e9cb69bb5ed4f2f312262763739f36f1d3223ddcda24a3ece7ca5980dc6d"
    def lock_check(self, user, pw):
        ok = hmac.compare_digest(hashlib.sha256((self.LOCK_SALT + "|" + str(pw)).encode("utf-8")).hexdigest(), self.LOCK_HASH) and str(user).strip().lower() == self.LOCK_USER
        if not ok: time.sleep(1.0)
        return ok

    def set_config(self, new):
        cfg = dict(self.cfg)
        for k in DEFAULTS:
            if k == "update_url": continue                           # alamat pembaruan hanya bisa diubah manual di config.ini
            if k in new and new[k] is not None:
                v = str(new[k]).strip()
                if k in ("telegram_token", "sheet_secret") and v.startswith("•"): continue          # tersamar = tidak diubah
                cfg[k] = v
        try:
            if int(cfg["interval"]) < 10: cfg["interval"] = "10"
        except ValueError: cfg["interval"] = "20"
        for k, lo, hi in (("rej_wait", 2, 180), ("rej_window", 1, 24), ("name_min", 40, 95), ("name_diff", 5, 90)):
            try: cfg[k] = str(int(min(hi, max(lo, float(cfg[k])))))
            except (TypeError, ValueError): cfg[k] = DEFAULTS[k]
        if int(cfg["name_diff"]) > int(cfg["name_min"]) - 5: cfg["name_diff"] = str(int(cfg["name_min"]) - 5)
        for k in ("rej_receipt", "rej_name", "rej_amount"): cfg[k] = "1" if cfg[k] == "1" else "0"
        if PROFILE: cfg["label"] = PROFILE
        cols = {}
        for part in str(cfg.get("sheet_cols", "")).split(","):
            k, _, v = part.partition("=")
            k, v = k.strip().lower(), v.strip().upper()
            if k in ("jam", "user", "nominal", "nama", "txid") and re.fullmatch(r"[A-Z]{1,2}", v): cols[k] = v
        cfg["sheet_cols"] = ",".join(f"{k}={v}" for k, v in cols.items()) or DEFAULTS["sheet_cols"]
        cfg["sheet_jam"] = "hm" if cfg.get("sheet_jam") == "hm" else "hms"
        cfg["saldo_max"] = str(int(re.sub(r"\D", "", str(cfg.get("saldo_max", ""))) or 0))
        ew = []
        for part in re.split(r"[,;\n]+", str(cfg.get("ewallet_map", ""))):
            k, _, v = part.partition("=")
            k, v = " ".join(k.upper().split()), " ".join(v.upper().split())
            if len(k) >= 3 and v: ew.append(f"{k}={v}")
        cfg["ewallet_map"] = ", ".join(ew)
        save_config(cfg); self.cfg = cfg; self.ledger.configure(cfg); set_ewallet(cfg.get("ewallet_map", "")); self.log("INFO", "Pengaturan disimpan")

    # ---------- wizard HP ----------
    def devices(self):
        out = self.adb("devices", "-l", use_serial=False, timeout=15)
        res = []
        for l in out.splitlines()[1:]:
            p = l.split()
            if len(p) >= 2 and p[1] in ("device", "unauthorized", "offline"):
                mdl = next((x.split(":", 1)[1] for x in p if x.startswith("model:")), "")
                res.append({"serial": p[0], "state": p[1], "model": mdl.replace("_", " "), "wifi": ":" in p[0]})
        return res

    def ping(self, ip):
        """True jika HP di alamat itu membalas ping dari PC (sekaligus membangunkan jalur jaringan)."""
        flag = ["-n", "2", "-w", "1500"] if os.name == "nt" else ["-c", "2", "-W", "2"]
        try:
            r = subprocess.run(["ping"] + flag + [ip], capture_output=True, timeout=12, creationflags=NOWIN)
            out = r.stdout.decode("utf-8", "ignore").lower()
            return r.returncode == 0 and "unreachable" not in out and "ttl" in out
        except Exception:
            return False

    def find_phone_ip(self, serial):
        """Cari IP Wi-Fi HP lewat beberapa cara (beda HP, beda hasil)."""
        cmds = [("shell", "ip", "-f", "inet", "addr", "show", "wlan0"), ("shell", "ip", "route"), ("shell", "ip", "addr", "show"),
                ("shell", "ifconfig", "wlan0"), ("shell", "dumpsys", "wifi"), ("shell", "getprop", "dhcp.wlan0.ipaddress")]
        pats = [r"inet (?:addr:)?(\d+\.\d+\.\d+\.\d+)", r"wlan\d.*?src (\d+\.\d+\.\d+\.\d+)", r"src (\d+\.\d+\.\d+\.\d+)",
                r"IP: /?(\d+\.\d+\.\d+\.\d+)", r"^(\d+\.\d+\.\d+\.\d+)$"]
        for cmd in cmds:
            try: out = self.adb(*cmd, serial=serial, timeout=15)
            except Exception: continue
            for pat in pats:
                for m in re.finditer(pat, out, re.M):
                    ip = m.group(1)
                    if re.match(r"(192\.168|10\.|172\.(1[6-9]|2\d|3[01]))\.", ip): return ip
        return ""

    def wizard_wifi(self, ip=""):
        ip = (ip or "").strip().split(":")[0]
        devs = self.devices()
        usb = next((d for d in devs if not d["wifi"] and d["state"] == "device"), None)
        if not ip:
            if not usb:
                w = next((d for d in devs if d["wifi"] and d["state"] == "device"), None)
                if w:
                    self.set_config({"serial": w["serial"]}); return {"ok": True, "serial": w["serial"], "msg": "Sudah tersambung lewat Wi-Fi"}
                return {"ok": False, "msg": "Belum ada HP yang diizinkan lewat kabel USB"}
            ip = self.find_phone_ip(usb["serial"])             # dicari SEBELUM tcpip, selagi kabel masih stabil
            if not ip:
                return {"ok": False, "need_ip": True, "msg": "Alamat Wi-Fi HP tidak ditemukan otomatis. Isi manual di kolom bawah (lihat Settings > About phone > Status > IP address)."}
        if usb:
            self.adb("tcpip", "5555", serial=usb["serial"], timeout=15); time.sleep(3)
        target = f"{ip}:5555"; out = ""
        for _ in range(4):                                       # koneksi USB ke HP sempat restart, coba beberapa kali
            out = self.adb("connect", target, use_serial=False, timeout=20)
            if "connected to" in out.lower() and "cannot" not in out.lower() and "failed" not in out.lower(): break
            time.sleep(2)
        else:
            reach = self.ping(ip)
            if reach:
                why = f"HP membalas ping tapi menolak sambungan ADB ({out.strip()[:80]}). Coba: cabut lalu colok kabel USB, ketuk Izinkan di HP, tekan tombol ini lagi."
            else:
                why = (f"PC tidak bisa menjangkau {ip}. Nyalakan layar HP, pastikan HP dan PC di Wi-Fi yang SAMA (bukan tamu/guest), "
                       "dan router tidak mengaktifkan 'AP/Client Isolation'. Cek juga IP HP: Settings > About phone > Status.")
            self.log("WARN", "Sambung Wi-Fi gagal: " + why[:100])
            return {"ok": False, "need_ip": True, "msg": why}
        self.set_config({"serial": target}); self.log("OK", f"HP tersambung lewat Wi-Fi {target}")
        return {"ok": True, "serial": target, "msg": "Tersambung ke " + target + ". Kabel USB boleh dicabut."}

    def wizard_usb(self):
        usb = next((d for d in self.devices() if not d["wifi"] and d["state"] == "device"), None)
        if not usb: return {"ok": False, "msg": "Belum ada HP yang diizinkan lewat kabel USB"}
        self.set_config({"serial": usb["serial"]}); self.log("OK", f"Memakai kabel USB ({usb['serial']})")
        return {"ok": True, "serial": usb["serial"], "msg": "Memakai kabel USB. Jangan cabut kabel selama dipantau."}

    def test_connect(self):
        s = self.cfg["serial"]
        if not s: return {"ok": False, "msg": "Alamat HP belum diisi"}
        if ":" in s: out = self.adb("connect", s, use_serial=False, timeout=15)
        else: out = ""
        ds = [d for d in self.devices() if d["serial"] == s]
        if ds and ds[0]["state"] == "device": return {"ok": True, "msg": "HP " + (ds[0]["model"] or s) + " tersambung"}
        return {"ok": False, "msg": (out.strip() or "HP tidak terdeteksi")[:160]}

    def compat(self):
        checks, sample = [], []
        def add(name, ok, detail="", level=None): checks.append({"name": name, "ok": ok, "detail": detail, "warn": level == "warn"})
        try:
            ds = [d for d in self.devices() if (not self.cfg["serial"]) or d["serial"] == self.cfg["serial"]]
        except Exception as ex:
            add("ADB jalan", False, str(ex)[:120]); return {"ok": False, "checks": checks, "sample": sample}
        if not ds: add("HP terdeteksi", False, "Tidak ada HP. Sambungkan dulu di halaman Sambung HP."); return {"ok": False, "checks": checks, "sample": sample}
        d = ds[0]
        add("HP terdeteksi", d["state"] == "device", (d["model"] or d["serial"]) + ("" if d["state"] == "device" else f" ({d['state']}, ketuk Izinkan di HP)"))
        if d["state"] != "device": return {"ok": False, "checks": checks, "sample": sample}
        try:
            w, h = self.screen_size(); add("Ukuran layar", True, f"{w} x {h} piksel (dipakai otomatis)")
            self.ensure_awake()
            items = texts(self.dump_xml()); add("Layar bisa dibaca", True, f"{len(items)} teks terbaca")
        except Exception as ex:
            add("Layar bisa dibaca", False, str(ex)[:140]); return {"ok": False, "checks": checks, "sample": sample}
        foc = self.adb("shell", "dumpsys", "window").lower()
        focus = next((l for l in foc.splitlines() if "mcurrentfocus" in l), "")
        if "bca" not in focus and not any("account" in i["t"].lower() for i in items):
            add("myBCA terbuka", False, "Buka app myBCA dan login dulu, lalu ulangi tes"); return {"ok": False, "checks": checks, "sample": sample}
        add("myBCA terbuka", True)
        if not is_mutasi(items):
            self.log("INFO", "Tes: masuk ke Mutasi"); self.reenter()
            items = texts(self.dump_xml())
        alltext = " ".join(i["t"] for i in items).lower()
        eng = sum(k in alltext for k in ("account", "transactions", "balance", "information", "my account"))
        ind = sum(k in alltext for k in ("rekening", "mutasi", "informasi", "saldo", "beranda"))
        add("Bahasa myBCA English", eng > 0 and ind == 0 or eng > ind,
            "OK" if eng > ind else "Ganti bahasa app myBCA ke English (Settings di myBCA), karena pembacaan memakai teks English")
        mu = is_mutasi(items)
        add("Halaman Mutasi terbaca", mu, "" if mu else "Buka My Account > View Account Transactions & Info, lalu ulangi")
        if mu:
            es = parse_entries(items, False)
            sample = [{"name": e["name"], "amount": e["amount"], "type": e["type"], "date": e["date"]} for e in es[:4]]
            add("Nama dan nominal terbaca", bool(es), f"{len(es)} transaksi di layar")
        return {"ok": all(c["ok"] or c["warn"] for c in checks), "checks": checks, "sample": sample}

    # ---------- state untuk UI ----------
    def events(self):
        rows = self.read_csv()
        pend = {p.get("id") for p in self.pending()}
        out = []
        for r in rows:
            d = parse_tx_date(r["date"])
            out.append({"id": r["id"], "seen_at": r["seen_at"], "date": r["date"], "d": d.isoformat() if d else "", "amount": r["amount"],
                        "name": r["name"] or "(nama tidak terbaca)", "pending": r["id"] in pend})
        out.sort(key=lambda e: e["seen_at"], reverse=True)
        return out

    def state(self):
        now = time.time(); ev = self.events(); today = datetime.now().date().isoformat()
        te = [e for e in ev if e["d"] == today]
        tot = sum(e["amount"] for e in te)
        by = collections.OrderedDict()
        for e in te: by[e["name"]] = by.get(e["name"], 0) + e["amount"]
        top = sorted(by.items(), key=lambda kv: -kv[1])[:3]
        big = max(te, key=lambda e: e["amount"]) if te else None
        latest = None
        with self.lock: sn = list(self.session_new)
        if sn:
            l = sn[-1]; latest = {"name": l["name"] or "(nama tidak terbaca)", "amount": l["amount"], "date": l["date"], "seen_at": l["seen_at"],
                                  "ago": int(now - l["ts"]), "is_new": True, "pending": l["id"] in {p.get("id") for p in self.pending()}}
        elif ev:
            l = ev[0]
            try: ago = int(now - datetime.strptime(l["seen_at"], "%Y-%m-%d %H:%M:%S").timestamp())
            except Exception: ago = 0
            latest = {"name": l["name"], "amount": l["amount"], "date": l["date"], "seen_at": l["seen_at"], "ago": ago, "is_new": False, "pending": l["pending"]}
        tok = self.cfg["telegram_token"]
        return {
            "version": VERSION, "running": self.running, "paused": self.paused, "busy": self.busy,
            "hp": {**self.hp, "serial": self.cfg["serial"]},
            "screen_warn": self.empty_streak >= 3,
            "tg": {"ready": self.tg_ready(), "topic": self.cfg["telegram_topic_id"]},
            "profile": PROFILE, "label": self.cfg["label"], "interval": int(self.cfg["interval"] or 20),
            "next_in": max(0, int(self.next_check - now)) if self.running and not self.paused else None,
            "last_check_ago": int(now - self.last_check) if self.last_check else None,
            "stats": self.stats, "pending": len(self.pending()),
            "today": {"total": tot, "count": len(te), "big": ({"name": big["name"], "amount": big["amount"]} if big else None),
                      "top": [{"name": n, "amount": a} for n, a in top]},
            "saldo": ({**self.balance, "ago": int(now - self.balance["ts"])} if self.balance else None), "show_balance": self.cfg.get("show_balance", "1") == "1",
            "sheet": {"on": self.sheet_on(), "pending": self.sheet_count(), "err": self.sheet_err},
            "blind_in": max(0, int(self.blind_until - now)),
            "latest": latest, "events": ev[:1500], "total_events": len(ev),
            "log": [{"ts": l["ts"], "lv": l["lv"], "msg": l["msg"]} for l in list(self.logs)[-250:]],
            "needs_setup": not self.cfg["serial"] and not self.tg_ready(),
            "cfg": {**{k: v for k, v in self.cfg.items() if k not in ("lock_hash", "lock_salt")}, "locked": True, "telegram_token": ("•" * 10 + tok[-4:]) if tok else "", "sheet_secret": "•" * 8 if self.cfg.get("sheet_secret") else ""},
        }
