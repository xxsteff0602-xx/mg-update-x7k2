/* Cari Selisih — core logic (browser + node). Needs XLSX (SheetJS) and JSZip. */
(function (root) {
  'use strict';
  const XLSX = root.XLSX || (typeof require !== 'undefined' ? require('xlsx') : null);
  const JSZip = root.JSZip || (typeof require !== 'undefined' ? require('jszip') : null);

  // ---------- helpers ----------
  const pad = n => String(n).padStart(2, '0');
  function excelDate(v) {
    if (v == null || v === '') return '';
    if (v instanceof Date) return v.getFullYear() + '-' + pad(v.getMonth() + 1) + '-' + pad(v.getDate()) + ' ' + pad(v.getHours()) + ':' + pad(v.getMinutes()) + ':' + pad(v.getSeconds());
    if (typeof v === 'number') {
      const d = XLSX.SSF.parse_date_code(v);
      if (!d) return '';
      return d.y + '-' + pad(d.m) + '-' + pad(d.d) + ' ' + pad(d.H) + ':' + pad(d.M) + ':' + pad(Math.floor(d.S));
    }
    const m = String(v).match(/(\d{4}-\d\d-\d\d)(?:[ T](\d\d:\d\d(?::\d\d)?))?/);
    if (!m) return '';
    let t = m[2] || '00:00:00'; if (t.length === 5) t += ':00';
    return m[1] + ' ' + t;
  }
  function num(v) {
    if (v == null || v === '') return 0;
    if (typeof v === 'number') return v;
    const s = String(v).replace(/,/g, '').trim();
    const n = parseFloat(s); return isNaN(n) ? 0 : n;
  }
  function boUser(v) {
    const t = String(v == null ? '' : v).trim().split(/\s+/).filter(Boolean);
    if (!t.length) return '';
    return (t[0] === 'New' && t.length > 1) ? t[1] : t[0];
  }
  const low = s => String(s == null ? '' : s).trim().toLowerCase();
  const day = s => (s || '').slice(0, 10);
  const r2 = n => Math.round(n * 100) / 100;
  // TID di note adjustment bisa salah ketik (1-3 karakter) -> cocokkan dengan toleransi
  function lev(a, b) {
    const m = a.length, n = b.length; if (!m) return n; if (!n) return m;
    let p = Array.from({ length: n + 1 }, (_, j) => j);
    for (let i = 1; i <= m; i++) { const c = [i]; for (let j = 1; j <= n; j++) c[j] = Math.min(p[j] + 1, c[j - 1] + 1, p[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); p = c; }
    return p[n];
  }
  function noteTids(note) { return (String(note || '').toUpperCase().match(/[0-9A-Z]{14,24}/g) || []).filter(t => /\d/.test(t) && /[A-Z]/.test(t)); }
  function tidNear(tok, tid) {
    const T = String(tid || '').toUpperCase(); if (T.length < 8) return false;
    if (tok.includes(T)) return true;
    const w = [tok]; if (tok.length > T.length) w.push(tok.slice(0, T.length), tok.slice(-T.length));
    return w.some(x => lev(x, T) <= 3);
  }
  // note berisi TID, tapi tidak satu pun mirip TID ini -> adjustment ini untuk WD lain, jangan dipasangkan hanya karena user + nominal sama
  const noteConflict = (a, tid) => { const t = noteTids(a.note); return t.length > 0 && !t.some(x => tidNear(x, tid)); };
  // TID GIGA: 5 karakter member + 0/8 + 8 hex waktu (unix detik) + acak
  const tidTime = t => { const m = /^[0-9A-Z]{5}[0-9][0-9A-F]{8}/i.exec(String(t || '')); return m ? parseInt(String(t).slice(6, 14), 16) : null; };

  // ---------- file reading ----------
  function isZip(u8) { return u8[0] === 0x50 && u8[1] === 0x4b; }
  function isOle(u8) { return u8[0] === 0xd0 && u8[1] === 0xcf; }
  function looksText(u8) {
    const n = Math.min(u8.length, 2000); let ctrl = 0;
    for (let i = 0; i < n; i++) { const c = u8[i]; if (c === 0) return false; if (c < 9 || (c > 13 && c < 32)) ctrl++; }
    return ctrl < 5;
  }
  function tsvRows(u8) {
    const txt = new TextDecoder('utf-8').decode(u8).replace(/^\uFEFF/, '');
    return txt.split(/\r?\n/).filter(l => l.length).map(l => l.split('\t'));
  }

  // expand zips → list of {name, u8}
  async function expand(files) {
    const out = [];
    for (const f of files) {
      const u8 = f.u8;
      const lower = f.name.toLowerCase();
      if (isZip(u8) && lower.endsWith('.zip')) {
        const z = await JSZip.loadAsync(u8);
        const names = Object.keys(z.files).filter(n => !z.files[n].dir && !/(^|\/)(__MACOSX|\.)/.test(n));
        for (const n of names) out.push(...await expand([{ name: f.name + ' › ' + n.split('/').pop(), u8: await z.files[n].async('uint8array') }]));
      } else out.push(f);
    }
    return out;
  }

  // returns array of {sheet, rows} for a file
  function sheetsOf(f) {
    const u8 = f.u8;
    if (!isZip(u8) && !isOle(u8) && looksText(u8) && !/^\s*</.test(new TextDecoder().decode(u8.slice(0, 50)))) {
      return { kind: 'text', sheets: [{ name: 'tsv', rows: tsvRows(u8) }] };
    }
    const wb = XLSX.read(u8, { type: 'array', cellDates: false, cellFormula: true, cellNF: false });
    return { kind: 'wb', wb, sheets: wb.SheetNames.map(n => ({ name: n, rows: XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, raw: true, defval: null, blankrows: true }) })) };
  }

  function findHeader(rows, must, maxScan = 6) {
    for (let i = 0; i < Math.min(rows.length, maxScan); i++) {
      const r = (rows[i] || []).map(c => String(c == null ? '' : c).trim().toLowerCase());
      if (must.every(m => r.includes(m))) { const idx = {}; r.forEach((c, j) => { if (c && !(c in idx)) idx[c] = j; }); return { i, idx }; }
    }
    return null;
  }

  // ---------- parsers ----------
  function parseHoki(rows, h, src) {
    const g = k => h.idx[k];
    const out = [];
    for (let i = h.i + 1; i < rows.length; i++) {
      const r = rows[i]; if (!r) continue;
      const wl = r[g('whitelabel transaction id')]; if (wl == null || wl === '') continue;
      out.push({
        tid: String(wl).trim().split('-')[0].replace(/\.0$/, ''),
        status: String(r[g('status')] || '').trim(),
        amt: num(r[g('total amount')]),
        trx: excelDate(r[g('transaction date')]),
        fin: excelDate(r[g('finished date')]),
        by: String(r[g('processed by')] || '').trim(),
        name: String(r[g('account name')] || '').trim(),
        pm: String(r[g('payment method')] || '').trim(), src
      });
    }
    return out;
  }
  function parseBoOne(rows, h, src) { // One-Gaming Back Office System xlsx
    const g = k => h.idx[k]; const out = [];
    for (let i = h.i + 1; i < rows.length; i++) {
      const r = rows[i]; if (!r) continue;
      const tid = r[g('transaction id')]; if (tid == null || tid === '') continue;
      out.push({
        tid: String(tid).trim().replace(/\.0$/, ''), user: boUser(r[g('username')]),
        fm: String(r[g('fund method')] || '').trim(), status: String(r[g('status')] || '').trim(),
        debit: num(r[g('debit')]), credit: num(r[g('credit')]),
        note: String(r[g('notes')] || '').trim(),
        tdate: excelDate(r[g('transaction date')]), ctime: excelDate(r[g('comfirmed/rejected time')] ?? r[g('confirmed/rejected time')]),
        by: String(r[g('comfirmed/rejected by')] ?? r[g('confirmed/rejected by')] ?? '').trim(), ttype: '', src
      });
    }
    return out;
  }
  function parseBoTsv(rows, h, src) { // Transactions_*.xls (tab text)
    const g = k => h.idx[k]; const out = [];
    for (let i = h.i + 1; i < rows.length; i++) {
      const r = rows[i]; if (!r || r.length < 5) continue;
      const tid = r[g('transaction id')]; if (!tid || !String(tid).trim()) continue;
      out.push({
        tid: String(tid).trim(), user: boUser(r[g('user name')]),
        fm: String(r[g('fund method')] || '').trim(), status: String(r[g('status title')] || '').trim(),
        debit: num(r[g('debit')]), credit: num(r[g('credit')]), note: String(r[g('note')] || '').trim(),
        tdate: excelDate(r[g('transaction date')]), ctime: excelDate(r[g('confirmed / rejected time')]),
        by: String(r[g('confirmed / rejected by')] || '').trim(), ttype: String(r[g('transaction type')] || '').trim(), src
      });
    }
    return out;
  }

  // ---------- buku ----------
  function parseCoin(rows, h, src) { // coin log agen (GIGA): # / Date & Time / Transaction Id / Transaction Type / Debit / Credit / Balance / Credited By
    const g = k => h.idx[k]; const out = [];
    for (let i = h.i + 1; i < rows.length; i++) {
      const r = rows[i]; if (!r) continue;
      const tid = r[g('transaction id')], bal = r[g('balance')];
      if (tid == null || tid === '' || bal == null || bal === '' || isNaN(num(bal))) continue;
      out.push({ no: num(r[g('#')]), tid: String(tid).trim(), type: String(r[g('transaction type')] || '').trim(), debit: num(r[g('debit')]), credit: num(r[g('credit')]), bal: num(bal), at: excelDate(r[g('date & time')]), by: String(r[g('credited by')] || '').trim(), src });
    }
    return out;
  }
  // cek coin error: saldo seharusnya (saldo awal - debit + credit) vs kolom Balance.
  // top-up tidak tercatat di coin log -> kelipatan 10 juta dibuang. Transaksi di detik yang sama sering menulis Balance lama,
  // jadi selisih baru dihitung kalau menetap 5 baris berturut-turut.
  function checkCoin(coinRaw) {
    const seen = new Set(), rows = [];
    coinRaw.forEach((c, i) => { const k = c.tid + '|' + c.type + '|' + c.debit + '|' + c.credit + '|' + c.bal; if (!seen.has(k)) { seen.add(k); rows.push({ c, i }); } });
    if (!rows.length) return null;
    rows.sort((p, q) => (p.c.at < q.c.at ? -1 : p.c.at > q.c.at ? 1 : (q.c.no - p.c.no) || (q.i - p.i)));
    const L = rows.map(x => x.c);
    let s = L[0].bal + L[0].debit - L[0].credit;
    const t = [], q = [];
    for (const c of L) { s += c.credit - c.debit; const x = s - c.bal; const k = Math.round(x / 1e7); q.push(k); t.push(Math.round(x - k * 1e7)); }
    const W = 5, errors = [], topups = [];
    let V = 0, K = 0;
    const steady = (arr, i) => { const e = Math.min(arr.length, i + W); for (let j = i + 1; j < e; j++) if (arr[j] !== arr[i]) return false; return true; };
    for (let i = 0; i < L.length; i++) {
      if (t[i] !== V && steady(t, i)) { errors.push({ at: L[i].at, tid: L[i].tid, type: L[i].type, debit: L[i].debit, credit: L[i].credit, amt: t[i] - V }); V = t[i]; }
      if (q[i] !== K && steady(q, i)) { topups.push({ at: L[i].at, amt: (K - q[i]) * 1e7 }); K = q[i]; }
    }
    const tids = new Set(L.map(c => c.tid.toUpperCase()));
    const tt = L.map(c => tidTime(c.tid)).filter(x => x != null).sort((a, b) => a - b);
    return { n: L.length, from: L[0].at, to: L[L.length - 1].at, errors, topups, tids, tMin: tt[0] || null, tMax: tt[tt.length - 1] || null };
  }

  function parseBuku(wb, fileName) {
    const tabs = [];
    for (const n of wb.SheetNames) {
      const ws = wb.Sheets[n];
      const a4 = ws['A4'] && String(ws['A4'].v || '').trim().toUpperCase();
      if (a4 && a4.replace(/\s+/g, ' ').startsWith('UP / CUT')) tabs.push(n);
    }
    if (!tabs.length) return null;
    const entries = []; const wdRows = []; const loose = [];
    // baris bernominal bank tanpa UP/CUT CREDIT (untuk cek baris sesudah tanggal gross terakhir) + tanggal grossan
    const bankRows = [], lateA = [], grossDays = [];
    const bankRng = {};
    try {
      for (const n of wb.SheetNames) {
        const c = wb.Sheets[n]['A3']; if (!(c && c.f && /E1\s*\+\s*A1/i.test(c.f))) continue;
        const f = String(c.f); const k = f.search(/SUM\(/i); if (k < 0) break;
        rangesIn(f.slice(k), n).forEach(g => { (bankRng[g.sheet] = bankRng[g.sheet] || []).push(g); });
        break;
      }
    } catch (e) { }
    const lumpUser = u => /^(saldo|wd\s*hoki|qris|netz|abc|transaksi|bonus|all\s)/i.test(u);
    for (const n of tabs) {
      const rg = bankRng[n] || [];
      const bankOf = r => { let t = 0; for (const g of rg) for (let c = g.c1; c <= g.c2; c++) if (typeof r[c] === 'number') t += r[c]; return t; };
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[n], { header: 1, raw: true, defval: null, blankrows: true });
      // find WD QRISHOKI column (header in rows 1-3)
      let wdCol = -1;
      for (let i = 0; i < 4; i++) (rows[i] || []).forEach((c, j) => { if (String(c || '').toUpperCase().replace(/\s+/g, ' ').trim() === 'WD QRISHOKI') wdCol = j; });
      let group = null; // MC group
      let grossRun = false; // di dalam blok grossan (baris "Gross Coin" + baris harian di bawahnya)
      for (let i = 4; i < rows.length; i++) {
        const r = rows[i] || []; const A = r[0], B = r[1], C = r[2], E = r[4];
        const user = String(E == null ? '' : E).trim();
        const date = excelDate(B).slice(0, 10);
        const aNum = typeof A === 'number' ? A : (A != null && A !== '' && !isNaN(num(A)) && String(A).trim() !== '' ? num(A) : null);
        if (grossRun && (user || (C != null && C !== '') || (r[3] != null && String(r[3]).trim() !== '' && !/gross/i.test(String(r[3]))))) grossRun = false;
        if (user && date && rg.length && !lumpUser(user) && !(wdCol >= 0 && typeof r[wdCol] === 'number' && r[wdCol] !== 0)) {
          const bk = bankOf(r);
          if (Math.abs(bk) >= 0.5) (aNum == null || aNum === 0 ? bankRows : lateA).push({ tab: n, row: i + 1, user, date, bank: bk, A: aNum || 0 });
        }
        if (wdCol >= 0 && typeof r[wdCol] === 'number' && r[wdCol] !== 0) {
          const m = user.match(/^WD\s*HOKI\s*(\d{1,2})$/i);
          wdRows.push({ tab: n, row: i + 1, user, date, label: m ? +m[1] : null, val: r[wdCol] });
        }
        // rincian di bawah baris total (misal baris "MC"): user + nominal catatan di kolom C.
        // Baris "DONE" (refund yang sudah di-add, kolom C hanya catatan) BUKAN rincian.
        const isDone = x => /^\s*done\s*$/i.test(String(x && x[3] != null ? x[3] : ''));
        const isMemberRow = x => x && !isDone(x) && x[4] != null && String(x[4]).trim() !== '' && typeof x[2] === 'number' && x[2] >= 1;
        if (group && isMemberRow(r)) {
          group.members.push({ tab: n, row: i + 1, user, date: date || group.date, amt: C });
          if (aNum != null && aNum !== 0) {
            // a lump equal to the group total written on a member row = reversal of the whole group (e.g. cut done next day)
            if (Math.abs(Math.abs(aNum) - Math.abs(group.total)) < 1) group.revs.push({ row: i + 1, date, sign: Math.sign(aNum) });
            else entries.push({ tab: n, row: i + 1, user, date, A: aNum });
          }
          continue;
        }
        if (aNum != null && aNum !== 0) {
          // group header: A filled, own C empty, next row is a member (user + amount in C)
          if (!isMemberRow(r) && isMemberRow(rows[i + 1])) {
            group = { tab: n, row: i + 1, total: aNum, date, sign: Math.sign(aNum), members: [], revs: [] };
            entries.push({ tab: n, row: i + 1, user: '(grup ' + (user || '') + ')', date, A: aNum, group: true, g: group });
            continue;
          }
          group = null;
          if (!user) {
            // baris "Gross Coin" dan baris grossan harian di bawahnya (tanpa jam, CS, user, bank) bukan catatan transaksi;
            // deposit tanpa user (A = nominal bank-nya, uang masuk tanpa coin) juga bukan "baris tanpa nama" yang bisa dipasangkan ke user
            const isG = /gross/i.test(String(r[3] || ''));
            const bankEq = r.slice(6).some(x => typeof x === 'number' && Math.abs(x - aNum) < 0.5);
            const bare = (C == null || C === '') && (r[3] == null || String(r[3]).trim() === '') && !r.slice(6).some(x => typeof x === 'number' && x !== 0);
            if (isG) grossRun = true; else if (!(grossRun && bare)) grossRun = false;
            if ((isG || grossRun) && date) grossDays.push(date);
            if (!isG && !grossRun && !bankEq) loose.push({ tab: n, row: i + 1, date, A: aNum });
            continue;
          }
          entries.push({ tab: n, row: i + 1, user, date, A: aNum });
        } else if (group && ((!user && !isMemberRow(rows[i + 1])) || isDone(r))) {
          group = null;
        }
      }
    }
    // expand groups whose member sum matches the total
    const flat = []; const headerDiffs = [];
    for (const e of entries) {
      if (!e.group) { flat.push(e); continue; }
      const s = e.g.members.reduce((a, m) => a + m.amt, 0);
      if (Math.abs(s - Math.abs(e.A)) < 1) {
        e.g.members.forEach(m => flat.push({ tab: m.tab, row: m.row, user: m.user, date: m.date, A: e.g.sign * m.amt, groupRow: e.row }));
        e.g.revs.forEach(v => e.g.members.forEach(m => flat.push({ tab: m.tab, row: v.row, user: m.user, date: v.date || m.date, A: v.sign * m.amt, groupRow: e.row, rev: true })));
      } else if (e.g.members.length) {
        e.g.members.forEach(m => flat.push({ tab: m.tab, row: m.row, user: m.user, date: m.date, A: e.g.sign * m.amt, groupRow: e.row }));
        headerDiffs.push({ tab: e.tab, row: e.row, date: e.date, header: e.A, members: e.g.sign * s, diff: e.A - e.g.sign * s, n: e.g.members.length });
      } else {
        flat.push({ tab: e.tab, row: e.row, user: e.user, date: e.date, A: e.A, groupMismatch: s });
      }
    }
    // selisih cell: sheet whose A3 is a formula containing E1+A1
    let selisih = null, selisihAt = '';
    for (const n of wb.SheetNames) { const c = wb.Sheets[n]['A3']; if (c && c.f && /E1\s*\+\s*A1/i.test(c.f) && typeof c.v === 'number') { selisih = c.v; selisihAt = n + '!A3'; break; } }
    const formulaWarn = [];
    try {
      const sheetOfA3 = selisihAt ? selisihAt.split('!')[0] : null;
      const a1 = sheetOfA3 && wb.Sheets[sheetOfA3]['A1'] && wb.Sheets[sheetOfA3]['A1'].f || '';
      if (a1) for (const n of tabs) {
        const b1 = wb.Sheets[n]['B1'];
        if (!b1 || !b1.f || !/SUMIFS/i.test(b1.f)) continue;
        const ref = n === sheetOfA3 ? /(^|[^!A-Z])B1\b/ : new RegExp("'?" + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + "'?!B1\\b", 'i');
        if (!ref.test(a1) && typeof b1.v === 'number' && Math.abs(b1.v) >= 1) formulaWarn.push({ tab: n, b1: b1.v });
      }
    } catch (e) { }
    let formulaIssues = [];
    try { formulaIssues = auditFormulas(wb, tabs, selisihAt ? selisihAt.split('!')[0] : null, formulaWarn); } catch (e) { formulaIssues = []; }
    return { file: fileName, tabs, entries: flat, wdRows, loose, selisih, selisihAt, formulaWarn, headerDiffs, formulaIssues, bankRows, lateA, grossDays };
  }

  // ---------- cek rumus buku ----------
  // effect = selisih sekarang − selisih kalau rumusnya benar (bagian selisih yang disebabkan rumus)
  const colN = c => XLSX.utils.decode_col(c), colA = n => XLSX.utils.encode_col(n);
  function rangesIn(f, defSheet) {
    const out = []; const re = /(?:'((?:[^']|'')+)'|([A-Za-z0-9_]+))?(!)?\$?([A-Z]{1,3})\$?(\d+):\$?([A-Z]{1,3})\$?(\d+)/g; let m;
    while ((m = re.exec(f))) { const sh = m[3] ? (m[1] != null ? m[1].replace(/''/g, "'") : m[2]) : defSheet; out.push({ sheet: sh, c1: colN(m[4]), r1: +m[5], c2: colN(m[6]), r2: +m[7] }); }
    return out;
  }
  function lastSumRange(f) { const all = [...String(f || '').matchAll(/SUM\(\$?([A-Z]{1,3})\$?(\d+):\$?([A-Z]{1,3})\$?(\d+)\)/gi)]; const m = all[all.length - 1]; return m ? { c1: colN(m[1].toUpperCase()), c2: colN(m[3].toUpperCase()), row: +m[2] } : null; }
  function auditFormulas(wb, tabs, main, formulaWarn) {
    const issues = [];
    if (!main) return issues;
    const M = wb.Sheets[main], fA1 = (M['A1'] && M['A1'].f) || '', fA3 = (M['A3'] && M['A3'].f) || '';
    if (!fA3) return issues;
    const cell = (ws, c, r) => ws[colA(c) + r];
    const numv = x => (x && typeof x.v === 'number') ? x.v : null;
    const blank = x => !x || x.v == null || String(x.v).trim() === '';
    const R = v => Math.round(v * 100) / 100;
    const keyHdr = /serial|number|nomor|phone|hp\b|transaction|rrn|rate|note|ket|id\b/i;
    const A3r = rangesIn(fA3.replace(/^.*?A1\s*-/i, ''), main), A1r = rangesIn(fA1, main).filter(x => x.c1 === 0 && x.c2 === 0);
    const b1InA1 = n => new RegExp((n === main ? "(^|[^!A-Z0-9])" : "'?" + n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + "'?!") + '\\$?B\\$?1\\b', 'i').test(fA1);
    if (/#REF!/i.test(fA1 + fA3)) issues.push({ kind: 'ref', tab: main, effect: 0, title: 'Rumus selisih rusak (#REF!)', story: 'Rumus A1 atau A3 di ' + main + ' berisi #REF!: ada tab atau kolom yang dihapus sehingga tidak ikut terhitung.', steps: ['Perbaiki referensi #REF! di rumus A1/A3 ' + main + ' (tulis ulang nama tab dan rentangnya)'] });
    for (const n of tabs) {
      const ws = wb.Sheets[n]; if (!ws || !ws['!ref']) continue;
      const rg = XLSX.utils.decode_range(ws['!ref']); const maxR = rg.e.r + 1;
      // kolom bank tab ini: rentang SUM terakhir di rumus kolom A (model buku VIP/MW288) atau kolom F (model MW188)
      const tally = (col) => { const cnt = new Map(); for (let r = 5; r <= maxR; r++) { const x = cell(ws, col, r); if (x && x.f) { const sr = lastSumRange(x.f); if (sr) { const k = sr.c1 + ':' + sr.c2; cnt.set(k, (cnt.get(k) || 0) + 1); } } } let best = null, bn = 0; for (const [k, v] of cnt) if (v > bn) { best = k; bn = v; } return best ? { c1: +best.split(':')[0], c2: +best.split(':')[1], n: bn } : null; };
      let rowA = 0; for (let r = 5; r <= maxR; r++) { const x = cell(ws, 0, r); if (x && x.f && /COUNT\(/i.test(x.f) && /IF\(/i.test(x.f)) rowA++; }
      const tA = rowA ? tally(0) : null, tF = tally(5);
      const bank = tA || tF;                        // kolom yang dijumlah rumus per baris
      if (!bank || bank.c1 < 6) continue;
      const bankU = { c1: Math.min(...[tA, tF].filter(Boolean).map(x => x.c1)), c2: Math.max(...[tA, tF].filter(Boolean).map(x => x.c2)) };   // semua kolom rekening
      const hdrSkip = new Set(); for (let c = bankU.c1; c <= bankU.c2 + 30; c++) for (let r = 1; r <= 4; r++) { const h = cell(ws, c, r); if (h && typeof h.v === 'string' && keyHdr.test(h.v) && !/^\s*=/.test(h.v)) hdrSkip.add(c); }
      const rowS = r => { let s = 0, k = 0; for (let c = bank.c1; c <= bank.c2; c++) { const v = numv(cell(ws, c, r)); if (v != null && v !== 0) { s += v; k++; } } return { s, k }; };
      const rowSU = (r, c1 = bankU.c1, c2 = bankU.c2) => { let s = 0, k = 0; for (let c = c1; c <= c2; c++) { if (hdrSkip.has(c)) continue; const v = numv(cell(ws, c, r)); if (v != null && v !== 0) { s += v; k++; } } return { s, k }; };
      const short = n === main ? "" : (/^[A-Za-z0-9_]+$/.test(n) ? n + '!' : "'" + n + "'!");
      // 1. rentang A3 untuk tab ini. Cek BARIS dimatikan: rentang terbuka Google Sheets (A5:A) berubah jadi A5:A<baris terakhir tab rumus>
      //    waktu di-download .xlsx, jadi tidak bisa dinilai dari file. Yang dicek: tab tidak ikut dan kolom bank yang tidak ikut.
      const a3 = A3r.filter(x => x.sheet === n && x.c1 >= 6);
      const a1 = A1r.filter(x => x.sheet === n);
      let lastBank = 0, lastA = 0;
      for (let r = 5; r <= maxR; r++) { if (rowSU(r).k) lastBank = r; const av = numv(cell(ws, 0, r)); if (av != null && av !== 0) lastA = r; }
      if (!a3.length) {
        let tot = 0; for (let r = 5; r <= maxR; r++) tot += rowSU(r).s;
        if (Math.abs(tot) >= 1) issues.push({ kind: 'a3tab', tab: n, effect: R(tot), title: 'Tab ' + n + ' tidak ikut di rumus selisih', story: 'Kolom bank di tab ' + n + ' (total ' + fmtID(tot) + ') tidak ada di rumus A3 ' + main + ', jadi uangnya tidak ikut dihitung.', steps: ['Tambahkan ' + short + colA(bankU.c1) + '5:' + colA(bankU.c2) + Math.max(maxR, lastBank) + ' ke SUM di rumus A3 ' + main] });
      } else {
        const r2a = Math.max(...a3.map(x => x.r2)), c1a = Math.min(...a3.map(x => x.c1)), c2a = Math.max(...a3.map(x => x.c2));
        if (false && lastBank > r2a) { let y = 0; for (let r = r2a + 1; r <= lastBank; r++) y += rowSU(r, c1a, c2a).s; if (Math.abs(y) >= 1) issues.push({ kind: 'a3rows', tab: n, effect: R(y), title: 'Rumus selisih tidak sampai ke baris terakhir ' + n, story: 'Rumus A3 ' + main + ' hanya menjumlah ' + n + ' sampai baris ' + r2a + ', padahal ada nominal bank sampai baris ' + lastBank + ' (total ' + fmtID(y) + ' tidak terhitung).', steps: ['Ubah rentang ' + short + colA(c1a) + '5:' + colA(c2a) + r2a + ' di rumus A3 ' + main + ' jadi sampai baris ' + Math.max(maxR, lastBank)] }); }
        if (c1a > bankU.c1 || c2a < bankU.c2) {
          let y = 0, cols = new Set();
          for (let r = 5; r <= Math.min(r2a, maxR); r++) for (let c = bankU.c1; c <= bankU.c2; c++) { if (c >= c1a && c <= c2a) continue; if (hdrSkip.has(c)) continue; const v = numv(cell(ws, c, r)); if (v != null && v !== 0) { y += v; cols.add(colA(c)); } }
          if (Math.abs(y) >= 1) issues.push({ kind: 'a3cols', tab: n, effect: R(y), title: 'Kolom bank ' + [...cols].join(', ') + ' di ' + n + ' tidak ikut di rumus selisih', story: 'Rumus A3 ' + main + ' menjumlah ' + n + ' kolom ' + colA(c1a) + '–' + colA(c2a) + ', padahal rekening di tab itu sampai kolom ' + colA(bankU.c2) + ' (total ' + fmtID(y) + ' tidak terhitung).', steps: ['Ubah rentang ' + short + colA(c1a) + '5:' + colA(c2a) + r2a + ' di rumus A3 ' + main + ' jadi ' + short + colA(Math.min(c1a, bankU.c1)) + '5:' + colA(Math.max(c2a, bankU.c2)) + r2a] });
        }
      }
      // 2. rentang A1 (kolom A tab ini)
      if (!a1.length) {
        let x = 0; for (let r = 5; r <= maxR; r++) { const av = numv(cell(ws, 0, r)); if (av) x += av; }
        if (Math.abs(x) >= 1) issues.push({ kind: 'a1tab', tab: n, effect: R(-x), title: 'Kolom A tab ' + n + ' tidak ikut di rumus selisih', story: 'Catatan +/− di kolom A tab ' + n + ' (total ' + fmtID(x) + ') tidak ada di rumus A1 ' + main + '.', steps: ['Tambahkan ' + short + 'A5:A' + Math.max(maxR, lastA) + ' ke rumus A1 ' + main] });
      } else {
        const r2a = Math.max(...a1.map(x => x.r2));
        if (false && lastA > r2a) { let x = 0; for (let r = r2a + 1; r <= lastA; r++) { const av = numv(cell(ws, 0, r)); if (av) x += av; } if (Math.abs(x) >= 1) issues.push({ kind: 'a1rows', tab: n, effect: R(-x), title: 'Rumus selisih tidak sampai ke baris terakhir kolom A ' + n, story: 'Rumus A1 ' + main + ' hanya menjumlah kolom A ' + n + ' sampai baris ' + r2a + ', padahal ada catatan sampai baris ' + lastA + ' (total ' + fmtID(x) + ' tidak terhitung).', steps: ['Ubah ' + short + 'A5:A' + r2a + ' di rumus A1 ' + main + ' jadi sampai baris ' + Math.max(maxR, lastA)] }); }
      }
      // 3. rumus per baris
      if (rowA) {
        // model VIP/MW288: kolom A = IF(COUNT(..)>1,"ERROR",IF(E="",IF(SUM>0,SUM,""),""))
        let tmpl = null; for (let r = 5; r <= maxR && !tmpl; r++) { const x = cell(ws, 0, r); if (x && x.f && /COUNT\(/i.test(x.f) && lastSumRange(x.f) && lastSumRange(x.f).c1 === bank.c1 && lastSumRange(x.f).c2 === bank.c2) tmpl = { f: x.f, r }; }
        const fFor = r => tmpl ? '=' + tmpl.f.replace(/([A-Z]{1,3})(\d+)/g, (m, c, d) => +d === tmpl.r ? c + r : m) : '';
        const bad = [], err = [], wrong = [];
        for (let r = 5; r <= maxR; r++) {
          const x = cell(ws, 0, r), { s, k } = rowS(r);
          if (x && x.v === 'ERROR') { err.push({ r, s }); continue; }
          if (x && x.f && /COUNT\(/i.test(x.f)) { const refs = [...x.f.matchAll(/[A-Z]{1,3}(\d+)/g)].map(m => +m[1]); if (refs.some(d => d !== r)) wrong.push({ r, f: x.f, s, a: numv(x) || 0 }); }
          if (!blank(cell(ws, 4, r)) || !(s > 0.5)) continue;
          const a = numv(x); if (a != null && Math.abs(a - s) < 0.5) continue;
          if (x && x.f && /COUNT\(/i.test(x.f) && wrong.length && wrong[wrong.length - 1].r === r) continue;
          bad.push({ r, s, a: a || 0, typed: !!(x && !x.f && !blank(x)) });
        }
        for (const b of bad) issues.push({ kind: 'rowA', tab: n, row: b.r, effect: R(b.a - b.s), title: b.typed ? 'Kolom A diketik manual, rumusnya tertimpa' : 'Rumus kolom A hilang', story: n + ' baris ' + b.r + ': USER ID kosong dan ada nominal bank ' + fmtID(b.s) + ', tapi kolom A ' + (b.typed ? 'berisi angka ketikan ' + fmtID(b.a) : 'kosong') + '. Seharusnya kolom A otomatis ' + fmtID(b.s) + ' supaya uang tanpa user tidak bikin selisih.', steps: ['Isi lagi rumus di ' + n + '!A' + b.r + (tmpl ? ': ' + fFor(b.r) : ' (salin dari baris di atasnya)'), 'Kalau baris ini memang deposit member, isi USER ID-nya di kolom E'] });
        for (const w of wrong) issues.push({ kind: 'rowAwrong', tab: n, row: w.r, effect: R(w.a - (blank(cell(ws, 4, w.r)) && w.s > 0.5 ? w.s : 0)), title: 'Rumus kolom A menunjuk baris lain', story: n + '!A' + w.r + ' berisi ' + w.f.slice(0, 60) + '…, yang membaca baris lain, bukan baris ' + w.r + ' sendiri.', steps: ['Ganti rumus di ' + n + '!A' + w.r + (tmpl ? ' jadi ' + fFor(w.r) : ' (salin dari baris di atasnya)')] });
        for (const e of err) issues.push({ kind: 'rowErr', tab: n, row: e.r, effect: R(blank(cell(ws, 4, e.r)) ? -e.s : 0), title: 'Dua kolom bank terisi di satu baris', story: n + ' baris ' + e.r + ' menampilkan ERROR: ada lebih dari satu kolom rekening yang terisi (' + fmtID(e.s) + ').', steps: ['Pecah jadi dua baris, satu rekening per baris'] });
      } else if (!formulaWarn.some(w => w.tab === n) && (n === main || b1InA1(n) || b1InA1(main))) {
        // model MW188: kolom F = jumlah bank per baris, B1 = SUMIFS(F, E kosong, F>0)
        const b1 = ws['B1'] && ws['B1'].f || '';
        if (/SUMIFS/i.test(b1) && b1InA1(n)) {
          const fr = rangesIn(b1, n).find(x => x.c1 === 5);
          for (let r = 5; r <= maxR; r++) {
            if (!blank(cell(ws, 4, r))) continue; const { s } = rowS(r); if (!(s > 0.5)) continue;
            const fx = cell(ws, 5, r), f = numv(fx);
            if (f != null && Math.abs(f - s) < 0.5) { if (false) issues.push({ kind: 'b1rows', tab: n, row: r, effect: R(-s), title: 'Rumus B1 ' + n + ' tidak sampai baris ' + r, story: 'B1 ' + n + ' menjumlah uang tanpa user sampai baris ' + fr.r2 + ', baris ' + r + ' (' + fmtID(s) + ') tidak ikut.', steps: ['Perpanjang rentang di rumus ' + n + '!B1 sampai baris ' + maxR] }); continue; }
            issues.push({ kind: 'rowF', tab: n, row: r, effect: R((f || 0) - s), title: 'Rumus kolom F (NOMINAL) hilang', story: n + ' baris ' + r + ': USER ID kosong dan ada nominal bank ' + fmtID(s) + ', tapi kolom F ' + (f == null ? 'kosong' : fmtID(f)) + ', jadi tidak ikut di B1.', steps: ['Isi lagi rumus kolom F di ' + n + '!F' + r + ' (salin dari baris di atasnya)'] });
          }
        }
      }
    }
    return issues;
  }
  const fmtID = n => (Math.round(n * 100) / 100).toLocaleString('id-ID', { maximumFractionDigits: 2 });

  // ---------- load everything ----------
  async function load(files) {
    const all = await expand(files);
    const hoki = [], bo = [], coin = [], log = []; let buku = null;
    for (const f of all) {
      let info;
      try { info = sheetsOf(f); } catch (e) { log.push({ file: f.name, type: 'GAGAL DIBACA', n: 0, err: String(e) }); continue; }
      if (info.kind === 'wb') {
        const bk = (() => { try { return parseBuku(info.wb, f.name); } catch (e) { return null; } })();
        if (bk) { buku = bk; log.push({ file: f.name, type: 'Buku', n: bk.entries.length }); continue; }
      }
      let used = false;
      for (const s of info.sheets) {
        let h;
        if ((h = findHeader(s.rows, ['whitelabel transaction id', 'status', 'total amount']))) { const x = parseHoki(s.rows, h, f.name); hoki.push(...x); log.push({ file: f.name, type: 'Hoki', n: x.length }); used = true; break; }
        if ((h = findHeader(s.rows, ['transaction id', 'username', 'fund method', 'debit', 'credit']))) { const x = parseBoOne(s.rows, h, f.name); bo.push(...x); log.push({ file: f.name, type: 'BO', n: x.length }); used = true; break; }
        if ((h = findHeader(s.rows, ['transaction id', 'user name', 'fund method', 'status title']))) { const x = parseBoTsv(s.rows, h, f.name); bo.push(...x); log.push({ file: f.name, type: 'BO', n: x.length }); used = true; break; }
        if ((h = findHeader(s.rows, ['transaction id', 'transaction type', 'debit', 'credit', 'balance']))) { const x = parseCoin(s.rows, h, f.name); coin.push(...x); log.push({ file: f.name, type: 'Coin log', n: x.length }); used = true; break; }
      }
      if (!used) log.push({ file: f.name, type: 'TIDAK DIKENALI', n: 0 });
    }
    return { hoki, bo, buku, coin, log };
  }

  // ---------- analysis ----------
  function analyze(data, opt = {}) {
    const { hoki: hokiRaw, bo: boRaw, buku } = data;
    // dedupe hoki by tid
    const hokiMap = new Map();
    for (const h of hokiRaw) { const p = hokiMap.get(h.tid); if (!p || (h.fin || '') > (p.fin || '')) hokiMap.set(h.tid, h); }
    const hoki = [...hokiMap.values()];
    // dedupe BO by tid+status+amount
    const seen = new Set(); const bo = [];
    for (const b of boRaw) { const k = b.tid + '|' + b.status + '|' + b.debit + '|' + b.credit; if (seen.has(k)) continue; seen.add(k); bo.push(b); }
    const isAdj = b => /adjustment/i.test(b.fm);
    const isWD = b => !isAdj(b) && !(b.credit > 0) && (b.ttype ? b.ttype === '2' : true);
    const wdMap = new Map();
    for (const b of bo) if (isWD(b)) { const p = wdMap.get(b.tid); if (!p || (p.status !== 'Confirmed' && b.status === 'Confirmed')) wdMap.set(b.tid, b); }
    const adj = bo.filter(b => isAdj(b) && /confirm/i.test(b.status)).map(b => ({ ...b, amt: b.debit > 0 ? b.debit : b.credit, dir: b.debit > 0 ? 'CUT' : 'ADD', u: low(b.user), used: null, usedAmt: 0 }))
      .sort((a, b) => a.tdate < b.tdate ? -1 : 1);

    const hokiDays = [...new Set(hoki.map(h => day(h.trx)).filter(Boolean))].sort();
    const S0 = hokiDays[0] || '', Dmax = hokiDays[hokiDays.length - 1] || '';
    const D = opt.closeDay || Dmax;
    // check window = closing day and the day before (the day before only to see what was still pending)
    const prev = d => { if (!d) return ''; const t = new Date(d + 'T00:00:00Z'); t.setUTCDate(t.getUTCDate() - 1); return t.toISOString().slice(0, 10); };
    const S = S0 > prev(D) ? S0 : prev(D);
    const hokiMin = hoki.reduce((m, h) => !m || h.trx < m ? h.trx : m, '');
    const hokiMax = hoki.reduce((m, h) => !m || h.trx > m ? h.trx : m, '');

    // classify hoki WD
    const items = hoki.map(h => {
      const b = wdMap.get(h.tid);
      const st = /success/i.test(h.status) ? 'S' : /refund/i.test(h.status) ? 'R' : 'X';
      let cls;
      if (!b) cls = 'NO_BO';
      else if (st === 'S' && b.status === 'Confirmed') cls = 'OK';
      else if (st === 'R' && /reject/i.test(b.status)) cls = 'OK_R';
      else if (st === 'R' && b.status === 'Confirmed') cls = 'NEED_ADD';
      else if (st === 'S' && /reject/i.test(b.status)) cls = 'NEED_CUT';
      else cls = 'OTHER';
      return { tid: h.tid, user: b ? b.user : '', u: b ? low(b.user) : '', amt: h.amt, hst: h.status, bst: b ? b.status : '-', trx: h.trx, fin: h.fin, hby: h.by, name: h.name, pm: h.pm, boAmt: b ? b.debit : null, boNote: b ? b.note : '', boBy: b ? b.by : '', cls, matches: [] };
    });
    const tidSet = new Set(hoki.map(h => h.tid));
    // coin log: refund Hoki tanpa baris BO dan tanpa gerakan coin = WD ditolak sebelum diproses (coin member aman)
    const coinChk = data.coin && data.coin.length ? checkCoin(data.coin) : null;
    const coinCovers = tid => { const x = tidTime(tid); return !!(coinChk && x != null && coinChk.tMin != null && x > coinChk.tMin + 60 && x < coinChk.tMax - 60); };
    const coinHas = tid => !!coinChk && coinChk.tids.has(String(tid).toUpperCase());
    const coinNear = t => coinHas(t) || [...coinChk.tids].some(c => c.slice(0, 5) === t.slice(0, 5) && tidNear(c, t));
    if (coinChk) for (const it of items) if (it.cls === 'NO_BO' && /refund/i.test(it.hst) && coinCovers(it.tid) && !coinHas(it.tid)) { it.cls = 'OK_R'; it.noCoin = true; }

    // BO confirmed WD (hoki channel) not in hoki, within hoki time range
    const manual = [];
    for (const b of wdMap.values()) {
      if (b.status !== 'Confirmed' || tidSet.has(b.tid)) continue;
      if (/netz/i.test(b.fm)) continue;
      // only WDs confirmed by the QRISHOKI account (paid through Hoki); manual payouts (bot/KPS, staff) are outside
      // GIGA: WD lewat Hoki dikonfirmasi "…@report -: Auto System", tanda Hoki-nya ada di Fund Method "(QRISHOKI)"
      if (b.by && !/qrishoki/i.test(b.by) && !/qrishoki/i.test(b.fm || '')) continue;
      const when = b.ctime || b.tdate;
      if (!when || when < hokiMin.slice(0, 10) + ' 00:00:00' || when > hokiMax) continue;
      manual.push({ tid: b.tid, user: b.user, u: low(b.user), amt: b.debit, trx: b.tdate, fm: b.fm, boBy: b.by, cls: 'MANUAL', matches: [] });
    }

    // matching — several passes so the clearest pairing wins
    const eq = (x, y) => Math.abs(x - y) < 0.5;
    function take(it, list, alloc) { list.forEach(a => { a.used = it; }); it.matches = it.matches.concat(list); it.alloc = (it.alloc || []).concat(alloc || list.map(a => a.amt)); }
    const got = it => (it.alloc || []).reduce((s, x) => s + x, 0);
    const open = it => !it.matches.length;
    const byTime = (a, b) => a.trx < b.trx ? -1 : 1;
    const groups = [
      [items.filter(i => i.cls === 'NEED_CUT').sort(byTime), 'CUT'],
      [items.filter(i => i.cls === 'NEED_ADD').concat(manual).sort(byTime), 'ADD']
    ];
    const poolFor = (it, dir) => adj.filter(a => !a.used && a.dir === dir && a.u === it.u && a.tdate >= (it.trx || '') && !noteConflict(a, it.tid));
    for (const [list, dir] of groups) {
      // 1) adjustment note names the WD TID (GIGA style)
      for (const it of list) {
        const T = String(it.tid).toUpperCase(); if (T.length < 8) continue;
        const byNote = adj.filter(a => !a.used && a.dir === dir && String(a.note || '').toUpperCase().includes(T));
        const mine = byNote.filter(a => a.u === it.u);
        byNote.filter(a => a.u !== it.u).forEach(a => { a.wrongUser = { tid: it.tid, user: it.user }; });
        if (mine.length) take(it, mine);
      }
      // 1b) TID di note salah ketik sedikit (beda 1-3 karakter), user sama
      for (const it of list) {
        if (!open(it) || String(it.tid).length < 8) continue;
        const fz = adj.filter(a => !a.used && a.dir === dir && a.u === it.u && a.tdate >= (it.trx || '') && noteTids(a.note).some(t => tidNear(t, it.tid)));
        if (fz.length) take(it, fz);
      }
      // 3) one adjustment covering several WDs of the same user (e.g. ADD 1.052.500 for six refunds)
      for (const a of adj.filter(a => !a.used && a.dir === dir)) {
        const cand = list.filter(it => open(it) && it.u === a.u && (it.trx || '') <= a.tdate && !noteConflict(a, it.tid)).slice(-12);
        if (cand.length < 2 || cand.some(it => eq(it.amt, a.amt))) continue;
        let best = null; const n = cand.length;
        for (let m = 1; m < (1 << n) && !best; m++) {
          let sum = 0, pick = []; for (let k = 0; k < n; k++) if (m & (1 << k)) { sum += cand[k].amt; pick.push(cand[k]); }
          if (pick.length >= 2 && eq(sum, a.amt)) best = pick;
        }
        if (best) best.forEach(it => { take(it, [a], [it.amt]); });
      }
      // 2) one adjustment, same user, same amount
      for (const it of list) { if (!open(it)) continue; const ex = poolFor(it, dir).find(a => eq(a.amt, it.amt)); if (ex) take(it, [ex]); }
      // 4) several adjustments for one WD (split addback)
      for (const it of list) {
        if (!open(it)) continue; const pool = poolFor(it, dir); let done = false;
        for (let i = 0; i < pool.length && !done; i++) for (let j = i + 1; j < pool.length && !done; j++) {
          if (eq(pool[i].amt + pool[j].amt, it.amt)) { take(it, [pool[i], pool[j]]); done = true; break; }
          for (let k = j + 1; k < pool.length; k++) if (eq(pool[i].amt + pool[j].amt + pool[k].amt, it.amt)) { take(it, [pool[i], pool[j], pool[k]]); done = true; break; }
        }
      }
      // 5) partial: one smaller adjustment close to the amount
      for (const it of list) {
        if (!open(it)) continue;
        const sm = poolFor(it, dir).filter(a => a.amt < it.amt).sort((a, b) => b.amt - a.amt)[0];
        if (sm && (it.amt - sm.amt) <= Math.max(1000, it.amt * 0.2)) take(it, [sm]);
      }
      list.forEach(it => { it.partial = it.matches.length > 0 && !eq(got(it), it.amt); });
    }
    // kelebihan: refund di-add lebih (atau sukses-reject di-cut lebih), lalu kelebihannya ditarik balik
    // (mis. ADD 200 + ADD 200 untuk refund 200, lalu "DB ADJUST" CUT 200) -> pasangkan, hasilnya pas
    for (const [list, dir] of groups) {
      const back = dir === 'ADD' ? 'CUT' : 'ADD';
      for (const it of list) {
        const over = r2(got(it) - it.amt); if (!(over >= 0.5) || !it.matches.length) continue;
        const first = it.matches.reduce((m, a) => (!m || a.tdate < m) ? a.tdate : m, '');
        const c = adj.filter(a => !a.used && a.dir === back && a.u === it.u && a.tdate >= first && eq(a.amt, over)).sort((p, q) => p.tdate < q.tdate ? -1 : 1)[0];
        if (c) { take(it, [c], [-c.amt]); it.partial = false; }
      }
    }
    // "SALAH ADJUST"-type corrections undo an earlier opposite adjustment of the same user — pair them before anything else claims it
    for (const a of adj.filter(a => !a.used && /salah|keliru|batal|cancel/i.test(a.note || ''))) {
      const prevOpp = adj.filter(x => !x.used && x !== a && x.u === a.u && x.dir !== a.dir && x.tdate <= a.tdate).sort((p, q) => p.tdate < q.tdate ? 1 : -1);
      const one = prevOpp.find(x => Math.abs(x.amt - a.amt) < 0.5);
      if (one) { a.used = { cls: 'PAIR', other: one.tid }; one.used = { cls: 'PAIR', other: a.tid }; }
    }
    // leftover ADD that returns a BO-confirmed WD paid outside Hoki (bank manual / NETZPAY) → outside this check
    const hrsBetween = (x, y) => (Date.parse(String(y).replace(' ', 'T') + 'Z') - Date.parse(String(x).replace(' ', 'T') + 'Z')) / 3.6e6;
    const recentPaid = a => items.find(it => it.cls === 'OK' && it.u === a.u && Math.abs(it.amt - a.amt) < 0.5 && (it.fin || it.trx) <= a.tdate && hrsBetween(it.fin || it.trx, a.tdate) <= 24) || null;
    const nonHokiWD = [...wdMap.values()].filter(b => b.status === 'Confirmed' && !tidSet.has(b.tid) && !manual.some(m => m.tid === b.tid))
      .map(b => ({ ...b, u: low(b.user), taken: false })).sort((a, b) => a.tdate < b.tdate ? -1 : 1);
    for (const a of adj) {
      if (a.used || a.dir !== 'ADD' || a.wrongUser) continue;
      const T = String(a.note || '').toUpperCase();
      let w = nonHokiWD.find(b => !b.taken && b.tid.length >= 8 && T.includes(b.tid.toUpperCase()));
      if (!w) w = nonHokiWD.find(b => !b.taken && b.u === a.u && b.tid.length >= 8 && noteTids(a.note).some(t => tidNear(t, b.tid)));
      // tanpa TID di note: WD lama (>24 jam) tidak dipakai kalau ada WD Hoki sukses dengan nominal sama tidak lama sebelum ADD —
      // ADD itu lebih mungkin "pengembalian" WD yang sebenarnya sudah dibayar (dicek di bagian expected)
      if (!w) w = nonHokiWD.find(b => !b.taken && b.u === a.u && Math.abs(b.debit - a.amt) < 0.5 && b.tdate <= a.tdate && (hrsBetween(b.tdate, a.tdate) <= 24 || !recentPaid(a)) && !noteConflict(a, b.tid));
      if (w) { w.taken = true; a.used = { cls: 'OUTSIDE', tid: w.tid, fm: w.fm }; a.outside = true; }
    }
    for (const a of adj) {
      if (a.used || a.dir !== 'ADD' || a.wrongUser) continue;
      const okW = (w, x) => !w.taken && w.u === a.u && Math.abs(w.debit - a.amt - x.amt) < 0.5 && w.tdate <= a.tdate && !noteConflict(a, w.tid) && !noteConflict(x, w.tid);
      const b = adj.find(x => x !== a && !x.used && !x.wrongUser && x.dir === 'ADD' && x.u === a.u && nonHokiWD.some(w => okW(w, x)));
      if (b) { const w = nonHokiWD.find(w => okW(w, b)); w.taken = true; a.used = b.used = { cls: 'OUTSIDE', tid: w.tid, fm: w.fm }; a.outside = b.outside = true; }
    }
    // reversal: one adjustment undoing several earlier opposite ones of the same user (e.g. SALAH ADJUST 125.000 = 50.000 + 25.000 + 50.000)
    for (const a of adj.filter(a => !a.used)) {
      if (a.used) continue;
      const cand = adj.filter(x => !x.used && x !== a && x.u === a.u && x.dir !== a.dir && x.tdate <= a.tdate).slice(-10);
      if (cand.length < 2) continue;
      let best = null;
      for (let m = 1; m < (1 << cand.length) && !best; m++) {
        let sum = 0, pick = []; for (let k = 0; k < cand.length; k++) if (m & (1 << k)) { sum += cand[k].amt; pick.push(cand[k]); }
        if (pick.length >= 2 && Math.abs(sum - a.amt) < 0.5) best = pick;
      }
      if (best) { a.used = { cls: 'PAIR', other: best.map(x => x.tid).join('+') }; best.forEach(x => { x.used = { cls: 'PAIR', other: a.tid }; }); }
    }
    // reversal pairs among leftovers (CUT then ADD same user same amount, or ADD then CUT)
    const left = adj.filter(a => !a.used);
    for (const a of left) {
      if (a.used) continue;
      const b = left.find(x => !x.used && x !== a && x.u === a.u && x.dir !== a.dir && Math.abs(x.amt - a.amt) < 0.5 && x.tdate >= a.tdate);
      if (b) { a.used = { cls: 'PAIR', other: b.tid }; b.used = { cls: 'PAIR', other: a.tid }; }
    }

    // expected book entries at close of D
    const endD = D + ' 23:59:59';
    const expected = [];
    const doneBy = (it, t) => it.matches.reduce((s, a, k) => s + (a.tdate <= t ? (it.alloc ? it.alloc[k] : a.amt) : 0), 0);
    for (const it of items) {
      if (day(it.trx) > D || !day(it.trx)) continue;
      if (it.cls === 'NEED_ADD') { const r = r2(it.amt - doneBy(it, endD)); if (Math.abs(r) >= 0.5) expected.push({ user: it.user, u: it.u, amt: r, why: r < 0 ? 'Refund di-add lebih' : r < it.amt ? 'Refund belum lengkap di-add' : 'Refund belum di-add', ref: it.tid, day: day(it.trx), k: r < 0 ? 'REFX' : r < it.amt ? 'REFP' : 'REF', full: it.amt, at: it.fin || it.trx }); }
      if (it.cls === 'NEED_CUT') { const r = r2(it.amt - doneBy(it, endD)); if (Math.abs(r) >= 0.5) expected.push({ user: it.user, u: it.u, amt: -r, why: r < 0 ? 'Sukses-reject di-cut lebih' : r < it.amt ? 'Sukses-reject, cut kurang' : 'Sukses-reject, belum di-cut', ref: it.tid, day: day(it.trx), k: r < 0 ? 'SRX' : r < it.amt ? 'SRP' : 'SR', full: it.amt, at: it.fin || it.trx }); }
    }
    for (const it of manual) {
      if (day(it.trx) > D) continue;
      const r = r2(it.amt - doneBy(it, endD)); if (Math.abs(r) >= 0.5) expected.push({ user: it.user, u: it.u, amt: r, why: 'Confirmed di BO, tidak ada di Hoki (cek dibayar lewat mana)', ref: it.tid, day: day(it.trx), k: 'MAN', full: it.amt, at: it.trx, fm: it.fm });
    }
    for (const a of adj) {
      if (a.used && a.used.cls !== 'PAIR') continue;
      if (a.outside) continue;
      if (/net\s*z?\s*payz?|netpayz|netzpay/i.test(a.note)) { a.outside = true; continue; }
      const d = day(a.tdate); if (d < S || d > D) continue;
      // adjustment hari sebelumnya hanya dicek kalau user-nya ada di buku, KECUALI note-nya jelas bukan urusan WD
      // (mis. "SALAH APPROVE"): pasangan WD dari hari sebelumnya mungkin tidak ada di data, tapi koreksi seperti ini tidak punya pasangan WD
      const notWd = !noteTids(a.note).length && !/wd|withdraw|refund|reject|pending|gagal|sukses|tarik|qris|hoki|balik|kembali/i.test(a.note || '') && /salah|keliru|mistake|double|dobel/i.test(a.note || '');
      if (d !== D && !notWd && !(buku && buku.entries.some(e => low(e.user) === a.u && e.date >= S && e.date <= D))) continue;
      if (a.used && a.used.cls === 'PAIR') { // pair: both inside window → net 0 ; else show the one inside
        const os = String(a.used.other).split('+').map(t => adj.find(x => x.tid === t)).filter(Boolean);
        if (os.length && os.every(o => day(o.tdate) >= S && day(o.tdate) <= D)) continue;
      }
      const twin = a.dir === 'ADD' && [...items, ...manual].find(it => it.u === a.u && it.matches.length && Math.abs(it.amt - a.amt) < 0.5 && (it.cls === 'NEED_ADD' || it.cls === 'MANUAL'));
      const why = a.wrongUser ? (a.dir === 'ADD' ? 'ADD' : 'CUT') + ' ke user yang salah — note berisi TID ' + a.wrongUser.tid + ' milik ' + a.wrongUser.user : twin ? 'ADD dobel — WD ' + twin.tid + ' (' + twin.amt.toLocaleString('id-ID') + ') sudah di-add sebelumnya' : (a.dir === 'CUT' ? 'CUT' : 'ADD') + ' di BO tanpa pasangan WD' + (a.note ? ' — ' + a.note : '');
      // ADD tanpa pasangan, padahal WD user ini dengan nominal sama sukses dibayar Hoki tidak lama sebelumnya → member dapat uang dan koin
      const paid = a.dir === 'ADD' && !a.wrongUser && !twin ? items.filter(it => it.cls === 'OK' && it.u === a.u && Math.abs(it.amt - a.amt) < 0.5 && (it.fin || it.trx) <= a.tdate && hrsBetween(it.fin || it.trx, a.tdate) <= 24 && !noteConflict(a, it.tid)).sort((p, q) => (p.fin || p.trx) < (q.fin || q.trx) ? 1 : -1)[0] || null : null;
      const noCoin = a.dir === 'ADD' && !a.wrongUser && !twin ? (noteTids(a.note).find(t => coinCovers(t) && !coinNear(t)) || null) : null;
      expected.push({ noCoin, user: a.user, u: a.u, amt: a.dir === 'CUT' ? a.amt : -a.amt, why, ref: a.tid, day: d, adj: true, bronze: /bronze/i.test(a.note), k: a.wrongUser ? 'WRONG' : twin ? 'DOBEL' : (a.dir === 'CUT' ? 'CUT' : 'ADD'), full: a.amt, at: a.tdate, note: a.note, twin: twin ? { tid: twin.tid, amt: twin.amt, when: (twin.matches[0] || {}).tdate } : null, paid: paid ? { tid: paid.tid, amt: paid.amt, when: paid.fin || paid.trx } : null, owner: a.wrongUser || null, pairOut: a.used && a.used.cls === 'PAIR' });
    }

    // compare with buku
    let compare = null;
    if (buku) {
      const expUsers = new Set(expected.map(e => e.u));
      const looseRun = (buku.loose || []).map(e => ({ ...e }));   // salinan per hitungan: input tidak boleh berubah (tombol Cari selisih bisa ditekan berkali-kali)
      const inWin = e => !e.date || (e.date >= S && e.date <= D);
      // rows written the next day are counted only for users that this check expects (late entries)
      const inWinU = e => inWin(e) || (e.date && e.date > D && expUsers.has(low(e.user)));
      const be = buku.entries.filter(e => !/^\(grup/.test(e.user) || e.groupMismatch != null).filter(inWinU).map(e => ({ ...e, u: low(e.user) }));
      // WD QRISHOKI totals per day
      const hokiPerDay = {};
      for (const h of hoki) if (/success/i.test(h.status)) { const d = day(h.trx); hokiPerDay[d] = r2((hokiPerDay[d] || 0) + h.amt); }
      const wdCheck = [];
      for (const d of hokiDays) {
        if (d > D) continue;
        const dd = +d.slice(8, 10);
        const rows = buku.wdRows.filter(w => (w.label != null ? w.label === dd : w.date === d));
        const bk = r2(-rows.reduce((s, w) => s + w.val, 0));
        wdCheck.push({ day: d, buku: bk, hoki: hokiPerDay[d] || 0, beda: r2(bk - (hokiPerDay[d] || 0)), rows });
      }
      // beda per hari: cari WD yang tidak dibayar Hoki (refund / tidak ada di Hoki) atau sukses-reject yang belum dikoreksi di baris WD buku.
      // Beda yang saling menutup dengan hari lain = baris koreksi pindah tanggal, tidak dijelaskan per TID.
      const bedaDays = wdCheck.filter(w => Math.abs(w.beda) >= 0.5);
      for (const w of bedaDays) if (bedaDays.some(o => o !== w && Math.abs(o.beda + w.beda) < 0.5)) w.cancels = true;
      for (const w of bedaDays) {
        if (w.cancels) continue;
        const cand = [];
        for (const it of items) if (day(it.trx) === w.day) { if (it.cls === 'NEED_ADD') cand.push({ it, v: it.amt }); else if (it.cls === 'NEED_CUT') cand.push({ it, v: -it.amt }); }
        for (const it of manual) if (day(it.trx) === w.day) cand.push({ it, v: it.amt });
        const sols = []; const n = Math.min(cand.length, 60);
        for (let k = 1; k <= 3 && !sols.length; k++) {
          const rec = (start, left, pick) => {
            if (sols.length > 4) return;
            if (left === 0) { if (Math.abs(pick.reduce((s, c) => s + c.v, 0) - w.beda) < 0.5) sols.push(pick.slice()); return; }
            for (let i = start; i < n; i++) { pick.push(cand[i]); rec(i + 1, left - 1, pick); pick.pop(); }
          };
          rec(0, k, []);
        }
        if (sols.length === 1) w.explain = sols[0].map(c => c.it);
        else if (sols.length > 1) w.maybe = sols.slice(0, 4).map(s => s.map(c => c.it));
      }
      // catatan: WD yang tidak dibayar Hoki dibereskan di DUA tempat — uangnya di kolom WD QRISHOKI (cek total di atas)
      // dan coin member yang sudah terpotong di UP/CUT CREDIT (+nominal sampai di-ADD, dicek per user di bawah)
      const users = new Set([...be.map(e => e.u), ...expected.map(e => e.u)]);
      const diffs = [];
      for (const u of users) {
        const b = be.filter(e => e.u === u), x = expected.filter(e => e.u === u);
        const sb = r2(b.reduce((s, e) => s + e.A, 0)), sx = r2(x.reduce((s, e) => s + e.amt, 0));
        if (Math.abs(sb - sx) < 0.5) continue;
        // same user recorded in the buku before this period (refund/adjust of an older WD)
        const old = buku.entries.filter(e => low(e.user) === u && e.date && e.date < S);
        if (old.length && Math.abs(sb + old.reduce((s, e) => s + e.A, 0) - sx) < 0.5) continue;
        // a row without user name carrying exactly the missing amount
        const lo = looseRun.find(e => !e.taken && (inWin(e) || (e.date && e.date > D)) && Math.abs(e.A - (sx - sb)) < 0.5);
        if (lo) { lo.taken = u; continue; }
        diffs.push({ user: (b[0] || x[0]).user, u, buku: sb, seharusnya: sx, beda: r2(sb - sx), bukuRows: b, expRows: x });
      }
      const known = new Set();
      items.forEach(i => { if (i.cls !== 'OK' && i.cls !== 'OK_R' && day(i.trx) <= D) known.add(i.u); });
      manual.forEach(i => known.add(i.u));
      adj.forEach(a => { const d = day(a.tdate); if (d >= S && d <= D) known.add(a.u); });
      const manualWD = [...wdMap.values()].filter(b => b.status === 'Confirmed' && !tidSet.has(b.tid) && !/qrishoki/i.test(b.by || '') && day(b.ctime || b.tdate) >= S && day(b.ctime || b.tdate) <= D);
      diffs.forEach(x => {
        x.kind = (x.expRows.length || known.has(x.u)) ? 'salah' : 'tidak-dicek';
        if (!x.expRows.length && x.bukuRows.length && manualWD.some(b => low(b.user) === x.u && x.bukuRows.some(e => Math.abs(Math.abs(e.A) - b.debit) < 0.5))) x.kind = 'manual';
      });
      diffs.sort((a, b) => Math.abs(b.beda) - Math.abs(a.beda));
      const headers = (buku.headerDiffs || []).filter(h => !h.date || (h.date >= S && h.date <= D));
      const sumH = r2(headers.reduce((s, h) => s + h.diff, 0));
      const fw = buku.formulaWarn || [];
      // rumus per baris dihitung ke "ketemu"; rentang rumus A1/A3 yang kependekan ditampilkan sebagai peringatan
      // (barisnya bisa saja ditempel sesudah grossan diambil, jadi angkanya belum tentu bagian dari selisih sekarang)
      const fi = (buku.formulaIssues || []).filter(x => /^row/.test(x.kind));
      const fr = (buku.formulaIssues || []).filter(x => !/^row/.test(x.kind));
      const sumF = r2(-fw.reduce((s, w) => s + w.b1, 0) + fi.reduce((s, x) => s + x.effect, 0));
      const sumA = r2(diffs.filter(d => d.kind === 'salah').reduce((s, d) => s + d.beda, 0) + sumH + sumF);
      const sumU = r2(diffs.filter(d => d.kind !== 'salah').reduce((s, d) => s + d.beda, 0));
      const sumW = r2(wdCheck.reduce((s, d) => s + d.beda, 0));
      // baris sesudah tanggal tutup buku: kalau gross terakhir = tanggal tutup, uangnya ikut terhitung tapi coin-nya belum ada di gross.
      // Kebiasaan buku: baris seperti ini diberi UP/CUT CREDIT = nominal sampai gross hari itu dimasukkan.
      const gMax = (buku.grossDays || []).slice().sort().pop() || '';
      const late = gMax && gMax === D ? (buku.bankRows || []).filter(r => r.date > D) : [];
      const lateOk = gMax && gMax === D ? (buku.lateA || []).filter(r => r.date > D && Math.abs(r.A - r.bank) < 0.5) : [];
      const sumL = r2(-late.reduce((s, r) => s + r.bank, 0));
      compare = { formulaWarn: fw, formulaIssues: fi, formulaRange: fr, headers, sumH, sumF, diffs, wdCheck, sumA, sumU, sumW, late, lateOk, sumL, total: r2(sumA + sumW + sumL), selisih: buku.selisih, selisihAt: buku.selisihAt };
    }

    const coverage = [];
    if (S0 > prev(D)) coverage.push('Data Hoki tgl ' + prev(D) + ' belum dimasukkan. Addback/cut hari ini untuk WD kemarin bisa terbaca tanpa pasangan, dan baris buku tgl ' + prev(D) + ' tidak dicek.');
    const adjDays = new Set(adj.map(a => day(a.tdate)));
    if (!adjDays.has(D)) coverage.push('Tidak ada adjustment tgl ' + D + ' di file BO. Masukkan export Adjustment tgl ' + prev(D) + ' sampai sekarang.');
    else if (!adjDays.has(prev(D)) || adj.filter(a => day(a.tdate) === prev(D)).length < 5) coverage.push('Adjustment tgl ' + prev(D) + ' kosong atau sangat sedikit. Pastikan export Adjustment mulai tgl ' + prev(D) + '.');
    const sum = (arr) => r2(arr.reduce((s, i) => s + i.amt, 0));
    const cnt = c => items.filter(i => i.cls === c);
    // ---------- findings: one entry per thing to fix, in plain words ----------
    const findings = [];
    if (compare) {
      const fmtN = n => Math.round(n).toLocaleString('id-ID');
      const sg = n => (n > 0 ? '+' : n < 0 ? '−' : '') + fmtN(Math.abs(n));
      const ts = t => t ? t.slice(8, 10) + '/' + t.slice(5, 7) + ' ' + t.slice(11, 16) : '';
      const loc = e => e.tab + ' baris ' + e.row;
      const resolved = (u, amts) => {
        const out = [];
        for (const it of [...items, ...manual]) {
          if (it.u !== u || !it.matches.length || !['NEED_ADD', 'NEED_CUT', 'MANUAL'].includes(it.cls)) continue;
          if (amts && !amts.some(x => Math.abs(Math.abs(x) - it.amt) < 0.5)) continue;
          const done = [...new Set(it.matches.filter(a => a.tdate <= endD))];
          if (!done.length) continue;
          out.push({ it, done });
        }
        return out;
      };
      for (const w of compare.formulaWarn) findings.push({ type: 'rumus', effect: -w.b1, user: '', title: 'Rumus selisih tidak menjumlah B1 tab ' + w.tab,
        story: 'Baris bernominal di ' + w.tab + ' yang kolom USER ID-nya kosong (total ' + fmtN(w.b1) + ') dihitung di sel B1 tab itu, tapi A1 di ' + (compare.selisihAt || '').split('!')[0] + ' tidak ikut menjumlahkannya.',
        steps: ["Tambahkan '" + w.tab + "'!B1 ke bagian SUM(B1, …) di rumus A1 " + (compare.selisihAt || '').split('!')[0]] });
      for (const x of compare.formulaIssues || []) findings.push({ type: 'rumus', effect: x.effect, user: '', title: x.title, story: x.story, steps: x.steps });
      for (const g of compare.headers) findings.push({ type: 'grup', effect: g.diff, user: '', title: 'Baris total tidak sama dengan rincian di bawahnya',
        story: g.tab + ' baris ' + g.row + ': total ' + sg(g.header) + ', sedangkan ' + g.n + ' user di bawahnya (kolom C) berjumlah ' + sg(g.members) + '. Cut sebagian yang sudah dicatat di baris user ikut dikurangkan lagi dari total, jadi terhitung dua kali.',
        steps: ['Ubah ' + g.tab + ' baris ' + g.row + ' jadi ' + sg(g.members) + ' (jumlah kolom C)', 'Cut sebagian / refund per user cukup ditulis di baris user-nya saja'] });
      // total WD Hoki per hari di buku vs Hoki sukses
      for (const w of compare.wdCheck) {
        if (Math.abs(w.beda) < 0.5 || w.cancels) continue;
        const dl = w.day.slice(8, 10) + '/' + w.day.slice(5, 7);
        const firstAdj = it => it.matches.filter(a => a.tdate <= endD).map(a => a.tdate).sort()[0] || '';
        const f = { type: w.explain ? 'tambah' : 'cek', effect: w.beda, user: '', title: 'Total WD Hoki tgl ' + dl + ' di buku ' + (w.beda > 0 ? 'lebih ' : 'kurang ') + fmtN(Math.abs(w.beda)) + ' dari Hoki', story: '', steps: [],
          evidence: w.rows.map(x => x.tab + ' baris ' + x.row + ' ' + sg(x.val)) };
        const head = 'Kolom WD QRISHOKI tgl ' + dl + ' di buku ' + fmtN(w.buku) + ', Hoki sukses ' + fmtN(w.hoki) + '. ';
        if (w.explain) {
          f.story = head + 'Bedanya pas dengan: ' + w.explain.map(it => {
            const a = firstAdj(it);
            if (it.cls === 'NEED_CUT') return 'WD ' + it.user + ' ' + fmtN(it.amt) + ' (TID ' + it.tid + ') sukses dibayar Hoki ' + ts(it.fin || it.trx) + ' tapi Rejected di BO' + (a ? ', sudah di-CUT ' + ts(a) : ', belum di-CUT') + '.';
            if (it.cls === 'MANUAL') return 'WD ' + it.user + ' ' + fmtN(it.amt) + ' (TID ' + it.tid + ') Confirmed di BO ' + ts(it.trx) + ' lewat QRISHOKI, tapi tidak ada sama sekali di laporan Hoki, jadi tidak terbayar' + (a ? '; sudah di-ADD balik ' + ts(a) : '; koinnya juga belum di-ADD balik') + '.';
            return 'WD ' + it.user + ' ' + fmtN(it.amt) + ' (TID ' + it.tid + ') Confirmed di BO tapi di-refund Hoki ' + ts(it.fin || it.trx) + (a ? ', sudah di-ADD ' + ts(a) : ', belum di-ADD') + '.';
          }).join(' ') + ' ' + (w.beda > 0 ? 'Di buku masih terhitung sebagai WD yang dibayar.' : 'Di buku belum terhitung sebagai WD yang dibayar.');
          f.steps.push('Tambah baris ' + sg(w.beda) + ' di kolom WD QRISHOKI tgl ' + dl + ' (' + w.explain.map(it => it.user + ' ' + fmtN(it.amt)).join(' + ') + ')');
          const open = w.explain.filter(it => !firstAdj(it));
          if (open.length) f.steps.push('Coin-nya belum dibereskan di BO: ' + open.map(it => it.user).join(', ') + ' — lihat kartu user itu (UP/CUT CREDIT)');
        } else {
          f.story = head + (w.maybe ? 'Bisa salah satu dari: ' + w.maybe.map(s => s.map(it => it.user + ' ' + fmtN(it.amt)).join(' + ')).join(' / ') + '.' : 'Tidak ada kombinasi WD refund / tidak terbayar / sukses-reject yang pas dengan bedanya.');
          f.steps.push('Cocokkan baris WD QRISHOKI tgl ' + dl + ' dengan total Sukses di laporan Hoki');
        }
        findings.push(f);
      }
      if (compare.late.length) {
        const L = compare.late, dl = d => d.slice(8, 10) + '/' + d.slice(5, 7);
        const days = [...new Set(L.map(r => dl(r.date)))].join(', ');
        findings.push({ type: 'tambah', effect: compare.sumL, user: L.length === 1 ? L[0].user : L.length + ' baris', title: 'Baris tgl ' + days + ' belum diberi UP/CUT CREDIT',
          story: 'Gross terakhir di buku tgl ' + dl(D) + ', tapi ada baris tgl ' + days + ' yang nominalnya ikut dihitung di selisih: ' + L.map(r => r.user + ' ' + sg(r.bank) + ' (' + r.tab + ' baris ' + r.row + ')').join(', ') + '. Coin-nya belum ada di gross, jadi selisih tutup buku tgl ' + dl(D) + ' kena.' + (compare.lateOk.length ? ' Baris tgl ' + days + ' lain (' + compare.lateOk.slice(0, 4).map(r => r.user).join(', ') + ') sudah ditulis UP/CUT CREDIT = nominal.' : ''),
          steps: L.map(r => 'Isi UP/CUT CREDIT ' + r.tab + ' baris ' + r.row + ' = ' + sg(r.bank)).concat(['Hapus lagi isinya saat gross tgl ' + days + ' dimasukkan']) });
      }
      // whole groups resolved later → one finding
      const sal = compare.diffs.filter(d => d.kind === 'salah');
      const grp = {};
      sal.filter(d => !d.expRows.length && d.bukuRows.length && d.bukuRows.every(e => e.groupRow)).forEach(d => { const k = d.bukuRows[0].tab + '!' + d.bukuRows[0].groupRow; (grp[k] = grp[k] || []).push(d); });
      const used = new Set();
      for (const [k, list] of Object.entries(grp)) {
        if (list.length < 2) continue;
        list.forEach(d => used.add(d));
        const eff = r2(list.reduce((s, d) => s + d.beda, 0));
        let last = ''; list.forEach(d => resolved(d.u).forEach(x => x.done.forEach(a => { if (a.tdate > last) last = a.tdate; })));
        const [tab, row] = k.split('!');
        findings.push({ type: 'grup', effect: eff, user: list.length + ' user', title: 'Semua user di baris total sudah beres, tapi barisnya belum dibalik',
          story: tab + ' baris ' + row + ': total ' + sg(eff) + '. Semua ' + list.length + ' user di rincian bawahnya sudah dibereskan di BO' + (last ? ' (terakhir ' + ts(last) + ')' : '') + ', tapi di buku belum ada baris kebalikannya. User: ' + list.map(d => d.user).join(', ') + '.',
          steps: ['Tambah ' + sg(-eff) + ' di tanggal beresnya (satu baris, kebalikan dari ' + tab + ' baris ' + row + ')'] });
      }
      for (const d of sal) {
        if (used.has(d)) continue;
        const f = { type: 'cek', effect: d.beda, user: d.user, title: '', story: '', steps: [], evidence: [] };
        d.bukuRows.forEach(e => f.evidence.push('Buku: ' + loc(e) + ' ' + sg(e.A) + (e.date ? ' (' + e.date.slice(8, 10) + '/' + e.date.slice(5, 7) + ')' : '')));
        if (!d.expRows.length) {
          const rs = resolved(d.u, d.bukuRows.map(e => e.A).concat([d.buku]));
          const ok = items.find(i => i.u === d.u && i.cls === 'OK' && d.bukuRows.some(e => Math.abs(Math.abs(e.A) - i.amt) < 0.5));
          if (rs.length) {
            f.type = 'hapus'; f.title = 'Sudah beres di BO sebelum tutup buku, tapi masih tercatat';
            f.story = rs.map(x => (x.it.cls === 'NEED_CUT' ? 'Sukses-reject ' : 'Refund ') + fmtN(x.it.amt) + ' (TID ' + x.it.tid + ') sudah di-' + (x.it.cls === 'NEED_CUT' ? 'cut' : 'add') + ' ' + x.done.map(a => ts(a.tdate) + (x.done.length > 1 ? ' ' + fmtN(a.amt) : '')).join(' + ') + '.').join(' ');
            f.steps.push('Hapus ' + d.bukuRows.map(loc).join(', ') + (rs.some(x => x.it.cls === 'NEED_CUT') ? ', atau tambah ' + sg(-d.buku) + ' di tanggal cut' : ''));
          } else if (ok) {
            f.type = 'hapus'; f.title = 'WD ini sukses di Hoki, tidak perlu dicatat';
            f.story = 'WD ' + fmtN(ok.amt) + ' (TID ' + ok.tid + ') sukses di Hoki ' + ts(ok.fin || ok.trx) + ' dan Confirmed di BO, jadi tidak ada yang menggantung.';
            f.steps.push('Hapus ' + d.bukuRows.map(loc).join(', '));
          } else {
            f.type = 'cek'; f.title = 'Tercatat di buku, tapi tidak ada transaksi yang cocok';
            f.story = 'Tidak ada WD Hoki, WD BO, atau adjustment ' + fmtN(Math.abs(d.buku)) + ' untuk user ini di file yang dimasukkan.';
            f.steps.push('Cek catatan ini; kalau salah catat, hapus ' + d.bukuRows.map(loc).join(', '));
          }
        } else {
          const ks = new Set(d.expRows.map(e => e.k));
          const lines = d.expRows.map(e => {
            switch (e.k) {
              case 'REF': return { t: 'bo', s: 'Refund Hoki ' + fmtN(e.full) + ' (TID ' + e.ref + ', ' + ts(e.at) + ') belum dikembalikan ke member.', step: 'ADD ' + fmtN(e.amt) + ' di BO, atau catat +' + fmtN(e.amt) + ' di buku sampai di-add' };
              case 'REFP': return { t: 'bo', s: 'Refund Hoki ' + fmtN(e.full) + ' (TID ' + e.ref + ') baru di-add sebagian, kurang ' + fmtN(e.amt) + '.', step: 'ADD ' + fmtN(e.amt) + ' lagi di BO, atau catat +' + fmtN(e.amt) + ' di buku' };
              case 'REFX': return { t: 'bo', s: 'Refund Hoki ' + fmtN(e.full) + ' (TID ' + e.ref + ') sudah di-add ' + fmtN(e.full - e.amt) + ', kelebihan ' + fmtN(-e.amt) + '.', step: 'CUT ' + fmtN(-e.amt) + ' di BO, atau catat −' + fmtN(-e.amt) + ' di buku' };
              case 'SRX': return { t: 'bo', s: 'Sukses-reject ' + fmtN(e.full) + ' (TID ' + e.ref + ') sudah di-cut ' + fmtN(e.full + e.amt) + ', kelebihan cut ' + fmtN(e.amt) + '.', step: 'ADD ' + fmtN(e.amt) + ' di BO, atau catat +' + fmtN(e.amt) + ' di buku' };
              case 'SR': return { t: 'bo', s: 'WD ' + fmtN(e.full) + ' (TID ' + e.ref + ') sukses di Hoki tapi di-reject di BO: member dapat uang dan koinnya balik.', step: 'CUT ' + fmtN(-e.amt) + ' di BO; kalau saldo sudah habis, catat −' + fmtN(-e.amt) + ' di grup MISTAKE' };
              case 'SRP': return { t: 'bo', s: 'Sukses-reject ' + fmtN(e.full) + ' (TID ' + e.ref + ') baru di-cut sebagian, kurang ' + fmtN(-e.amt) + '.', step: 'CUT ' + fmtN(-e.amt) + ' lagi, atau catat −' + fmtN(-e.amt) + ' di buku' };
              case 'MAN': return { t: 'tambah', s: 'WD ' + fmtN(e.full) + ' (TID ' + e.ref + ') Confirmed di BO lewat QRISHOKI tapi tidak ada di laporan Hoki (belum sukses), dan coin member yang sudah terpotong belum dikembalikan.', step: 'Catat +' + fmtN(e.amt) + ' di UP/CUT CREDIT sampai di-ADD; cek di Hoki, kalau memang tidak terbayar ADD ' + fmtN(e.amt) + ' ke member' };
              case 'DOBEL': return { t: 'bo', s: 'WD ' + (e.twin ? fmtN(e.twin.amt) + ' (TID ' + e.twin.tid + ')' : '') + ' sudah di-add' + (e.twin && e.twin.when ? ' ' + ts(e.twin.when) : '') + ', lalu di-add lagi ' + fmtN(e.full) + ' ' + ts(e.at) + '.', step: 'CUT ' + fmtN(e.full) + ' di BO (add dobel), atau catat −' + fmtN(e.full) + ' di buku' };
              case 'WRONG': return { t: 'bo', s: 'ADD ' + fmtN(e.full) + ' ' + ts(e.at) + ' masuk ke user ini, padahal note-nya berisi TID ' + e.owner.tid + ' milik ' + e.owner.user + '.', step: 'CUT ' + fmtN(e.full) + ' dari ' + d.user + ', lalu pastikan ' + e.owner.user + ' sudah di-add' };
              case 'ADD': return { t: e.bronze ? 'tambah' : 'tambah', s: 'ADD ' + fmtN(e.full) + ' ' + ts(e.at) + (e.note ? ' ("' + e.note + '")' : '') + ' tidak punya pasangan WD' + (e.pairOut ? ' di periode ini' : '') + '.' + (e.paid ? ' Padahal WD ' + fmtN(e.paid.amt) + ' (TID ' + e.paid.tid + ') sukses dibayar Hoki ' + ts(e.paid.when) + ', jadi member dapat uang dan koinnya dikembalikan juga.' : '') + (e.noCoin ? ' Di coin log, WD ' + e.noCoin + ' tidak pernah mengembalikan coin (WD-nya ditolak), jadi ADD ini kelebihan.' : ''), step: e.paid ? 'CUT ' + fmtN(e.full) + ' di BO, atau catat −' + fmtN(e.full) + ' di buku' : 'Catat −' + fmtN(e.full) + ' di buku' + (e.bronze ? '' : ', atau cek apakah add ini salah') };
              case 'CUT': return { t: 'tambah', s: 'CUT ' + fmtN(e.full) + ' ' + ts(e.at) + (e.note ? ' ("' + e.note + '")' : '') + ' tidak punya pasangan' + (e.pairOut ? ' di periode ini (pasangannya di hari sebelumnya)' : '') + '.', step: 'Catat +' + fmtN(e.full) + ' di buku (atau hapus baris yang dibatalkan cut ini)' };
              default: return { t: 'cek', s: e.why, step: '' };
            }
          });
          f.story = lines.map(l => l.s).join(' ');
          f.steps = [...new Set(lines.map(l => l.step).filter(Boolean))];
          if (d.bukuRows.length) {
            f.type = 'ubah'; f.title = 'Nominal di buku beda dengan seharusnya';
            f.steps.unshift('Ubah ' + d.bukuRows.map(loc).join(', ') + ' supaya totalnya ' + sg(d.seharusnya) + ' (sekarang ' + sg(d.buku) + ')');
          } else {
            f.type = lines.some(l => l.t === 'bo') ? 'bo' : lines.every(l => l.t === 'tambah') ? 'tambah' : 'cek';
            f.title = ks.has('DOBEL') ? 'ADD dobel' : ks.has('WRONG') ? 'ADD ke user yang salah' : ks.has('REFX') ? 'Refund di-add lebih' : ks.has('SRX') ? 'Sukses-reject di-cut lebih' : (ks.has('REF') || ks.has('REFP')) ? 'Refund belum di-add' : (ks.has('SR') || ks.has('SRP')) ? 'Sukses-reject belum di-cut' : ks.has('MAN') ? 'WD tidak ada di Hoki' : 'Adjustment belum dicatat di buku';
          }
        }
        findings.push(f);
      }
      const order = { rumus: 0, grup: 1, hapus: 2, ubah: 3, tambah: 4, bo: 5, cek: 6 };
      findings.sort((a, b) => (order[a.type] - order[b.type]) || (Math.abs(b.effect) - Math.abs(a.effect)));
      findings.forEach((f, i) => { f.id = 'f' + i; });
    }

    return {
      findings,
      S, S0, D, Dmax, coverage, days: hokiDays, items, manual, adj, expected, compare,
      coin: coinChk ? { n: coinChk.n, from: coinChk.from, to: coinChk.to, errors: coinChk.errors, topups: coinChk.topups } : null,
      stats: {
        hoki: hoki.length, bo: bo.length, wd: wdMap.size, adj: adj.length,
        OK: [cnt('OK').length, sum(cnt('OK'))], OK_R: [cnt('OK_R').length, sum(cnt('OK_R'))],
        NEED_ADD: [cnt('NEED_ADD').length, sum(cnt('NEED_ADD'))], NEED_CUT: [cnt('NEED_CUT').length, sum(cnt('NEED_CUT'))],
        NO_BO: [cnt('NO_BO').length, sum(cnt('NO_BO'))], OTHER: [cnt('OTHER').length, sum(cnt('OTHER'))], MANUAL: [manual.length, sum(manual)]
      }
    };
  }

  const api = { load, analyze, excelDate, boUser };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.CariSelisih = api;
})(typeof window !== 'undefined' ? window : globalThis);
