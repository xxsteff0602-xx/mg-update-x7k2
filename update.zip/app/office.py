"""MEGA OFFICE - login staff lewat Pusat (Google Sheet + Apps Script), kunci layar, admin, dan catatan hasil Cari Selisih.

Pusat menyimpan akun, izin, pengumuman, dan riwayat masuk. PC ini hanya menyimpan:
  pusat.json         kode Pusat (alamat Apps Script + kunci)
  office_cache.json  sidik sandi (PBKDF2) dari login terakhir yang berhasil, untuk masuk sementara saat internet putus
  profil/<WEB>/selisih_last.json  ringkasan hasil Cari Selisih terakhir (untuk Home)
"""
import os, re, json, time, base64, hashlib, hmac, secrets, socket, threading, urllib.request, urllib.error

APP = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(APP)
CODE_FILE = os.path.join(BASE, "pusat.json")
CACHE_FILE = os.path.join(BASE, "office_cache.json")
OFFLINE_HOURS = 72          # login tanpa internet hanya boleh untuk akun yang berhasil login di PC ini dalam 72 jam terakhir
IDLE_MIN = float(os.environ.get("MO_IDLE_MIN", "10"))   # kunci layar otomatis (menit, dipakai UI)
PC = (socket.gethostname() or "PC")[:60]

def _rj(path, default):
    try:
        with open(path, encoding="utf-8") as f: return json.load(f)
    except Exception: return default

def _wj(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)

def parse_code(code):
    """'MOP1.<base64 json {u,k}>' -> (url, key) atau None."""
    code = re.sub(r"\s+", "", str(code or ""))
    if not code.startswith("MOP1."): return None
    try:
        raw = code[5:]; raw += "=" * (-len(raw) % 4)
        d = json.loads(base64.urlsafe_b64decode(raw).decode("utf-8"))
        u, k = str(d.get("u", "")), str(d.get("k", ""))
    except Exception: return None
    if not re.match(r"^https?://", u) or len(k) < 16: return None
    return u, k

def _pbkdf(pw, salt): return hashlib.pbkdf2_hmac("sha256", str(pw).encode("utf-8"), bytes.fromhex(salt), 120_000).hex()


class Office:
    def __init__(self):
        self.lock = threading.RLock()
        self.user = None; self.token = None; self.offline = False; self.locked = False
        self.since = 0; self.ann = None; self.me_at = 0
        self.web = ""            # alamat MEGA OFFICE web (diatur admin di Pusat), dipakai menu Cek Rekening
        c = _rj(CODE_FILE, {})
        self.code = c.get("code", "") if parse_code(c.get("code", "")) else ""

    # ---------------- koneksi ke Pusat
    def has_code(self): return bool(self.code)

    def call(self, action, timeout=25, **kw):
        pk = parse_code(self.code)
        if not pk: return {"ok": False, "msg": "Kode Pusat belum diisi", "net": True}
        url, key = pk
        body = json.dumps({"k": key, "a": action, "pc": PC, **kw}, ensure_ascii=False).encode("utf-8")
        try:
            req = urllib.request.Request(url, body, {"Content-Type": "text/plain;charset=utf-8"})
            raw = urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8", "ignore")
        except Exception as ex:
            return {"ok": False, "net": True, "msg": "Pusat tidak bisa dihubungi (" + str(ex)[:60] + ")"}
        try: return json.loads(raw)
        except ValueError: return {"ok": False, "net": True, "msg": "Balasan Pusat tidak dikenali. Cek kode Pusat / deploy Web app (akses Anyone)."}

    def set_code(self, code):
        if not parse_code(code): return {"ok": False, "msg": "Kode Pusat tidak valid. Salin ulang dari Google Sheet (menu MEGA OFFICE > Tampilkan Kode Pusat)."}
        old = self.code; self.code = re.sub(r"\s+", "", code)
        r = self.call("ping", timeout=20)
        if not r.get("ok"):
            self.code = old
            return {"ok": False, "msg": r.get("msg") or "Kode ditolak Pusat"}
        _wj(CODE_FILE, {"code": self.code, "set_at": time.strftime("%Y-%m-%d %H:%M:%S")})
        return {"ok": True, "msg": "Tersambung ke Pusat: " + str(r.get("name", ""))}

    # ---------------- cache untuk login tanpa internet
    def _cache_put(self, user, pw):
        c = _rj(CACHE_FILE, {})
        salt = secrets.token_hex(16)
        c[user["username"]] = {"salt": salt, "hash": _pbkdf(pw, salt), "user": user, "ts": time.time()}
        try: _wj(CACHE_FILE, c)
        except OSError: pass

    def _cache_check(self, username, pw):
        e = _rj(CACHE_FILE, {}).get(username)
        if not e or time.time() - e.get("ts", 0) > OFFLINE_HOURS * 3600: return None
        if not hmac.compare_digest(_pbkdf(pw, e["salt"]), e["hash"]): return None
        return e["user"]

    def _cache_drop(self, username):
        c = _rj(CACHE_FILE, {})
        if username in c:
            c.pop(username, None)
            try: _wj(CACHE_FILE, c)
            except OSError: pass

    # ---------------- sesi
    def login(self, username, pw):
        username = re.sub(r"[^a-z0-9._-]", "", str(username or "").lower())[:30]
        if not username or not pw: return {"ok": False, "msg": "Isi username dan sandi."}
        r = self.call("login", u=username, p=pw)
        if r.get("ok"):
            u = r["user"]
            with self.lock:
                self.user, self.token, self.offline, self.locked = u, r["token"], False, False
                self.since = time.time(); self.ann = r.get("ann"); self.me_at = time.time(); self.web = str(r.get("web") or "")
            self._cache_put(u, pw)
            return {"ok": True, "user": u}
        if r.get("net"):
            u = self._cache_check(username, pw)
            if u:
                with self.lock:
                    self.user, self.token, self.offline, self.locked = u, None, True, False
                    self.since = time.time(); self.ann = None
                return {"ok": True, "user": u, "offline": True, "msg": "Pusat tidak bisa dihubungi. Masuk mode offline (pakai login terakhir di PC ini)."}
            return {"ok": False, "msg": r.get("msg", "Pusat tidak bisa dihubungi.") + " Login offline hanya untuk akun yang sudah pernah login di PC ini."}
        if r.get("locked") or "salah" in str(r.get("msg", "")).lower(): self._cache_drop(username)
        return {"ok": False, "msg": r.get("msg", "Login gagal"), "locked": bool(r.get("locked"))}

    def logged_in(self): return self.user is not None
    def is_admin(self): return bool(self.user) and self.user.get("role") == "admin"
    def usable(self): return self.user is not None and not self.locked

    def lock_screen(self):
        with self.lock:
            if self.user: self.locked = True
        return {"ok": True}

    def unlock(self, pw):
        if not self.user: return {"ok": False, "msg": "Belum login"}
        if self.token:
            r = self.call("verify", t=self.token, p=pw)
            if r.get("expired"): self.clear(); return {"ok": False, "expired": True, "msg": r.get("msg")}
            if r.get("ok"):
                self.locked = False; self._cache_put(self.user, pw); return {"ok": True}
            if not r.get("net"):
                if r.get("locked"): self._cache_drop(self.user["username"]); self.clear()
                return {"ok": False, "msg": r.get("msg", "Sandi salah"), "locked": bool(r.get("locked"))}
        if self._cache_check(self.user["username"], pw):          # offline: cek ke sidik sandi lokal
            self.locked = False; return {"ok": True}
        time.sleep(0.6)
        return {"ok": False, "msg": "Sandi salah."}

    def clear(self):
        with self.lock: self.user = None; self.token = None; self.offline = False; self.locked = False; self.ann = None; self.web = ""

    def logout(self, info=""):
        t = self.token
        self.clear()
        if t: threading.Thread(target=self.call, args=("logout",), kwargs={"t": t, "info": info}, daemon=True).start()
        return {"ok": True}

    def passwd(self, old, new):
        if not self.token: return {"ok": False, "msg": "Ganti sandi butuh koneksi ke Pusat."}
        r = self.call("passwd", t=self.token, old=old, new=new)
        if r.get("ok"):
            self.user = r["user"]; self._cache_put(self.user, new)
        elif r.get("expired"): self.clear()
        return r

    def rename(self, pw, new):
        """Ganti username sendiri. Pusat memberi token baru (token lama berisi username lama)."""
        if not self.token: return {"ok": False, "msg": "Ganti username butuh koneksi ke Pusat."}
        new = str(new or "").strip().lower()
        if not re.fullmatch(r"[a-z0-9._-]{3,30}", new): return {"ok": False, "msg": "Username 3-30 karakter: huruf kecil, angka, titik, strip, garis bawah."}
        old = self.user["username"]
        r = self.call("rename", t=self.token, p=pw, nu=new)
        if r.get("ok") and r.get("token"):
            with self.lock: self.user = r["user"]; self.token = r["token"]; self.me_at = time.time()
            self._cache_drop(old); self._cache_put(self.user, pw)
        elif r.get("expired"): self.clear()
        elif r.get("locked"): self._cache_drop(old)
        return r

    def refresh(self, force=False):
        """Ambil ulang data akun + pengumuman (paling sering tiap 60 detik). Akun dinonaktifkan / sesi habis -> keluar."""
        if not self.token or (not force and time.time() - self.me_at < 60): return
        self.me_at = time.time()
        r = self.call("me", t=self.token, timeout=15)
        if r.get("ok"):
            self.user = r["user"]; self.ann = r.get("ann"); self.web = str(r.get("web") or "") if "web" in r else self.web
            if self.offline: self.offline = False
        elif r.get("expired"): self.clear()

    def event(self, ev, info=""):
        if self.token: threading.Thread(target=self.call, args=("event",), kwargs={"t": self.token, "ev": ev, "info": info}, daemon=True).start()

    def admin(self, action, **kw):
        if not self.is_admin(): return {"ok": False, "msg": "Khusus admin."}
        if not self.token: return {"ok": False, "msg": "Mode offline: menu admin butuh koneksi ke Pusat."}
        if action not in ("users", "save", "reset", "unlock", "delete", "history", "announce", "setweb"): return {"ok": False, "msg": "aksi tidak dikenal"}
        r = self.call(action, t=self.token, **kw)
        if r.get("expired"): self.clear()
        if action == "announce" and r.get("ok"): self.ann = r.get("ann")
        if action == "setweb" and r.get("ok"): self.web = str(r.get("web") or "")
        return r

    def can(self, app): return bool(self.user) and (self.user.get("role") == "admin" or app in (self.user.get("apps") or []))

    def rekening(self, bank, account):
        """Cek nama pemilik rekening lewat MEGA OFFICE web (API key ggapi / apivalidasi ada di web, bukan di PC ini)."""
        if not self.can("rekening"): return {"success": False, "error": "Akun ini tidak punya akses Cek Rekening. Hubungi admin."}
        if not self.token: return {"success": False, "error": "Cek Rekening butuh koneksi ke Pusat (sekarang mode offline)."}
        if not self.web: return {"success": False, "error": "Alamat MEGA OFFICE web belum diatur. Admin: menu Pengumuman > Alamat web."}
        body = json.dumps({"bank": str(bank or "")[:20], "account": re.sub(r"\D", "", str(account or ""))[:25]}).encode("utf-8")
        req = urllib.request.Request(self.web.rstrip("/") + "/api/validate", body,
                                     {"Content-Type": "application/json", "Authorization": "Pusat " + self.token, "User-Agent": "MEGA-OFFICE/" + PC})
        try: raw = urllib.request.urlopen(req, timeout=30).read()
        except urllib.error.HTTPError as ex: raw = ex.read()            # 401/403/502 tetap berisi pesan JSON
        except Exception as ex: return {"success": False, "error": "MEGA OFFICE web tidak bisa dihubungi (" + str(ex)[:60] + ")"}
        try: r = json.loads(raw.decode("utf-8", "ignore"))
        except ValueError: return {"success": False, "error": "Balasan web tidak dikenali. Cek alamat web di menu Pengumuman."}
        if r.get("login"): r["error"] = "Sesi login habis. Lock lalu buka lagi, atau sign out dan login ulang."
        return r

    def view(self):
        u = self.user
        return {"pusat": self.has_code(), "pc": PC, "idle_min": IDLE_MIN, "locked": self.locked, "offline": self.offline,
                "user": u, "ann": self.ann if u else None, "web": self.web if u else ""}


# ---------------- hasil Cari Selisih terakhir per website (untuk Home)
def selisih_file(prof_dir): return os.path.join(prof_dir, "selisih_last.json")

def selisih_save(prof_dir, d):
    rows = _rj(selisih_file(prof_dir), [])
    def num(x):
        try: return float(x)
        except (TypeError, ValueError): return None
    row = {"day": str(d.get("day", ""))[:10], "selisih": num(d.get("selisih")), "ketemu": num(d.get("ketemu")), "sisa": num(d.get("sisa")),
           "n": int(d.get("n") or 0), "at": time.strftime("%Y-%m-%d %H:%M"), "by": str(d.get("by", ""))[:30]}
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", row["day"]): return {"ok": False}
    rows = [r for r in rows if r.get("day") != row["day"]] + [row]
    rows.sort(key=lambda r: r["day"]); rows = rows[-14:]
    os.makedirs(prof_dir, exist_ok=True); _wj(selisih_file(prof_dir), rows)
    return {"ok": True}

def selisih_load(prof_dir): return _rj(selisih_file(prof_dir), [])
