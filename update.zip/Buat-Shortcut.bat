@echo off
cd /d "%~dp0"
echo Membuat shortcut MEGA GAMING di Desktop...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\MEGA GAMING.lnk'); $s.TargetPath='%~dp0MEGA-GAMING.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0app\icon.ico'; $s.WindowStyle=7; $s.Save()"
echo Selesai. Klik dua kali "MEGA GAMING" di Desktop untuk membuka.
echo.
choice /c YN /m "Buka otomatis setiap Windows menyala"
if errorlevel 2 goto :end
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut([Environment]::GetFolderPath('Startup')+'\MEGA GAMING.lnk'); $s.TargetPath='%~dp0MEGA-GAMING.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0app\icon.ico'; $s.WindowStyle=7; $s.Save()"
echo Ditambahkan ke Startup Windows.
:end
pause
