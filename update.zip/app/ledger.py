"""Buku deposit lokal (pengganti Google Sheet): satu baris per deposit, User ID + Deposit ID diisi dari BO."""
import os, re, json, time, threading

# ======================= pencocokan nama =======================
# Sapaan / gelar yang tidak ikut dibandingkan ("I" dan "NI" = awalan nama Bali)
TITLES = {"BPK", "BAPAK", "IBU", "SDR", "SDRI", "SDRA", "TN", "NY", "NN", "MR", "MRS", "MS", "I", "NI", "HJ", "IR", "DRS", "DR"}
# Ejaan lain dari nama yang sama -> satu bentuk
ALIAS = {}
for _canon, _alts in {
    "MUHAMAD": "MUH MUHAMAD MUHAMMAD MUHAMMED MUHAMED MOH MOHAMAD MOHAMMAD MOHAMMED MOHAMED MOCH MOCHAMAD MOCHAMMAD MOCHAMED "
               "MUCH MUCHAMAD MUCHAMMAD MHD MHMD MHMMD MOHD MUHD MUHAMAT MOHAMAT MOCHAMAT",
    "AHMAD": "AHMAD ACHMAD AHMMAD ACHMAT AHMAT AHMED ACHMED",
    "ABDUL": "ABD ABDUL ABDOEL ABDUL",
    "NUR": "NUR NOOR NOER NURR",
    "SITI": "SITI STI",
    "SAIFUL": "SAIFUL SYAIFUL SAEFUL SYAEFUL SAIPUL SYAIPUL",
    "YUSUF": "YUSUF YUSUP JUSUF YUSUFF",
}.items():
    for _a in _alts.split(): ALIAS[_a] = _canon

def norm(x): return re.sub(r"\s+", " ", re.sub(r"[^A-Z ]", " ", str(x or "").upper())).strip()

def canon(t):
    """Satu kata -> bentuk baku: ejaan lama (OE->U, DJ->J, TJ->C), huruf dobel, alias nama umum."""
    if t in ALIAS: return ALIAS[t]
    t = t.replace("OE", "U").replace("DJ", "J").replace("TJ", "C")
    t = re.sub(r"(.)\1+", r"\1", t)
    return ALIAS.get(t, t)

def lev(a, b):
    m, n = len(a), len(b)
    if not m: return n
    if not n: return m
    prev = list(range(n + 1))
    for i in range(1, m + 1):
        cur = [i]
        for j in range(1, n + 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (0 if a[i - 1] == b[j - 1] else 1)))
        prev = cur
    return prev[n]

def _ratio(a, b):
    if not a or not b: return 0.0
    return 1 - lev(a, b) / max(len(a), len(b))

TRUNC = 16          # myBCA memotong nama di 18 huruf: nama sepanjang ini kemungkinan terpotong

def _tok_credit(t, u, t_last_cut, u_last_cut):
    """Nilai 0..1 untuk dua kata."""
    if t == u: return 1.0
    if (t_last_cut and len(t) >= 2 and u.startswith(t)) or (u_last_cut and len(u) >= 2 and t.startswith(u)): return 1.0   # kata terakhir terpotong
    if len(t) > 3 and len(u) > 3 and lev(t, u) <= (2 if min(len(t), len(u)) >= 8 else 1): return 0.95                     # salah ketik / ejaan
    if len(t) == 1 and u.startswith(t) or len(u) == 1 and t.startswith(u): return 0.6                                     # inisial: M = MUHAMAD
    if min(len(t), len(u)) >= 3 and (u.startswith(t) or t.startswith(u)): return 0.8                                      # singkatan: ABD = ABDUL
    return 0.0

def _words(n):
    w = [canon(x) for x in n.split(" ") if x]
    keep = [x for x in w if x not in TITLES]
    return keep or w

def sim(a, b):
    """Kemiripan nama 0..1. Tahan nama terpotong, urutan kata beda, singkatan, inisial, ejaan lama."""
    a, b = norm(a), norm(b)
    if not a or not b: return 0.0
    ta, tb = _words(a), _words(b)
    if not ta or not tb: return 0.0
    ca, cb = len(a) >= TRUNC, len(b) >= TRUNC
    # kata per kata, tiap kata hanya dipakai sekali (urutan bebas)
    if len(ta) > len(tb): ta, tb, ca, cb = tb, ta, cb, ca
    used, tot = set(), 0.0
    for i, t in enumerate(ta):
        best, bj = 0.0, -1
        for j, u in enumerate(tb):
            if j in used: continue
            c = _tok_credit(t, u, ca and i == len(ta) - 1, cb and j == len(tb) - 1)
            if c > best: best, bj = c, j
        if bj >= 0: used.add(bj); tot += best
    tok = tot / len(tb)                                         # dibagi jumlah kata nama yang lebih panjang
    if len(ta) >= 2: tok = max(tok, 0.85 * tot / len(ta))       # nama pendek (>= 2 kata) yang semuanya ada di nama panjang
    # dibandingkan utuh (tanpa spasi), urutan asli dan urutan diurutkan
    ja, jb = "".join(ta), "".join(tb)
    joined = max(_ratio(ja, jb), _ratio("".join(sorted(ta)), "".join(sorted(tb))))
    if joined < 0.85: joined *= 0.8                             # mirip sebagian saja: jangan terlalu dipercaya
    # nama terpotong: yang satu awalan yang lain
    pre = 0.0
    sa, sb = " ".join(ta), " ".join(tb)
    if (len(a) >= TRUNC or len(b) >= TRUNC) and min(len(sa), len(sb)) >= 10 and (sa.startswith(sb) or sb.startswith(sa)): pre = 0.95
    return round(min(1.0, max(tok, joined, pre)), 3)

# ---- aturan KETAT untuk auto confirm (lebih keras dari sim) ----
# Nama depan / urutan lahir yang sangat umum: tidak cukup sebagai bukti orang yang sama.
WEAK = set("""MUHAMAD AHMAD ABDUL NUR SITI WAYAN MADE NYOMAN KETUT PUTU KADEK KOMANG GEDE NENGAH LUH AYU GUSTI NGURAH IDA BAGUS DEWA
DESAK ANAK AGUNG""".split())
def skel(t):
    """Kerangka konsonan: ejaan beda vokal / H / Y dianggap sama (ZAENAL=ZAINAL, NURDIYANTO=NURDIANTO), konsonan beda = orang beda."""
    return re.sub(r"[AEIOUYH]", "", t)

def strict_ok(a, b):
    """True kalau dua nama hampir pasti orang yang sama. Semua kata nama yang lebih pendek harus cocok ketat
    (sama, alias, terpotong, atau hanya beda vokal), minimal satu kata yang tidak umum, dan nama satu kata
    hanya boleh cocok dengan nama satu kata (atau nama yang terpotong)."""
    a, b = norm(a), norm(b)
    if not a or not b: return False
    ta, tb = _words(a), _words(b)
    ca, cb = len(a) >= TRUNC, len(b) >= TRUNC
    if len(ta) > len(tb): ta, tb, ca, cb = tb, ta, cb, ca
    used, strong_hit = set(), False
    for i, t in enumerate(ta):
        hit = -1
        for j, u in enumerate(tb):
            if j in used: continue
            last_cut = (ca and i == len(ta) - 1 and len(t) >= 2 and u.startswith(t)) or (cb and j == len(tb) - 1 and len(u) >= 2 and t.startswith(u))
            same = t == u or last_cut or (len(t) >= 4 and len(u) >= 4 and skel(t) == skel(u) and abs(len(t) - len(u)) <= 2)
            initial = len(t) == 1 and u.startswith(t) and len(ta) >= 2
            if same or initial:
                hit = j
                if same and len(t) >= 3 and t not in WEAK and u not in WEAK: strong_hit = True
                break
        if hit < 0: return False
        used.add(hit)
    if len(ta) == 1 and len(tb) > 1 and not (ca or cb): return False     # "BUDI" vs "BUDI SANTOSO": terlalu umum
    return strong_hit

SURE_BEFORE = 20 * 60      # auto confirm hanya kalau transfer masuk paling lama 20 menit SEBELUM deposit BO dibuat (atau sesudahnya)

# nama di mutasi/notifikasi yang bukan nama orang (e-wallet / gateway): tidak bisa dibandingkan dengan nama di BO
GENERIC = re.compile(r"\b(ESPAY|VISIONET|AIRPAY|FINARYA|DOMPET ANAK BANGSA|GOPAY|GO PAY|OVO|DANA|SHOPEE|SHOPEEPAY|LINKAJA|LINK AJA|ISAKU|DEBIT INDONE|GOJEK|FINNET|MIDTRANS|XENDIT|DOKU|TELKOM|TOKOPEDIA|BUKALAPAK|FLIP|JENIUS)\b", re.I)
EXTRA_GENERIC = set()          # nama e-wallet dari Pengaturan (misal DANA, VISIONET)
def set_generic(words):
    global EXTRA_GENERIC
    EXTRA_GENERIC = {norm(w) for w in words if norm(w)}
def generic(name):
    if GENERIC.search(str(name or "")): return True
    n = " " + norm(name) + " "
    return any(" " + w + " " in n for w in EXTRA_GENERIC)

def ts_epoch(ts):
    try: return time.mktime(time.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S"))
    except Exception: return 0

DEFAULT_OPT = {"name_min": 0.6, "name_diff": 0.35, "wait": 600, "window": 3 * 3600, "rej_receipt": True, "rej_name": True, "rej_amount": True}

class Ledger:
    def __init__(self, path):
        self.path, self.lock, self.rows = path, threading.RLock(), []
        self.opt = dict(DEFAULT_OPT); self.rev = 0; self.del_at = 0
        try:
            with open(path, encoding="utf-8") as f: self.rows = json.load(f)
        except Exception: self.rows = []

    def configure(self, cfg):
        """Ambil pengaturan pencocokan / auto reject dari config aplikasi."""
        def num(k, d, lo, hi):
            try: return min(hi, max(lo, float(cfg.get(k, d))))
            except (TypeError, ValueError): return d
        nm = num("name_min", 60, 40, 95) / 100
        self.opt = {"name_min": nm, "name_diff": min(num("name_diff", 35, 5, 90) / 100, nm - 0.05),
                    "wait": num("rej_wait", 10, 2, 180) * 60, "window": num("rej_window", 3, 1, 24) * 3600,
                    "rej_receipt": str(cfg.get("rej_receipt", "1")) == "1", "rej_name": str(cfg.get("rej_name", "1")) == "1",
                    "rej_amount": str(cfg.get("rej_amount", "1")) == "1"}

    def _save(self):
        self.rev += 1
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f: json.dump(self.rows, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError: pass

    def add(self, id, ts, name, amount, pend=False):
        with self.lock:
            if any(r["id"] == id for r in self.rows): return False
            self.rows.append({"id": id, "ts": ts, "name": name or "", "amount": int(amount), "user": "", "txid": "", "pend": bool(pend), "unsure": False, "confirmed": False})
            self.rows = self.rows[-5000:]; self._save(); return True

    def unpend(self, id):
        """Deposit PEND sudah posting di myBCA."""
        with self.lock:
            for r in self.rows:
                if r["id"] == id:
                    if r["pend"]: r["pend"] = False; self._save()
                    return True
        return False

    def _rivals(self, r, name, exclude):
        """Baris bank lain (belum terpakai, nominal sama) yang juga cocok dengan nama BO dan BUKAN orang yang sama dengan r."""
        nm = self.opt["name_min"]
        return [x for x in self.rows if x is not r and x["id"] not in exclude and not x["user"] and not x["txid"]
                and x["amount"] == r["amount"] and sim(x["name"], name) >= nm and sim(x["name"], r["name"]) < 0.9]

    def match(self, txid, user, name, amount, when=None, done=False):
        """Pasangkan deposit BO ke baris bank. Kembalikan {ok, sure, pend, confirmed, sheetName}.
        when = jam deposit BO dibuat (epoch detik), done = deposit BO sudah selesai (approved): hanya diisi kalau yakin.
        sure (boleh auto confirm) = nama cocok KETAT + transfer tidak lebih dari 20 menit sebelum deposit dibuat + tidak ada pesaing."""
        none = {"ok": False}
        txid = str(txid)
        nm, win = self.opt["name_min"], self.opt["window"]
        try: amt = int(amount)
        except (TypeError, ValueError): return none
        with self.lock:
            for r in self.rows:
                if r["txid"] == txid:
                    if r["amount"] != amt: return none                  # Deposit ID salah ketik / salah pasang: nominal beda, jangan dipakai
                    if r.get("manual"):                                  # dipasang manual di aplikasi: yakin hanya kalau nama juga cocok ketat
                        sure = sim(r["name"], name) >= nm and strict_ok(r["name"], name)
                    else:
                        sure = not r["unsure"] and r.get("sure", True)
                        if not sure and r.get("why") == "rival" and not self._rivals(r, name, set()):   # pesaing sudah dipakai deposit lain
                            r["sure"] = True; r["why"] = ""; self._save(); sure = True
                    return {"ok": True, "sure": sure, "pend": r["pend"], "confirmed": r["confirmed"], "sheetName": r["name"]}
            cand = []
            for i, r in enumerate(self.rows):
                if r["user"] or r["txid"] or r["amount"] != amt: continue
                if when:
                    t = ts_epoch(r["ts"])
                    if t and t < when - win: continue                  # transfer jauh sebelum deposit BO dibuat
                    if done and t and t > when + win: continue         # deposit lama yang sudah selesai: jangan ambil transfer baru
                cand.append((i, sim(r["name"], name)))
            if not cand or not strict_ok(self.rows[max(cand, key=lambda c: c[1])[0]]["name"], name):
                # Baris yang dipasang ke deposit lain dengan nama KURANG YAKIN (belum di-confirm) boleh direbut oleh deposit
                # yang namanya cocok ketat. Contoh: RIZAL memegang transfer RIZKI, lalu deposit RIZKI masuk -> pindah ke RIZKI.
                for i, r in enumerate(self.rows):
                    if (r["txid"] and r.get("why") == "name" and not r["confirmed"] and not r.get("manual") and r["amount"] == amt
                            and (not when or not ts_epoch(r["ts"]) or ts_epoch(r["ts"]) >= when - win) and strict_ok(r["name"], name)):
                        r["user"] = ""; r["txid"] = ""; r["why"] = ""; r["sure"] = False
                        cand.append((i, sim(r["name"], name)))
                        break
            if not cand: return none
            cand.sort(key=lambda c: (-c[1], c[0]))                     # nama paling mirip, lalu transfer paling lama
            bi, bs = cand[0]; r = self.rows[bi]
            strong = bs >= nm
            if not strong:
                # nama beda: JANGAN dipasangkan (bisa jadi transfer orang lain, sedang transfer member ini belum masuk).
                # Kecuali nama bank berupa e-wallet / gateway (tidak bisa dibandingkan) dan hanya satu kandidat: isi dengan tanda cek.
                if done or len(cand) != 1 or not generic(r["name"]): return none
            why = ""
            if not strong: why = "ewallet"
            elif not strict_ok(r["name"], name): why = "name"
            elif when and ts_epoch(r["ts"]) and ts_epoch(r["ts"]) < when - SURE_BEFORE: why = "time"
            elif any(s >= nm and sim(self.rows[i]["name"], r["name"]) < 0.9 for i, s in cand[1:]): why = "rival"
            sure = not why
            if done and not (strong and why in ("", "time")): return none     # deposit selesai: isi ID hanya kalau nama cocok ketat
            r["user"] = str(user or ""); r["txid"] = txid; r["unsure"] = not strong; r["sure"] = sure; r["why"] = why
            self._save()
            return {"ok": True, "sure": sure, "pend": r["pend"], "confirmed": False, "sheetName": r["name"]}

    def mark_confirmed(self, txid):
        with self.lock:
            for r in self.rows:
                if r["txid"] == str(txid):
                    if not r["confirmed"]: r["confirmed"] = True; self._save()
                    return True
        return False

    def delete(self, ids=None, day=None):
        with self.lock:
            n = len(self.rows)
            if ids is not None: s = set(ids); self.rows = [r for r in self.rows if r["id"] not in s]
            elif day: self.rows = [r for r in self.rows if r["ts"][:10] != day]
            if n != len(self.rows): self.del_at = time.time()       # baris bank dihapus: deposit BO yang sudah ada tidak boleh di-reject karena "tidak ada transfer"
            self._save(); return n - len(self.rows)

    def edit(self, id, field, value):
        if field not in ("user", "txid"): return False
        with self.lock:
            for r in self.rows:
                if r["id"] == id:
                    r[field] = str(value or "").strip()
                    if r[field]: r["unsure"] = False; r["manual"] = True      # auto confirm hanya kalau nominal + nama cocok (dicek di match)
                    self._save(); return True
        return False

    def unassign(self, txid):
        """Setelah deposit BO di-reject: lepaskan pasangannya supaya baris bank bisa dipakai deposit lain."""
        with self.lock:
            for r in self.rows:
                if r["txid"] == str(txid):
                    r["user"] = ""; r["txid"] = ""; r["unsure"] = False
                    for k in ("sure", "why", "manual"): r.pop(k, None)
                    self._save(); return True
        return False

    def judge(self, items, now, since, unknown=()):
        """Putuskan tiap deposit BO (In Progress, Fund Method Bank / BCA): reject / ok / skip.
        items: [{txid,name,amount,bornAt(ms),seenAt(ms),noReceipt}]. Hanya reject kalau buktinya jelas; selebihnya skip (cek manual).
        Deposit yang ADA buktinya (receipt) tidak pernah di-reject otomatis. unknown = nominal dari notifikasi myBCA yang tidak terbaca."""
        o = self.opt; nm, nd, grace, win = o["name_min"], o["name_diff"], o["wait"], o["window"]
        out = {}
        def skip(why): return {"v": "skip", "why": why}
        def rej(kind, why, on): return {"v": "reject", "reason": kind, "why": why} if on else skip(why + " (reject jenis ini dimatikan)")
        with self.lock:
            by_tx = {r["txid"]: r for r in self.rows if r["txid"]}
            free = [r for r in self.rows if not r["user"] and not r["txid"] and now - ts_epoch(r["ts"]) <= win + grace]
            n_amt = {}
            for it in items:
                try: n_amt[int(it["amount"])] = n_amt.get(int(it["amount"]), 0) + 1
                except (TypeError, ValueError, KeyError): pass
            for it in items:
                tx = str(it.get("txid"))
                try: amt = int(it["amount"])
                except (TypeError, ValueError, KeyError): out[tx] = skip("nominal tidak terbaca"); continue
                born = (it.get("bornAt") or 0) / 1000.0
                seen = (it.get("seenAt") or 0) / 1000.0
                times = [x for x in (born, seen) if x]
                if since is None: out[tx] = skip("aplikasi belum sehat / belum membaca HP"); continue
                if not times: out[tx] = skip("jam deposit tidak terbaca"); continue
                start, ref = min(times), max(times)                       # start: kapan deposit dibuat, ref: masa tunggu dihitung dari yang paling akhir
                if start < since: out[tx] = skip("deposit lebih tua dari pemantauan aplikasi"); continue
                if now - ref < grace: out[tx] = skip(f"masih dalam masa tunggu ({int(grace // 60)} menit)"); continue
                if start < self.del_at + grace: out[tx] = skip("baris buku baru saja dihapus, cek manual"); continue
                if amt in unknown: out[tx] = skip(f"ada notifikasi myBCA Rp {amt:,} yang tidak terbaca, cek manual".replace(",", ".")); continue
                c = by_tx.get(tx)
                nr = bool(it.get("noReceipt"))
                near = lambda r: start - 120 <= ts_epoch(r["ts"]) <= start + 1800     # transfer masuk tepat setelah deposit dibuat
                if c:
                    if c["unsure"] and not generic(c["name"]):            # data lama (versi sebelumnya memasangkan nama beda)
                        s = sim(c["name"], it.get("name"))
                        if s >= nd: out[tx] = skip("nama agak mirip, cek manual")
                        elif n_amt[amt] == 1 and nr: out[tx] = rej("NAME", f'nominal sama tapi nama beda: bank "{c["name"]}" vs BO "{it.get("name")}"', o["rej_name"])
                        else: out[tx] = skip("nama beda tapi ada deposit BO bernominal sama, cek manual")
                    else: out[tx] = {"v": "ok"}
                    continue
                same = [r for r in free if r["amount"] == amt and ts_epoch(r["ts"]) >= start - win]
                if same:
                    sims = [(r, sim(r["name"], it.get("name"))) for r in same]
                    if any(s >= nm and not generic(r["name"]) for r, s in sims): out[tx] = {"v": "ok"}          # sebentar lagi dipasangkan
                    elif any(generic(r["name"]) for r in same): out[tx] = skip("nama di bank e-wallet/gateway, cek manual")
                    elif len(same) == 1 and n_amt[amt] == 1 and sims[0][1] < nd and nr and near(same[0]):
                        out[tx] = rej("NAME", f'nominal sama tapi nama beda: bank "{same[0]["name"]}" vs BO "{it.get("name")}"', o["rej_name"])
                    elif not nr: out[tx] = skip("ada bukti transfer, cek manual")
                    else: out[tx] = skip("nominal sama, nama kurang jelas / ada beberapa transfer: cek manual")
                    continue
                namehit = [r for r in free if not generic(r["name"]) and r["amount"] != amt and n_amt.get(r["amount"], 0) == 0
                           and ts_epoch(r["ts"]) >= start - win and sim(r["name"], it.get("name")) >= max(nm, 0.6)]
                if len(namehit) == 1 and nr and near(namehit[0]):
                    out[tx] = rej("AMOUNT", f'nama cocok tapi nominal beda: bank Rp {namehit[0]["amount"]:,} vs BO Rp {amt:,}'.replace(",", "."), o["rej_amount"])
                elif namehit: out[tx] = skip("ada transfer dengan nama mirip tapi nominal beda, cek manual")
                elif nr: out[tx] = rej("RECEIPT", "tidak ada bukti dan tidak ada transfer dengan nama pengirim itu", o["rej_receipt"])
                else: out[tx] = skip("belum ada transfer, tapi ada bukti: cek manual")
        return out

    def view(self):
        with self.lock: return [dict(r) for r in self.rows]


class ListStore:
    """Catatan sederhana (daftar baris) di satu file JSON: log confirm / reject / transfer keluar."""
    def __init__(self, path, cap=5000):
        self.path, self.cap, self.lock = path, cap, threading.Lock()
        try:
            with open(path, encoding="utf-8") as f: self.rows = json.load(f)
        except Exception: self.rows = []
    def add(self, row):
        with self.lock:
            row = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), **row}
            self.rows.append(row)
            if len(self.rows) > self.cap: self.rows = self.rows[-self.cap:]
            self._save(); return row
    def has(self, key, val):
        with self.lock: return any(r.get(key) == val for r in self.rows)
    def view(self):
        with self.lock: return list(self.rows)
    def _save(self):
        tmp = self.path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f: json.dump(self.rows, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except Exception: pass
