// MEGA GAMING -> Google Sheet. Tempel seluruh isi file ini di Extensions > Apps Script.
// GANTI kode rahasia di bawah (sama persis dengan yang diisi di Pengaturan aplikasi).
//
// - Tiap rekening punya TAB sendiri bernama sesuai "Nama rekening" di aplikasi (misal VIP555).
// - Satu tab terus menyambung. Setiap ganti hari ditambah baris pemisah gelap.
// - Kolom dibuat sama dengan buku hitungan: Jenis | Jam | Nama | User ID | Nominal | Deposit ID.
//   Nominal berupa teks 150.000 (titik ribuan). User ID dan Deposit ID dikosongkan untuk diisi sendiri. Kolom G (Status) dan H (ID, disembunyikan) tambahan.
// - Saldo semua rekening masuk ke tab "Saldo".
const SECRET = 'GANTI-KODE-RAHASIA';

const DEP_HEAD = ['Jenis', 'Jam', 'Nama', 'User ID', 'Nominal', 'Deposit ID', 'Status', 'ID'];
const SALDO_HEAD = ['Waktu', 'Label', 'Saldo', 'Perubahan', 'Deposit tercatat', 'Keluar / lain'];
const BULAN = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];

function tab_(name, head, hideLast) {
  const ss = SpreadsheetApp.getActive();
  let s = ss.getSheetByName(name);
  if (!s) s = ss.insertSheet(name);
  if (s.getLastRow() === 0) {
    s.appendRow(head);
    s.setFrozenRows(1);
    s.getRange(1, 1, 1, head.length).setFontWeight('bold').setHorizontalAlignment('center');
    if (hideLast) s.hideColumns(head.length);
  }
  return s;
}

function tabName_(label) {
  const n = String(label || '').replace(/[\[\]\*\?\:\/\\]/g, ' ').trim().substring(0, 90);
  return n || 'Deposit';
}

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

// "2026-10-20 02:19:29" -> {day: '2026-10-20', label: '20 Okt 2026', time: '02:19:29'}
function parts_(ts) {
  const m = String(ts).match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2}:\d{2})/);
  if (!m) return { day: String(ts), label: String(ts), time: '' };
  return { day: m[1] + '-' + m[2] + '-' + m[3], label: parseInt(m[3], 10) + ' ' + BULAN[parseInt(m[2], 10) - 1] + ' ' + m[1], time: m[4] };
}

function rp_(n) {
  return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

function separator_(s, label) {
  s.appendRow([label]);
  const r = s.getLastRow();
  s.getRange(r, 1, 1, DEP_HEAD.length).setBackground('#0b1620').setFontColor('#ffffff').setFontWeight('bold');
}


// ---- Isi User ID + Deposit ID dari BO (dikirim script Tampermonkey BO-ISI-ID) ----
function norm_(x) { return String(x || '').toUpperCase().replace(/[^A-Z ]/g, ' ').replace(/\s+/g, ' ').trim(); }

function lev_(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  let prev = [], cur = [];
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}

// Kemiripan nama 0..1 (sama dengan aplikasi): tahan nama terpotong myBCA, urutan kata beda, singkatan, inisial, ejaan lama.
const TITLES_ = { BPK: 1, BAPAK: 1, IBU: 1, SDR: 1, SDRI: 1, SDRA: 1, TN: 1, NY: 1, NN: 1, MR: 1, MRS: 1, MS: 1, I: 1, NI: 1, HJ: 1, IR: 1, DRS: 1, DR: 1 };
const ALIAS_ = (function () {
  const m = {}, g = {
    MUHAMAD: 'MUH MUHAMAD MUHAMMAD MUHAMMED MUHAMED MOH MOHAMAD MOHAMMAD MOHAMMED MOHAMED MOCH MOCHAMAD MOCHAMMAD MOCHAMED MUCH MUCHAMAD MUCHAMMAD MHD MHMD MHMMD MOHD MUHD MUHAMAT MOHAMAT MOCHAMAT',
    AHMAD: 'AHMAD ACHMAD AHMMAD ACHMAT AHMAT AHMED ACHMED', ABDUL: 'ABD ABDUL ABDOEL', NUR: 'NUR NOOR NOER NURR', SITI: 'SITI STI',
    SAIFUL: 'SAIFUL SYAIFUL SAEFUL SYAEFUL SAIPUL SYAIPUL', YUSUF: 'YUSUF YUSUP JUSUF YUSUFF' };
  Object.keys(g).forEach(function (k) { g[k].split(' ').forEach(function (x) { m[x] = k; }); });
  return m;
})();
const TRUNC_ = 16;
function canon_(t) {
  if (ALIAS_[t]) return ALIAS_[t];
  t = t.replace(/OE/g, 'U').replace(/DJ/g, 'J').replace(/TJ/g, 'C').replace(/(.)\1+/g, '$1');
  return ALIAS_[t] || t;
}
function ratio_(a, b) { return a && b ? 1 - lev_(a, b) / Math.max(a.length, b.length) : 0; }
function credit_(t, u, tc, uc) {
  if (t === u) return 1;
  if ((tc && t.length >= 2 && u.indexOf(t) === 0) || (uc && u.length >= 2 && t.indexOf(u) === 0)) return 1;
  if (t.length > 3 && u.length > 3 && lev_(t, u) <= (Math.min(t.length, u.length) >= 8 ? 2 : 1)) return 0.95;
  if ((t.length === 1 && u.indexOf(t) === 0) || (u.length === 1 && t.indexOf(u) === 0)) return 0.6;
  if (Math.min(t.length, u.length) >= 3 && (u.indexOf(t) === 0 || t.indexOf(u) === 0)) return 0.8;
  return 0;
}
function words_(n) {
  const w = n.split(' ').filter(String).map(canon_), k = w.filter(function (x) { return !TITLES_[x]; });
  return k.length ? k : w;
}
function sim_(a, b) {
  a = norm_(a); b = norm_(b);
  if (!a || !b) return 0;
  let ta = words_(a), tb = words_(b), ca = a.length >= TRUNC_, cb = b.length >= TRUNC_;
  if (ta.length > tb.length) { const x = ta; ta = tb; tb = x; const y = ca; ca = cb; cb = y; }
  const used = {}; let tot = 0;
  ta.forEach(function (t, i) {
    let best = 0, bj = -1;
    tb.forEach(function (u, j) { if (used[j]) return; const c = credit_(t, u, ca && i === ta.length - 1, cb && j === tb.length - 1); if (c > best) { best = c; bj = j; } });
    if (bj >= 0) { used[bj] = 1; tot += best; }
  });
  let tok = tot / tb.length;
  if (ta.length >= 2) tok = Math.max(tok, 0.85 * tot / ta.length);
  let joined = Math.max(ratio_(ta.join(''), tb.join('')), ratio_(ta.slice().sort().join(''), tb.slice().sort().join('')));
  if (joined < 0.85) joined *= 0.8;
  const sa = ta.join(' '), sb = tb.join(' ');
  const pre = (a.length >= TRUNC_ || b.length >= TRUNC_) && Math.min(sa.length, sb.length) >= 10 && (sa.indexOf(sb) === 0 || sb.indexOf(sa) === 0) ? 0.95 : 0;
  return Math.min(1, Math.max(tok, joined, pre));
}
const NAME_MIN = 0.6;   // kemiripan nama minimal untuk dianggap cocok (mengisi ID)
// Aturan KETAT untuk auto confirm (sama dengan aplikasi): semua kata nama pendek cocok persis / alias / terpotong / beda vokal saja,
// minimal satu kata yang tidak umum, dan nama satu kata tidak boleh cocok dengan nama banyak kata.
const WEAK_ = {}; 'MUHAMAD AHMAD ABDUL NUR SITI WAYAN MADE NYOMAN KETUT PUTU KADEK KOMANG GEDE NENGAH LUH AYU GUSTI NGURAH IDA BAGUS DEWA DESAK ANAK AGUNG'.split(' ').forEach(function (w) { WEAK_[w] = 1; });
function skel_(t) { return t.replace(/[AEIOUYH]/g, ''); }
function strictOk_(a, b) {
  a = norm_(a); b = norm_(b);
  if (!a || !b) return false;
  let ta = words_(a), tb = words_(b), ca = a.length >= TRUNC_, cb = b.length >= TRUNC_;
  if (ta.length > tb.length) { const x = ta; ta = tb; tb = x; const y = ca; ca = cb; cb = y; }
  const used = {}; let strong = false;
  for (let i = 0; i < ta.length; i++) {
    const t = ta[i]; let hit = -1;
    for (let j = 0; j < tb.length; j++) {
      if (used[j]) continue;
      const u = tb[j];
      const cut = (ca && i === ta.length - 1 && t.length >= 2 && u.indexOf(t) === 0) || (cb && j === tb.length - 1 && u.length >= 2 && t.indexOf(u) === 0);
      const same = t === u || cut || (t.length >= 4 && u.length >= 4 && skel_(t) === skel_(u) && Math.abs(t.length - u.length) <= 2);
      const initial = t.length === 1 && u.indexOf(t) === 0 && ta.length >= 2;
      if (same || initial) { hit = j; if (same && t.length >= 3 && !WEAK_[t] && !WEAK_[u]) strong = true; break; }
    }
    if (hit < 0) return false;
    used[hit] = 1;
  }
  if (ta.length === 1 && tb.length > 1 && !(ca || cb)) return false;
  return strong;
}
const SURE_BEFORE_MS = 20 * 60e3;   // auto confirm hanya kalau transfer masuk paling lama 20 menit sebelum deposit BO dibuat
// Jam baris DP (kolom B) + tanggal dari baris pemisah di atasnya -> epoch ms (jam PC, dikoreksi dengan zona PC dari script BO)
function rowTimes_(rows, tzo) {
  const tz = Session.getScriptTimeZone(); let day = null; const out = [];
  for (let i = 0; i < rows.length; i++) {
    const a = rows[i][0];
    if (a !== 'DP') {
      let m = null;
      if (a instanceof Date) m = [0, a.getDate(), a.getMonth(), a.getFullYear()];
      else { const x = String(a).match(/^(\d{1,2})\s+(\S+)\s+(\d{4})$/); if (x && BULAN.indexOf(x[2]) >= 0) m = [0, +x[1], BULAN.indexOf(x[2]), +x[3]]; }
      if (m) day = m;
      out.push(0); continue;
    }
    const j = rows[i][1] instanceof Date ? Utilities.formatDate(rows[i][1], tz, 'HH:mm:ss') : String(rows[i][1]);
    const h = j.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?/);
    out.push(day && h && tzo !== undefined && tzo !== '' ? Date.UTC(day[3], day[2], day[1], +h[1], +h[2], +(h[3] || 0)) + Number(tzo) * 60e3 : 0);
  }
  return out;
}
const GENERIC_ = /\b(ESPAY|DOMPET ANAK BANGSA|GOPAY|GO PAY|OVO|DANA|SHOPEE|SHOPEEPAY|LINKAJA|LINK AJA|ISAKU|DEBIT INDONE|GOJEK|FINNET|MIDTRANS|XENDIT|DOKU|TELKOM|TOKOPEDIA|BUKALAPAK|FLIP|JENIUS)\b/i;

function statusFlags_(st) {
  st = String(st || '');
  return { pend: /PEND/i.test(st), uncertain: /\(cek\)/i.test(st), confirmed: /CONFIRMED/i.test(st) };
}

function match_(r) {
  const none = { ok: false };
  const s = SpreadsheetApp.getActive().getSheetByName(tabName_(r.label));
  if (!s || s.getLastRow() < 2) return none;
  const n = s.getLastRow() - 1;
  const rows = s.getRange(2, 1, n, 8).getValues();
  const want = String(r.txid);
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][5]) === want) {                      // sudah terisi sebelumnya
      if (parseInt(String(rows[i][4]).replace(/\D/g, ''), 10) !== Number(r.amount)) return none;   // Deposit ID salah ketik: nominal beda
      const f = statusFlags_(rows[i][6]);
      return { ok: true, sure: !f.uncertain, pend: f.pend, confirmed: f.confirmed, sheetName: String(rows[i][2]) };
    }
  }
  const cand = [];
  for (let i = 0; i < rows.length; i++) {
    const x = rows[i];
    if (x[0] !== 'DP' || x[3] !== '' || x[5] !== '') continue;
    if (parseInt(String(x[4]).replace(/\D/g, ''), 10) !== Number(r.amount)) continue;
    cand.push({ i: i, score: sim_(x[2], r.name) });
  }
  if (!cand.length) return none;
  cand.sort(function (p, q) { return q.score - p.score || p.i - q.i; });   // nama paling mirip, lalu transfer paling lama
  const best = cand[0], bestName = String(rows[best.i][2]);
  const strong = best.score >= NAME_MIN;
  // Nama beda: JANGAN dipasangkan (bisa jadi transfer orang lain). Kecuali nama bank e-wallet/gateway dan hanya satu kandidat: isi dengan tanda (cek).
  if (!strong && (r.done || cand.length !== 1 || !GENERIC_.test(bestName))) return none;
  // "sure" (boleh auto confirm): nama cocok DAN tidak ada kandidat lain yang sama kuat (kecuali orang yang sama)
  const times = r.when ? rowTimes_(rows, r.tzo) : [];
  const tooOld = r.when && times[best.i] && times[best.i] < Number(r.when) - SURE_BEFORE_MS;
  const sure = strong && strictOk_(bestName, r.name) && !tooOld && !cand.slice(1).some(function (c) { return c.score >= NAME_MIN && sim_(rows[c.i][2], bestName) < 0.9; });
  if (r.done && !(strong && strictOk_(bestName, r.name))) return none;   // deposit BO yang sudah selesai: hanya diisi kalau nama cocok ketat
  const row = best.i + 2;
  const f = statusFlags_(rows[best.i][6]);
  s.getRange(row, 4).setValue(r.user);
  s.getRange(row, 6).setNumberFormat('@').setValue(want);
  if (!sure) s.getRange(row, 7).setValue(String(rows[best.i][6]) + ' (cek)');
  return { ok: true, sure: sure, pend: f.pend, confirmed: false, sheetName: bestName };
}

// Deposit BO di-reject / dibatalkan: kosongkan User ID + Deposit ID supaya baris bisa dipakai deposit lain
function release_(r) {
  const s = SpreadsheetApp.getActive().getSheetByName(tabName_(r.label));
  if (!s || s.getLastRow() < 2) return false;
  const rows = s.getRange(2, 1, s.getLastRow() - 1, 8).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][5]) === String(r.txid) && !/CONFIRMED/i.test(String(rows[i][6]))) {
      s.getRange(i + 2, 4).setValue(''); s.getRange(i + 2, 6).setValue('');
      s.getRange(i + 2, 7).setValue(String(rows[i][6]).replace(/\s*\(cek\)/g, ''));
      return true;
    }
  }
  return false;
}

function markConfirmed_(r) {
  const s = SpreadsheetApp.getActive().getSheetByName(tabName_(r.label));
  if (!s || s.getLastRow() < 2) return false;
  const rows = s.getRange(2, 1, s.getLastRow() - 1, 8).getValues();
  for (let i = 0; i < rows.length; i++) {
    if (String(rows[i][5]) === String(r.txid)) {
      if (!/CONFIRMED/i.test(String(rows[i][6]))) s.getRange(i + 2, 7).setValue(String(rows[i][6]) + ' | CONFIRMED');
      return true;
    }
  }
  return false;
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(25000);
  try {
    const b = JSON.parse(e.postData.contents);
    if (b.secret !== SECRET) return out_({ ok: false, error: 'kode rahasia salah' });
    const props = PropertiesService.getScriptProperties();
    const seen = {};   // id yang sudah ada per tab
    let added = 0;
    const results = [];
    (b.rows || []).forEach(function (r) {
      if (r.kind === 'deposit') {
        const name = tabName_(r.label);
        const s = tab_(name, DEP_HEAD, true);
        if (!seen[name]) seen[name] = s.getLastRow() > 1 ? s.getRange(2, 8, s.getLastRow() - 1, 1).getValues().map(function (x) { return String(x[0]); }) : [];
        const key = 'id:' + r.id;
        if (seen[name].indexOf(key) >= 0) return;
        const p = parts_(r.ts);
        const pk = 'day:' + name;
        if (props.getProperty(pk) !== p.day) { separator_(s, p.label); props.setProperty(pk, p.day); }
        s.appendRow(['DP', p.time, r.name, '', '', '', r.status, key]);
        // Nominal ditulis sebagai TEKS berformat titik ribuan (150.000) supaya bisa langsung disalin ke buku hitungan
        s.getRange(s.getLastRow(), 5).setNumberFormat('@').setValue(rp_(r.amount)).setHorizontalAlignment('right');
        seen[name].push(key); added++;
      } else if (r.kind === 'match') {
        const res = match_(r);
        results.push({ txid: r.txid, matched: res.ok, sure: !!res.sure, pend: !!res.pend, confirmed: !!res.confirmed, sheetName: res.sheetName || '' });
        if (res.ok) added++;
      } else if (r.kind === 'released') {
        results.push({ txid: r.txid, released: release_(r) });
      } else if (r.kind === 'confirmed') {
        results.push({ txid: r.txid, marked: markConfirmed_(r) });
      } else if (r.kind === 'saldo') {
        tab_('Saldo', SALDO_HEAD, false).appendRow([r.ts, r.label, Number(r.amount), r.delta === '' ? '' : Number(r.delta), Number(r.dep || 0), r.other === '' ? '' : Number(r.other)]);
        added++;
      }
    });
    return out_({ ok: true, added: added, results: results });
  } catch (err) {
    return out_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function doGet() { return out_({ ok: true, info: 'MEGA GAMING sheet siap' }); }
